#!/usr/bin/env python3
"""Pipeline editorial portable. Separa generación, controles y revisión visual."""
from __future__ import annotations
import argparse
import importlib.metadata
import json
import platform
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path
from ialp import __version__
from ialp.layout import build_document, render_pdf, sha256
from ialp.source import clean_source, preflight_source
from ialp.visuals import render_visuals, VisualRenderError
from ialp.quality import audit_pdf, make_preview, package_files


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def environment():
    versions = {}
    for package in ("mistune", "weasyprint", "PyMuPDF", "Pillow", "Jinja2", "PyYAML", "Pygments", "matplotlib", "openpyxl", "XlsxWriter"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = "NOT_INSTALLED"
    return {"python": platform.python_version(), "system": platform.system(), "machine": platform.machine(), "packages": versions}


def audit_markdown(report):
    return "# Auditoría automática\n\n" + "\n".join(f"- {key}: {report.get(key, 'NOT_RUN')}" for key in ("TEXT_AUDIT", "CONTENT_CHECK", "VISUAL_REVIEW")) + "\n\n```json\n" + json.dumps(report, ensure_ascii=False, indent=2) + "\n```\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("--outdir", default="IALP_OUT")
    parser.add_argument("--skip-mermaid", action="store_true", help="Conserva Mermaid como código; registra SKIPPED")
    parser.add_argument("--mmdc", help="Ruta explícita de Mermaid CLI")
    parser.add_argument("--clean-mode", default="explicit", choices=["preserve", "explicit", "legacy"])
    parser.add_argument("--family", default="auto", choices=["auto", "puerta", "doctrina", "sintesis"])
    parser.add_argument("--engine", default="weasyprint", choices=["weasyprint", "auto", "browser"])
    parser.add_argument("--pages", default="all", help="all, sample o lista 1,2,-1")
    parser.add_argument("--patterns", help="Archivo alternativo de patrones de auditoría")
    parser.add_argument("--browser-no-sandbox", action="store_true")
    args = parser.parse_args()
    source, out = Path(args.source).resolve(), Path(args.outdir).resolve()
    if not source.is_file():
        parser.error("No existe el manuscrito fuente")
    if out.exists() and any(out.iterdir()):
        parser.error("La salida debe estar vacía o ser nueva. Usa otra carpeta para conservar el resultado anterior.")
    out.mkdir(parents=True, exist_ok=True)
    base = source.stem
    run = {"schema": "ialp.run.v1", "kit_version": __version__, "source": source.name,
           "source_sha256": sha256(source), "started_at": datetime.now(timezone.utc).isoformat(),
           "environment": environment(), "status": "STARTED", "visual_review": "NOT_RUN", "stages": []}
    run_path = out / "RUN.json"
    original = out / f"{base}_ORIGINAL.md"
    clean = out / f"{base}_EDITORIAL_LIMPIO.md"
    graphics = out / f"{base}_CON_GRAFICOS.md"
    pdf = out / f"{base}_EDITORIAL.pdf"
    html_path = pdf.with_suffix(".html")
    expected_path = out / "CONTENIDO_ESPERADO.txt"
    visual_dir = out / "verificacion_visual"
    try:
        print("[1/6] Conservación y limpieza explícita", flush=True)
        shutil.copy2(source, original)
        text = source.read_bytes().decode("utf-8")
        kit = Path(__file__).resolve().parents[1]
        pattern_path = Path(args.patterns).resolve() if args.patterns else kit / "05_CONFIG" / "patrones_no_editoriales.txt"
        patterns = [re.compile(line.strip(), re.I) for line in pattern_path.read_text(encoding="utf-8").splitlines() if line.strip() and not line.lstrip().startswith("#")]
        preflight = preflight_source(text, patterns)
        preflight.update(source_sha256=run["source_sha256"], patterns_sha256=sha256(pattern_path))
        write_json(out / "PREFLIGHT.json", preflight)
        run["stages"].append({"stage": "preflight", "status": preflight["status"]})
        if preflight["exit_code"] == 1:
            raise ValueError("Preflight: " + "; ".join(preflight["errors"]))
        legacy_names = [line.strip() for line in (kit / "05_CONFIG" / "encabezados_control.txt").read_text(encoding="utf-8").splitlines() if line.strip() and not line.lstrip().startswith("#")]
        cleaned, cleaning = clean_source(text, mode=args.clean_mode, names=legacy_names)
        clean.write_bytes(cleaned.encode("utf-8"))
        write_json(out / "LIMPIEZA.json", cleaning)
        run["stages"].append({"stage": "source", "status": "COMPLETED", "mode": args.clean_mode})
        print("[2/6] Estructuras visuales", flush=True)
        local_mmdc = kit / "node_modules" / ".bin" / ("mmdc.cmd" if platform.system() == "Windows" else "mmdc")
        mmdc = args.mmdc or (str(local_mmdc) if local_mmdc.is_file() else None)
        transformed, visuals = render_visuals(cleaned, out, source_dir=source.parent,
            mermaid_mode="skip" if args.skip_mermaid else "required", mmdc=mmdc)
        graphics.write_text(transformed, encoding="utf-8")
        write_json(out / "VISUALES.json", visuals)
        run["stages"].append({"stage": "visuals", "status": visuals.get("status"), "counts": visuals.get("counts")})
        print("[3/6] HTML editable y PDF", flush=True)
        document, expected, layout = build_document(transformed, out, source_dir=source.parent,
            filename=source.name, family=args.family)
        html_path.write_text(document, encoding="utf-8")
        expected_path.write_text(expected, encoding="utf-8")
        layout.update(render_pdf(html_path, pdf, args.engine, args.browser_no_sandbox))
        layout["html_sha256"] = sha256(html_path)
        layout["expected_text_sha256"] = sha256(expected_path)
        write_json(out / "MAQUETACION.json", layout)
        run["pdf"] = pdf.name
        run["pdf_sha256"] = sha256(pdf)
        run["stages"].append({"stage": "layout", "status": "GENERATED", "engine": layout["engine"]})
        print("[4/6] Auditoría textual y conservación de texto", flush=True)
        audit = audit_pdf(pdf, expected_text=expected, patterns_path=args.patterns)
        write_json(out / "AUDITORIA.json", audit)
        (out / "AUDITORIA.md").write_text(audit_markdown(audit), encoding="utf-8")
        audit_ok = audit.get("TEXT_AUDIT") == "PASS" and audit.get("CONTENT_CHECK") == "PASS"
        run["stages"].append({"stage": "audit", "status": "AUTOMATIC_CHECKS_PASSED" if audit_ok else "FAIL"})
        print("[5/6] Páginas para revisión visual", flush=True)
        preview = make_preview(pdf, visual_dir, pages=args.pages)
        write_json(out / "VISTAS.json", preview)
        run["review_checkpoints"] = [
            {"when": "after_render", "action": "Inspeccionar portada, índice, estructuras visuales y todas las páginas."},
            {"when": "after_changes", "action": "Regenerar auditoría y vistas; el recibo anterior no aprueba un PDF con otro hash."},
            {"when": "before_final_delivery", "action": "Registrar revisión explícita con 09_registrar_revision_visual.py y cerrar con 10_cerrar_entrega.py."},
        ]
        run["stages"].append({"stage": "preview", "status": "GENERATED", "review": "NOT_RUN"})
        if not audit_ok:
            raise RuntimeError("La auditoría automática no ha superado todos los controles; consulta AUDITORIA.json y las páginas de verificacion_visual.")
        run["status"] = "AUTOMATIC_CHECKS_PASSED"
        if visuals.get("counts", {}).get("SKIPPED", 0) or not layout.get("toc_page_numbers", False):
            run["status"] = "GENERATED_WITH_LIMITATIONS"
        run["generation_files"] = {
            path.relative_to(out).as_posix(): sha256(path)
            for path in sorted(out.rglob("*"))
            if path.is_file() and path != run_path and path.suffix.lower() != ".zip"
        }
        run["finished_at"] = datetime.now(timezone.utc).isoformat()
        write_json(run_path, run)
        print("[6/6] Paquete reproducible con inventario SHA-256", flush=True)
        package = out / f"{base}_BORRADOR.zip"
        package_files(package, sorted(path for path in out.rglob("*") if path.is_file() and path != package), root=out)
        print(f"{run['status']} -> {package}\nREVISIÓN VISUAL: NOT_RUN. Las imágenes generadas deben revisarse.", flush=True)
        return 0
    except VisualRenderError as exc:
        write_json(out / "VISUALES.json", exc.report)
        if hasattr(exc, "transformed_markdown"):
            graphics.write_text(exc.transformed_markdown, encoding="utf-8")
        run["error"] = str(exc)
    except Exception as exc:
        run["error"] = str(exc)
    run["status"] = "FAILED"
    run["finished_at"] = datetime.now(timezone.utc).isoformat()
    write_json(run_path, run)
    print("FAILED: " + run["error"], file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
