"""Regression checks for evidence semantics and delivery completeness.

PDF page objects are simulated here; these tests do not claim PDF rendering.
The integration demo exercises real PDF generation separately.
"""
from __future__ import annotations
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import fitz
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "02_SCRIPTS"))
from ialp.quality import audit_pdf, compare_text, make_preview, package_files, parse_pages


class FakePixmap:
    def save(self, path):
        Image.new("RGB", (40, 60), "white").save(path)


class FakePage:
    rect = fitz.Rect(0, 0, 595, 842)

    def __init__(self, text="", *, header_only=False, images=0, vectors=False):
        self.text, self.header_only, self.images, self.vectors = text, header_only, images, vectors

    def get_text(self, kind):
        if kind == "text":
            return self.text
        if kind == "blocks":
            y = 15 if self.header_only else 100
            return [(30, y, 550, y + 15, self.text, 0, 0)] if self.text else []
        raise AssertionError(kind)

    def get_image_info(self):
        return [{}] * self.images

    def get_drawings(self):
        return [{"rect": fitz.Rect(50, 100, 250, 300)}] if self.vectors else []

    def get_pixmap(self, **kwargs):
        return FakePixmap()


class FakeDoc(list):
    needs_pass = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


class QualityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "simulated-document.data"
        self.source.write_bytes(b"This file is hashed only; PDF objects are mocked.")
        self.patterns = self.root / "patterns.txt"
        self.patterns.write_text("# No forbidden expressions for this fixture\n", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def audited(self, pages, expected=None):
        with patch("ialp.quality.fitz.open", return_value=FakeDoc(pages)):
            return audit_pdf(self.source, expected, self.patterns)

    def test_empty_pages_no_longer_pass(self):
        result = self.audited([FakePage(), FakePage(), FakePage()])
        self.assertEqual(result["TEXT_AUDIT"], "FAIL")
        self.assertEqual(result["findings"]["empty_pages"], [1, 2, 3])
        self.assertEqual(result["CONTENT_CHECK"], "NOT_RUN")
        self.assertEqual(result["VISUAL_REVIEW"], "NOT_RUN")

    def test_headers_do_not_make_an_empty_body_pass(self):
        result = self.audited([FakePage("IA. LA PREGUNTA Página 3 de 3", header_only=True)])
        self.assertEqual(result["TEXT_AUDIT"], "FAIL")

    def test_image_or_vector_page_is_not_a_blank_page(self):
        result = self.audited([FakePage(images=1), FakePage(vectors=True)])
        self.assertEqual(result["TEXT_AUDIT"], "PASS")
        self.assertEqual(result["CONTENT_CHECK"], "NOT_RUN")
        self.assertEqual(result["VISUAL_REVIEW"], "NOT_RUN")

    def test_missing_repeated_word_fails_coverage(self):
        result = self.audited([FakePage("alpha beta gamma")], "alpha beta beta gamma")
        self.assertEqual(result["TEXT_AUDIT"], "PASS")
        self.assertEqual(result["CONTENT_CHECK"], "FAIL")
        self.assertIn({"token": "beta", "count": 1}, result["content"]["missing_tokens"])

    def test_reordered_content_fails_coverage(self):
        result = compare_text("alpha beta gamma", "alpha gamma beta")
        self.assertEqual(result["missing_tokens"], [])
        self.assertFalse(result["ordered_subsequence"])
        self.assertEqual(result["status"], "FAIL")

    def test_math_operators_are_not_discarded(self):
        self.assertEqual(compare_text("A ≠ B", "A = B")["status"], "FAIL")

    def test_ligature_and_line_hyphen_normalization(self):
        result = compare_text("Financiación eficiente", "Cabecera\nFinan\u00ad\nciación eﬁciente\nPágina 1")
        self.assertEqual(result["status"], "PASS")

    def test_real_hyphen_is_preserved_when_line_wraps(self):
        for hyphen in ("-", "\u2010"):
            with self.subTest(hyphen=hyphen):
                self.assertEqual(compare_text("técnico-editorial", f"técnico{hyphen}\neditorial")["status"], "PASS")
                self.assertEqual(compare_text("conservación", f"conser{hyphen}\nvación")["status"], "PASS")
                self.assertEqual(compare_text("Markdown", f"Mark{hyphen}\ndown")["status"], "PASS")
                self.assertEqual(compare_text("técnico-editorial", "técnicoeditorial")["status"], "FAIL")

    def test_empty_expected_text_is_not_verification(self):
        self.assertEqual(compare_text("", "contenido")["status"], "FAIL")

    def test_pattern_hits_are_bound_to_pages(self):
        self.patterns.write_text("DICTAMEN\\s+INTERNO\n", encoding="utf-8")
        result = self.audited([FakePage("Contenido"), FakePage("Dictamen interno")])
        self.assertEqual(result["TEXT_AUDIT"], "FAIL")
        self.assertEqual(result["findings"]["pattern_hits"][0]["page"], 2)

    def test_pages_all_sample_and_explicit(self):
        self.assertEqual(parse_pages("all", 3), [0, 1, 2])
        self.assertEqual(parse_pages("sample", 105), [0, 1, 26, 52, 78, 103, 104])
        self.assertEqual(parse_pages("1,2,-1,1", 4), [0, 1, 3])
        with self.assertRaises(ValueError):
            parse_pages("0", 4)
        with self.assertRaises(ValueError):
            parse_pages("5", 4)

    def test_preview_generation_is_not_visual_acceptance(self):
        with patch("ialp.quality.fitz.open", return_value=FakeDoc([FakePage("a"), FakePage("b")])):
            receipt = make_preview(self.source, self.root / "preview", dpi=36)
        self.assertEqual(receipt["selected_pages"], [1, 2])
        self.assertEqual(receipt["coverage"], "ALL_PAGES")
        self.assertEqual(receipt["VISUAL_REVIEW"], "NOT_RUN")
        self.assertEqual(receipt["status"], "PREVIEW_GENERATED")
        for record in receipt["images"]:
            payload = (self.root / "preview" / record["path"]).read_bytes()
            self.assertEqual(record["sha256"], sha256(payload).hexdigest())

    def test_preview_rerun_removes_only_its_registered_stale_pages(self):
        out = self.root / "preview"
        with patch("ialp.quality.fitz.open", return_value=FakeDoc([FakePage("a"), FakePage("b")])):
            make_preview(self.source, out, dpi=36)
        unrelated = out / "user-note.txt"
        unrelated.write_text("keep")
        with patch("ialp.quality.fitz.open", return_value=FakeDoc([FakePage("a")])):
            result = make_preview(self.source, out, dpi=36)
        self.assertEqual(result["selected_pages"], [1])
        self.assertFalse((out / "page-002.png").exists())
        self.assertEqual(unrelated.read_text(), "keep")

    def test_missing_requested_file_preserves_existing_archive(self):
        target = self.root / "delivery.zip"
        target.write_bytes(b"previous known archive")
        with self.assertRaises(FileNotFoundError):
            package_files(target, [self.source, self.root / "missing.pdf"])
        self.assertEqual(target.read_bytes(), b"previous known archive")

    def test_empty_deliveries_fail(self):
        with self.assertRaises(ValueError):
            package_files(self.root / "empty.zip", [])
        empty = self.root / "empty"
        empty.mkdir()
        with self.assertRaises(ValueError):
            package_files(self.root / "empty.zip", [empty])

    def test_archive_hashes_and_paths_match_real_payloads(self):
        assets = self.root / "assets"
        assets.mkdir()
        picture = assets / "figure.svg"
        picture.write_text("<svg/>", encoding="utf-8")
        target = self.root / "delivery.zip"
        result = package_files(target, [self.source, assets], root=self.root)
        with zipfile.ZipFile(target) as archive:
            manifest = json.loads(archive.read("MANIFEST.json"))
            self.assertEqual(manifest, result)
            self.assertEqual({entry["path"] for entry in manifest["files"]},
                             {"simulated-document.data", "assets/figure.svg"})
            self.assertEqual(len(archive.namelist()), len(manifest["files"]) + 1)
            for entry in manifest["files"]:
                payload = archive.read(entry["path"])
                self.assertEqual(entry["bytes"], len(payload))
                self.assertEqual(entry["sha256"], sha256(payload).hexdigest())

    def test_packages_are_byte_deterministic(self):
        a, b = self.root / "a.zip", self.root / "b.zip"
        package_files(a, [self.source])
        package_files(b, [self.source])
        self.assertEqual(a.read_bytes(), b.read_bytes())

    def test_self_inclusion_is_rejected(self):
        target = self.root / "delivery.zip"
        target.write_bytes(b"existing")
        with self.assertRaises(ValueError):
            package_files(target, [target])

    def test_portable_case_collision_is_rejected(self):
        a, b = self.root / "A.txt", self.root / "a.txt"
        a.write_text("one")
        b.write_text("two")
        if a.samefile(b):
            self.skipTest("Filesystem is case-insensitive")
        with self.assertRaises(ValueError):
            package_files(self.root / "collision.zip", [a, b])

    def test_symlink_is_rejected(self):
        link = self.root / "link"
        try:
            link.symlink_to(self.source)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks unavailable on this platform")
        with self.assertRaises(ValueError):
            package_files(self.root / "links.zip", [link])

    def test_symlink_parent_is_rejected(self):
        directory = self.root / "directory"
        directory.mkdir()
        (directory / "data.txt").write_text("text")
        link = self.root / "linked-directory"
        try:
            link.symlink_to(directory, target_is_directory=True)
        except (OSError, NotImplementedError):
            self.skipTest("Symlinks unavailable on this platform")
        with self.assertRaises(ValueError):
            package_files(self.root / "linked.zip", [link / "data.txt"])

    def test_root_escape_is_rejected(self):
        only_assets = self.root / "assets"
        only_assets.mkdir()
        with self.assertRaises(ValueError):
            package_files(self.root / "escape.zip", [self.source], root=only_assets)

    def test_packager_cli_propagates_missing_file(self):
        script = Path(__file__).resolve().parents[1] / "02_SCRIPTS" / "06_empaquetar_entrega.py"
        result = subprocess.run([sys.executable, str(script), str(self.root / "no.zip"),
                                 str(self.root / "missing.pdf")], capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertFalse((self.root / "no.zip").exists())
        self.assertIn("Falta un entregable", result.stderr)


if __name__ == "__main__":
    unittest.main()
