#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Limpieza reversible: explicit por defecto; legacy requiere selección expresa.

legacy conserva la retirada histórica de metadatos/secciones, respetando código.
Puede retirar contenido publicable: revise el registro JSON antes de usarlo.
No se normalizan espacios, CRLF, saltos Markdown ni instrucciones \\newpage.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from ialp.source import MODES, clean_source


def read_heading_names(path: Path) -> list[str]:
    return [line.strip().lower() for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")]


def clean(text: str, control_names: list[str] | None = None, mode: str = "explicit") -> str:
    """Compatibility helper; historical removal requires mode='legacy'."""
    return clean_source(text, mode=mode, names=control_names)[0]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--mode", choices=MODES, default="explicit")
    parser.add_argument("--headings", help="Lista heredada de títulos, utilizada solo con legacy.")
    parser.add_argument("--report", help="Registro JSON; por defecto OUTPUT.cleaning.json.")
    args = parser.parse_args()
    source, output = Path(args.source).resolve(), Path(args.output).resolve()
    report_path = Path(args.report).resolve() if args.report else output.with_name(output.name + ".cleaning.json")
    try:
        if len({source, output, report_path}) != 3:
            raise ValueError("Fuente, salida e informe deben tener rutas distintas.")
        root = Path(__file__).resolve().parents[1]
        names = []
        if args.mode == "legacy":
            names = read_heading_names(Path(args.headings) if args.headings else root / "05_CONFIG" / "encabezados_control.txt")
        text = source.read_bytes().decode("utf-8")
        cleaned, report = clean_source(text, mode=args.mode, names=names)
        report.update(source_path=str(source), output_path=str(output))
        output.parent.mkdir(parents=True, exist_ok=True)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(cleaned.encode("utf-8"))
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except (OSError, UnicodeError, ValueError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(f"OK: {output} | modo={args.mode} | retiradas={report['removed_count']} | registro={report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
