#!/usr/bin/env python3
"""Auditoría textual acotada; la revisión visual conserva un estado separado."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from ialp.quality import audit_markdown, audit_pdf


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf")
    parser.add_argument("--patterns", default=None)
    parser.add_argument("--report", default=None, help="Informe Markdown")
    parser.add_argument("--json", default=None, help="Informe JSON estructurado")
    parser.add_argument("--expected-text", default=None, help="Archivo UTF-8 con texto esperado")
    parser.add_argument("--sparse-threshold", type=int, default=45)
    args = parser.parse_args()
    try:
        result = audit_pdf(args.pdf, Path(args.expected_text) if args.expected_text else None,
                           args.patterns, sparse_threshold=args.sparse_threshold)
        markdown = audit_markdown(result)
        if args.report:
            target = Path(args.report)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(markdown, encoding="utf-8")
        if args.json:
            target = Path(args.json)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(markdown)
        return 2 if result["automatic_status"] == "FAIL" else 0
    except Exception as exc:
        print(f"ERROR: auditoría no completada: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
