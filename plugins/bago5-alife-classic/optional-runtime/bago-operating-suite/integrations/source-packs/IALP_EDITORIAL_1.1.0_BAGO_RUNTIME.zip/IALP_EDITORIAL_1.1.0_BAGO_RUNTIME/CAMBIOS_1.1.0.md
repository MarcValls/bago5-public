# IALP 1.1.0 — cambios y alcance

Esta edición extiende el kit recibido y utiliza su propio manual como demostración de producción. El archivo ZIP original v1.0 se conserva como referencia; su huella y la comparación de archivos constan en `08_EVIDENCIAS`.

## Conservación y estructura

- Limpieza explícita por defecto y modo histórico optativo. Código cercado, espacios Markdown, CRLF y saltos de página permanecen protegidos.
- Registro íntegro de las retiradas y comprobación de reconstrucción exacta de la entrada.
- Frontmatter YAML validado. Metadatos, portada y las tres familias editoriales permanecen disponibles.
- Índice basado en el parser Markdown, identificadores únicos y profundidad configurable con `toc_depth` de 1 a 3.
- Plantillas Jinja2, HTML editable y fuentes DejaVu distribuidas con su licencia.

## Estructuras visuales y hojas

- Mermaid CLI con SVG, informe por bloque y propagación de fallos. La omisión exige `--skip-mermaid` y queda registrada.
- Graphviz nativo para grafos y mapas conceptuales.
- Barras, líneas y matrices de calor a partir de JSON, mediante Matplotlib.
- Lectura de rangos XLSX con openpyxl y conservación del libro de entrada.
- Generación de XLSX editables con XlsxWriter, fuentes JSON y fórmulas explícitas con resultado suministrado.
- Recursos locales copiados, referencias relativas y HTML portable.

## Comprobación y cierre

- Separación de auditoría textual, comparación de contenido, generación de vistas e inspección visual.
- Vistas de todas las páginas por defecto; registro explícito de páginas inspeccionadas y siete grupos de comprobación.
- Revisión ligada por SHA-256 al PDF y a la evidencia. Un cambio posterior invalida la aprobación anterior.
- ZIP de borrador tras la generación; cierre final separado que exige revisión completa vigente y verifica los archivos de la generación.
- Empaquetado atómico, entradas obligatorias, inventario y reproducibilidad binaria para entradas idénticas.
- Adaptador PowerShell que transmite errores en lugar de continuar con un éxito aparente.

## Defectos corregidos durante la integración

El ensayo del manual detectó un SVG Mermaid con tamaño porcentual que excedía la página, un índice con unas pocas entradas aisladas y falsos avisos de cobertura por guiones tipográficos de final de línea. Se ajustaron dimensiones y composición, y se amplió la normalización del guion U+2010 con una prueba que sigue protegiendo guiones semánticos. Los resultados y la revisión final figuran en `08_EVIDENCIAS` y en la salida del manual.

## Límites declarados

La verificación de esta edición corresponde al entorno Linux registrado. Windows, macOS y el motor alternativo de navegador no han sido ejecutados. Los bloques matemáticos no se convierten a LaTeX compuesto; los mapas geográficos y la exportación fiel de Excel a PDF no están implementados. La lectura de hojas utiliza resultados guardados y no recalcula fórmulas. No se declara conformidad PDF/A o PDF/UA.

El informe histórico del volumen 13 se conserva como antecedente recibido, sin usarlo para acreditar esta edición. Las comprobaciones de texto y hashes no sustituyen una inspección visual ni prueban equivalencia semántica.
