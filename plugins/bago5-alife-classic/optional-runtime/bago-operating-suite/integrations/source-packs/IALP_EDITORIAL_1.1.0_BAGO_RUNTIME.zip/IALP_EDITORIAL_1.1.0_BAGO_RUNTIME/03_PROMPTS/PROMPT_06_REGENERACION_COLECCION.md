# PROMPT — REGENERAR COLECCIÓN COMPLETA SIN REGRESIÓN

Regenera una colección desde sus fuentes editoriales. Conserva el contenido validado y distingue el estado de cada volumen del estado de la colección completa.

## Fuente e identidad

- Usa la fuente editable más avanzada y autorizada. No sustituyas un Markdown disponible por un PDF reparado como punto de partida.
- Conserva original, recursos, huellas y registro de cambios de cada volumen.
- Mantén títulos, símbolos, fórmulas, tablas y contenido conceptual sin reabrir doctrina.
- Aplica la identidad común y la familia adecuada: `puerta`, `doctrina` o `sintesis`.
- Usa limpieza `explicit` o `preserve` según corresponda. Activa `legacy` solo de forma expresa y revisa cada eliminación; no retires contenido legítimo por nombres de encabezados o palabras aisladas.

## Generación por volumen

Trabaja en una salida nueva o vacía por volumen y por iteración. Genera con WeasyPrint, conserva fuentes y recursos de los visuales, ejecuta la auditoría y produce vistas de todas las páginas. Registra errores y limitaciones de cada ejecución sin trasladar el resultado de un volumen a otro.

Si hay correcciones, conserva la ejecución anterior y repite generación, auditoría y comprobación visual completa. Comprueba el índice, el inicio y el final de todos los capítulos; la continuidad del texto; tablas y gráficos; cabeceras, pies y paginación.

## Revisión de la colección

Inspecciona todas las páginas de cada PDF final y registra un `REVISION_VISUAL.json` para cada archivo y su SHA-256. Después prepara un contact sheet conjunto de portadas, índices y páginas finales para comparar la identidad entre volúmenes. Esa comparación complementa la inspección completa; no la sustituye.

Mantén una tabla por volumen con fuente, PDF, hash, controles automáticos, cobertura visual, revisor real, recibo y bloqueos. No atribuyas revisiones del agente al usuario.

## Cierre

Cierra cada entrega con `10_cerrar_entrega.py` solo cuando los controles y la revisión completa estén aprobados. Una ejecución con `SKIPPED`, una revisión parcial, una evidencia obsoleta o un fallo en cualquier volumen impide presentar la colección completa como final. Los borradores y los volúmenes cerrados deben conservar su estado individual real.
