"""Real XLSX contract tests; no office application or formula evaluation implied."""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "02_SCRIPTS"
sys.path.insert(0, str(SCRIPTS))
from ialp.workbook import WorkbookSpecError, create_workbook, validate_workbook_spec
from ialp.visuals import render_visuals


def _spec():
    return {
        "title": "Datos de demostración",
        "sheets": [{
            "name": "Resumen",
            "columns": [
                {"header": "Capacidad", "width": 28, "format": "text"},
                {"header": "Casos", "width": 14, "format": "integer"},
                {"header": "Cobertura", "width": 16, "format": "percent"},
            ],
            "rows": [["Markdown", 8, 1.0], ["Mermaid", 2, 0.5]],
            "freeze_header": True,
        }],
    }


def test_real_xlsx_preserves_typed_data_formats_controls_and_source(tmp_path):
    pytest.importorskip("xlsxwriter")
    openpyxl = pytest.importorskip("openpyxl")
    spec = _spec()
    raw = (json.dumps(spec, ensure_ascii=False, indent=3) + "\n\n").encode("utf-8")
    output = tmp_path / "datos.xlsx"
    report = create_workbook(spec, output, source_bytes=raw)
    workbook = openpyxl.load_workbook(output, data_only=False)
    sheet = workbook["Resumen"]
    assert sheet["A1"].value == "Capacidad"
    assert sheet["B2"].value == 8 and sheet["B2"].data_type == "n"
    assert sheet["C3"].value == 0.5 and sheet["C3"].number_format == "0.0%"
    assert sheet["A1"].font.bold
    assert sheet["A1"].fill.fgColor.rgb.endswith("173D57")
    assert sheet.freeze_panes == "A2"
    assert sheet.auto_filter.ref == "A1:C3"
    assert not sheet.sheet_view.showGridLines
    assert Path(report["source_copy_path"]).read_bytes() == raw
    assert report["source_sha256"] == hashlib.sha256(raw).hexdigest()
    assert report["output_sha256"] == hashlib.sha256(output.read_bytes()).hexdigest()
    workbook.close()


def test_literal_formula_and_url_stay_plain_text(tmp_path):
    pytest.importorskip("xlsxwriter")
    openpyxl = pytest.importorskip("openpyxl")
    spec = _spec()
    spec["sheets"][0]["rows"][0][0] = "=SUM(1,2)"
    spec["sheets"][0]["rows"][1][0] = "https://example.invalid/"
    create_workbook(spec, tmp_path / "text.xlsx")
    workbook = openpyxl.load_workbook(tmp_path / "text.xlsx")
    assert workbook.active["A2"].data_type == "s"
    assert workbook.active["A2"].value == "=SUM(1,2)"
    assert workbook.active["A3"].hyperlink is None
    workbook.close()


def test_explicit_formula_keeps_supplied_cache_without_recalculation(tmp_path):
    pytest.importorskip("xlsxwriter")
    openpyxl = pytest.importorskip("openpyxl")
    spec = _spec()
    # Deliberately inconsistent cache proves no hidden evaluation is claimed.
    spec["sheets"][0]["rows"][0][1] = {"formula": "=1+1", "result": 99}
    output = tmp_path / "cached.xlsx"
    report = create_workbook(spec, output)
    formulas = openpyxl.load_workbook(output, data_only=False)
    values = openpyxl.load_workbook(output, data_only=True)
    assert formulas.active["B2"].value == "=1+1"
    assert values.active["B2"].value == 99
    assert report["sheets"][0]["explicit_formulas"] == 1
    assert "not calculated" in report["formula_policy"]
    formulas.close()
    values.close()


def test_created_workbook_can_feed_spreadsheet_visual(tmp_path):
    pytest.importorskip("xlsxwriter")
    pytest.importorskip("openpyxl")
    source = tmp_path / "source"
    source.mkdir()
    spec = _spec()
    spec["sheets"][0]["rows"].append(["Total", {"formula": "=SUM(B2:B3)", "result": 10}, None])
    create_workbook(spec, source / "datos.xlsx")
    markdown = '```spreadsheet\n{"path":"datos.xlsx","sheet":"Resumen","range":"A1:C4"}\n```\n'
    output, report = render_visuals(markdown, tmp_path / "rendered", source_dir=source)
    assert "| Total | 10 |  |" in output
    assert report["counts"]["RENDERED"] == 1
    assert report["items"][0]["formulas_with_cached_values"] == 1


@pytest.mark.parametrize("mutation", [
    lambda spec: spec["sheets"].append(deepcopy(spec["sheets"][0])),
    lambda spec: spec["sheets"][0].update(name="No/valido"),
    lambda spec: spec["sheets"][0]["columns"][0].update(format="date"),
    lambda spec: spec["sheets"][0]["columns"][0].update(width=0),
    lambda spec: spec["sheets"][0]["rows"].append(["Falta una columna", 1]),
    lambda spec: spec["sheets"][0]["rows"][0].__setitem__(1, {"formula": "=1+1"}),
    lambda spec: spec["sheets"][0]["rows"][0].__setitem__(1, {"formula": "=1+1", "result": True}),
    lambda spec: spec["sheets"][0]["rows"][0].__setitem__(1, float("nan")),
])
def test_invalid_spec_does_not_replace_existing_output(tmp_path, mutation):
    spec = _spec()
    mutation(spec)
    output = tmp_path / "existing.xlsx"
    output.write_bytes(b"existing workbook remains untouched")
    with pytest.raises(WorkbookSpecError):
        create_workbook(spec, output)
    assert output.read_bytes() == b"existing workbook remains untouched"
    assert not list(tmp_path.glob(".ialp-*"))


def test_source_bytes_must_match_validated_spec(tmp_path):
    with pytest.raises(WorkbookSpecError, match="no corresponden"):
        create_workbook(_spec(), tmp_path / "mismatch.xlsx", source_bytes=b"{}")
    assert not (tmp_path / "mismatch.xlsx").exists()


def test_output_path_must_be_xlsx(tmp_path):
    with pytest.raises(WorkbookSpecError, match=".xlsx"):
        create_workbook(_spec(), tmp_path / "mistake.json")
    assert not (tmp_path / "mistake.json").exists()


def test_cli_records_hash_report_after_success(tmp_path):
    pytest.importorskip("xlsxwriter")
    source, output, report = tmp_path / "data.json", tmp_path / "data.xlsx", tmp_path / "report.json"
    source.write_text(json.dumps(_spec(), ensure_ascii=False), encoding="utf-8")
    original = source.read_bytes()
    result = subprocess.run([sys.executable, str(SCRIPTS / "08_crear_hoja.py"), str(source), str(output), "--report", str(report)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert "CREATED" in result.stdout
    data = json.loads(report.read_text(encoding="utf-8"))
    assert data["status"] == "CREATED"
    assert source.read_bytes() == original
    assert data["output_sha256"] == hashlib.sha256(output.read_bytes()).hexdigest()


def test_cli_failure_never_prints_success_or_overwrites_source(tmp_path):
    source = tmp_path / "invalid.json"
    source.write_text('{"sheets":[]}', encoding="utf-8")
    output = tmp_path / "output.xlsx"
    result = subprocess.run([sys.executable, str(SCRIPTS / "08_crear_hoja.py"), str(source), str(output)], capture_output=True, text=True)
    assert result.returncode == 2
    assert "FAILED" in result.stderr
    assert "CREATED" not in result.stdout
    assert not output.exists()
    assert source.read_text(encoding="utf-8") == '{"sheets":[]}'


def test_cli_cannot_overwrite_source_with_report(tmp_path):
    source = tmp_path / "input.json"
    source.write_text(json.dumps(_spec()), encoding="utf-8")
    original = source.read_bytes()
    result = subprocess.run([sys.executable, str(SCRIPTS / "08_crear_hoja.py"), str(source), str(tmp_path / "out.xlsx"), "--report", str(source)], capture_output=True, text=True)
    assert result.returncode == 2
    assert source.read_bytes() == original
    assert not (tmp_path / "out.xlsx").exists()
