# PROMPT — QA VISUAL DEL PDF

Revisa el PDF renderizado como un editor de producción. Haz la comprobación tras el render, tras cualquier corrección y de nuevo sobre la versión exacta que se cerrará. La mera generación de PNG o de un contact sheet deja la revisión en `NOT_RUN`.

## Cobertura obligatoria

Inspecciona todas las páginas del PDF final, una a una y a tamaño legible. Usa los contact sheets para localizar patrones, comparar continuidad y detectar anomalías; amplía las páginas para evaluar texto pequeño, tablas y etiquetas. Una muestra de portada, índice, páginas intermedias y final no aprueba las páginas omitidas.

Comprueba especialmente portada, todas las páginas del índice, primera página del cuerpo, tablas, cuadrículas, diagramas, fórmulas o código, cambios de capítulo, penúltima y última página. Anota el número real de cada página afectada.

## Checklist de registro

Cumplimenta una copia de `05_CONFIG/CHECKLIST_VISUAL.json`, con las siete claves:

- `portada`: título completo, jerarquía y composición.
- `indice`: legibilidad, entradas, enlaces y correspondencia con páginas reales.
- `cortes_desbordes`: texto e imágenes íntegros, márgenes y ausencia de solapamientos.
- `diagramas_etiquetas`: nodos, conectores y etiquetas completos y legibles.
- `tablas_cuadriculas`: filas, columnas, cortes, alineación y cabeceras.
- `cabeceras_pies`: contenido, numeración, continuidad y ausencia de superposiciones.
- `fuentes_contraste`: tamaños, glifos, símbolos, contraste y consistencia tipográfica.

Cada entrada contiene `status` y `notes`. Usa `PASS` solo para una comprobación realizada; `FAIL` para un defecto; `NOT_RUN` para lo pendiente y `NOT_APPLICABLE` cuando no exista ese elemento, indicando el motivo. Tanto `FAIL` como `NOT_APPLICABLE` necesitan una explicación. No marques toda la plantilla como aprobada por haber abierto unas pocas páginas.

Comprueba además la continuidad del contenido, el final del último capítulo o anexo, las páginas casi vacías accidentales y las notas de producción ajenas al documento. Distingue esas notas de ejemplos técnicos deliberados del manual.

## Hallazgos y correcciones

Devuelve hallazgos P0, P1 y P2 con página, descripción, evidencia y acción. P0 es un fallo crítico; P1, un defecto que impide entregar; P2, una observación menor que debe quedar descrita. P0 o P1 obliga a corregir y regenerar. En el registro JSON, traduce los bloqueos a `severity: ERROR`; los niveles P0/P1/P2 son la clasificación editorial, no valores aceptados por la CLI.

Después de cualquier corrección, conserva la ejecución anterior, genera nuevas auditorías y vistas, e inspecciona todas las páginas de la versión final. No reutilices como aprobación el recibo de un PDF con otro SHA-256.

## Declaración trazable

Identifica a quien realmente inspeccionó las páginas y registra su veredicto con `09_registrar_revision_visual.py`. Usa `--pages all` únicamente después de revisar la totalidad. Si la revisión la realiza un agente, identifica al agente; no la atribuyas al usuario ni inventes una firma humana.

El recibo `REVISION_VISUAL.json` vincula PDF, auditoría, vistas y ejecución mediante SHA-256. Las huellas detectan cambios en archivos; no prueban que alguien los haya observado. Valida de nuevo el recibo antes de cerrar. Una revisión parcial, un ítem pendiente, un error o una ejecución con limitaciones bloquean la elegibilidad final.
