#!/usr/bin/env python3
"""Empaqueta entregables completos con un inventario SHA-256."""
from __future__ import annotations
import argparse
import sys
from ialp.quality import package_files


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("zip")
    parser.add_argument("files", nargs="+")
    parser.add_argument("--root", default=None, help="Raíz que define las rutas dentro del ZIP")
    args = parser.parse_args()
    try:
        manifest = package_files(args.zip, args.files, args.root)
        print(f"PACKAGED: {args.zip} | {len(manifest['files'])} archivos + MANIFEST.json")
        return 0
    except Exception as exc:
        print(f"ERROR: entrega no empaquetada: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
