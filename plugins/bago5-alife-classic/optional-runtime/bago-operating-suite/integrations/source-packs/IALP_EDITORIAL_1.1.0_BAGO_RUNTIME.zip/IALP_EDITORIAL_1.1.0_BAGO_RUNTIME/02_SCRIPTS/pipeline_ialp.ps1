param(
    [Parameter(Mandatory=$true)][string]$InputMd,
    [string]$OutDir = "IALP_OUT",
    [switch]$SkipMermaid,
    [ValidateSet("preserve", "explicit", "legacy")][string]$CleanMode = "explicit",
    [ValidateSet("auto", "puerta", "doctrina", "sintesis")][string]$Family = "auto"
)
$ErrorActionPreference = "Stop"
$pipelineScript = Join-Path $PSScriptRoot "07_pipeline_ialp.py"
$pipelineArgs = @($pipelineScript, $InputMd, "--outdir", $OutDir, "--clean-mode", $CleanMode, "--family", $Family)
if ($SkipMermaid) { $pipelineArgs += "--skip-mermaid" }
& python @pipelineArgs
$pipelineExit = $LASTEXITCODE
if ($pipelineExit -ne 0) { Write-Error "El pipeline terminó con código $pipelineExit" -ErrorAction Continue }
exit $pipelineExit
