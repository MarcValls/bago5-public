# PROMPT — VALIDACIÓN FINAL DE ENTREGA

Antes de cerrar la entrega, comprueba la versión final y sus evidencias. Mantén separados los controles automáticos, la inspección visual y la aprobación conceptual del contenido.

## Condiciones de cierre

1. El PDF abre y su SHA-256 coincide con auditoría, vistas, ejecución y recibo de revisión.
2. El índice corresponde a encabezados y páginas reales; los enlaces y recursos están presentes.
3. `TEXT_AUDIT` y `CONTENT_CHECK` han superado sus controles. Contrasta sus resultados con el contenido esperado y revisa las limitaciones de una comparación automática: no acredita por sí sola significado, diseño ni legibilidad.
4. La fuente original, los cambios de limpieza y la fuente realmente maquetada están conservados. No hay eliminaciones o alteraciones silenciosas.
5. Los visuales requeridos están renderizados y sus fuentes y datos son trazables. Un bloque `SKIPPED`, una dependencia ausente o una limitación pendiente impide presentar el paquete como entrega final.
6. Se han inspeccionado todas las páginas tras el render y tras las correcciones. No hay cortes, desbordes, glifos dañados, tablas ilegibles ni páginas accidentales casi vacías. El último capítulo o anexo termina completo.
7. `REVISION_VISUAL.json` identifica al revisor real, declara todas las páginas y contiene el checklist completo. No quedan errores ni comprobaciones pendientes; cualquier `NOT_APPLICABLE` está justificado.
8. Justo antes del cierre, se valida otra vez la revisión contra los archivos actuales. No se ha sustituido el PDF ni una evidencia desde la inspección.
9. El paquete conserva PDF, HTML y recursos, fuentes, datos, informes, vistas y recibo; el inventario registra rutas y SHA-256. No falta ningún archivo solicitado ni se incluyen salidas obsoletas de otra ejecución como evidencia de esta.

## Procedimiento y estados

La generación normal termina en `_BORRADOR.zip`. `RUN.json` puede declarar `AUTOMATIC_CHECKS_PASSED`, mientras `visual_review` continúa en `NOT_RUN`: ese estado histórico describe la ejecución inicial y no debe editarse a mano.

Registra la inspección mediante `09_registrar_revision_visual.py`. Después usa `10_cerrar_entrega.py` para obtener `_ENTREGA.zip` y `ENTREGA.json` cuando se cumplan sus condiciones. El cierre no modifica el registro original de ejecución. No renombres un borrador para simular el cierre.

Si una condición no se ha comprobado, registra su estado real y conserva el borrador con los bloqueos. No declares una entrega final `PASS` por la mera creación del PDF, por una auditoría textual o por una muestra de páginas. Nunca atribuyas al usuario una revisión realizada por un agente.
