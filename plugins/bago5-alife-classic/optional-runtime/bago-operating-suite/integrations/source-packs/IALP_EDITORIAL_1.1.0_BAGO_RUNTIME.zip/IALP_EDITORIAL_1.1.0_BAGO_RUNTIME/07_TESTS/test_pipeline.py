"""CLI integration with small, real WeasyPrint PDFs and synthetic manuscripts.

Successful runs render PDFs, audit them, rasterize previews and package drafts.
Failure cases use real missing paths, never substitute PDF byte fixtures or a
fake renderer. No test declares a human visual review or needs Node/Chromium.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from urllib.parse import unquote
from zipfile import ZipFile

import fitz

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "02_SCRIPTS"))
from ialp.layout import render_pdf

PIPELINE = ROOT / "02_SCRIPTS" / "07_pipeline_ialp.py"
FINAL_PARAGRAPH = "La última frase conserva el compromiso de revisar cada página antes de publicar."
MANUSCRIPT = (
    "---\r\ntitle: Integración breve\r\nauthor: Equipo de pruebas\r\nvolume_number: 12\r\n---\r\n"
    "# Apertura\r\n\r\nPrimer párrafo con contenido editorial suficiente para esta prueba.  \r\n"
    "Segunda línea conservada con su salto Markdown.\r\n\r\n"
    "\\newpage\r\n\r\n# Cierre\r\n\r\n" + FINAL_PARAGRAPH + "\r\n"
).encode("utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def execute_pipeline(source, output, *options):
    return subprocess.run(
        [sys.executable, "-B", str(PIPELINE), str(source), "--outdir", str(output),
         "--engine", "weasyprint", *map(str, options)],
        cwd=ROOT, capture_output=True, text=True, timeout=90,
    )


class PipelineIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shared = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.shared.cleanup)
        folder = Path(cls.shared.name)
        cls.basic_source = folder / "ensayo.md"
        cls.basic_source.write_bytes(MANUSCRIPT)
        cls.basic_output = folder / "basic_output"
        cls.basic_result = execute_pipeline(cls.basic_source, cls.basic_output)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)

    def require_success(self, result):
        self.assertEqual(result.returncode, 0, result.stdout + "\n" + result.stderr)

    def source(self, content):
        path = self.folder / "source" / "ensayo.md"
        path.parent.mkdir()
        path.write_bytes(content.encode("utf-8") if isinstance(content, str) else content)
        return path

    def test_no_visual_blocks_produces_draft_without_claiming_visual_pass(self):
        self.require_success(self.basic_result)
        out = self.basic_output
        run, audit = read_json(out / "RUN.json"), read_json(out / "AUDITORIA.json")
        self.assertEqual(run["status"], "AUTOMATIC_CHECKS_PASSED")
        self.assertEqual(run["visual_review"], "NOT_RUN")
        self.assertEqual(audit["VISUAL_REVIEW"], "NOT_RUN")
        self.assertEqual(audit["TEXT_AUDIT"], "PASS")
        self.assertEqual(audit["CONTENT_CHECK"], "PASS")
        self.assertEqual(read_json(out / "VISUALES.json")["status"], "NO_VISUALS")
        self.assertFalse(list(out.glob("*ENTREGA*.zip")))
        self.assertFalse((out / "REVISION_VISUAL.json").exists())
        drafts = list(out.glob("*_BORRADOR.zip"))
        self.assertEqual(len(drafts), 1)
        with ZipFile(drafts[0]) as bundle:
            self.assertIn("RUN.json", bundle.namelist())
            self.assertIn("ensayo_EDITORIAL.pdf", bundle.namelist())
            self.assertEqual(json.loads(bundle.read("RUN.json"))["visual_review"], "NOT_RUN")

    def test_source_bytes_and_html_remain_portable_after_relocation(self):
        source = self.source(MANUSCRIPT + b'\r\n![Figura](figura.svg)\r\n')
        resource = source.parent / "figura.svg"
        resource.write_text('<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><rect width="20" height="20" fill="navy"/></svg>', encoding="utf-8")
        original_bytes, image_bytes = source.read_bytes(), resource.read_bytes()
        out = self.folder / "output"
        self.require_success(execute_pipeline(source, out))
        self.assertEqual(source.read_bytes(), original_bytes)
        self.assertEqual((out / "ensayo_ORIGINAL.md").read_bytes(), original_bytes)
        self.assertEqual((out / "ensayo_EDITORIAL_LIMPIO.md").read_bytes(), original_bytes)
        self.assertEqual(read_json(out / "RUN.json")["source_sha256"], hashlib.sha256(original_bytes).hexdigest())
        relocated = self.folder / "relocated"
        shutil.copytree(out, relocated)
        shutil.rmtree(source.parent)
        shutil.rmtree(out)
        document = (relocated / "ensayo_EDITORIAL.html").read_text(encoding="utf-8")
        self.assertNotIn(str(source.parent), document)
        self.assertNotIn(str(out), document)
        references = re.findall(r'<img\b[^>]*\bsrc="([^"]+)"', document)
        self.assertTrue(references)
        self.assertEqual((relocated / unquote(references[0])).read_bytes(), image_bytes)
        rebuilt = relocated / "recreated.pdf"
        render_pdf(relocated / "ensayo_EDITORIAL.html", rebuilt, "weasyprint")
        with fitz.open(rebuilt) as pdf:
            self.assertIn(FINAL_PARAGRAPH, " ".join(page.get_text() for page in pdf).replace("\n", " "))

    def test_nonempty_output_is_rejected_without_overwriting_existing_files(self):
        source = self.source(MANUSCRIPT)
        out = self.folder / "output"
        out.mkdir()
        sentinel = out / "existing.txt"
        sentinel.write_bytes(b"retain existing work")
        result = execute_pipeline(source, out)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("vacía", result.stderr)
        self.assertEqual(sentinel.read_bytes(), b"retain existing work")
        self.assertEqual(list(out.iterdir()), [sentinel])

    def test_missing_resource_leaves_failed_run_without_a_package(self):
        source = self.source(MANUSCRIPT + b'\r\n![Figura](absent.png)\r\n')
        out = self.folder / "output"
        result = execute_pipeline(source, out)
        self.assertNotEqual(result.returncode, 0)
        run = read_json(out / "RUN.json")
        self.assertEqual(run["status"], "FAILED")
        self.assertIn("absent.png", run["error"])
        self.assertFalse(list(out.glob("*.zip")))
        self.assertFalse(list(out.glob("*.pdf")))
        self.assertEqual((out / "ensayo_ORIGINAL.md").read_bytes(), source.read_bytes())

    def test_required_mermaid_missing_executable_propagates_a_real_failure(self):
        source = self.source(MANUSCRIPT + b"\r\n```mermaid\r\nflowchart TD\r\n A --> B\r\n```\r\n")
        out = self.folder / "output"
        missing_command = self.folder / "nonexistent-bin" / "mmdc"
        self.assertFalse(missing_command.exists())
        result = execute_pipeline(source, out, "--mmdc", missing_command)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(read_json(out / "RUN.json")["status"], "FAILED")
        visuals = read_json(out / "VISUALES.json")
        self.assertEqual(visuals["status"], "FAILED")
        self.assertEqual(visuals["counts"]["FAILED"], 1)
        self.assertIn("mmdc", visuals["items"][0]["error"])
        self.assertIsNone(visuals["items"][0]["output_path"])
        self.assertFalse(list(out.glob("*.pdf")))
        self.assertFalse(list(out.glob("*.zip")))

    def test_explicit_mermaid_skip_renders_pdf_with_recorded_limitations(self):
        source = self.source(MANUSCRIPT + b"\r\n```mermaid\r\nflowchart TD\r\n A --> B\r\n```\r\n")
        out = self.folder / "output"
        self.require_success(execute_pipeline(source, out, "--skip-mermaid"))
        run, visuals = read_json(out / "RUN.json"), read_json(out / "VISUALES.json")
        self.assertEqual(run["status"], "GENERATED_WITH_LIMITATIONS")
        self.assertEqual(run["visual_review"], "NOT_RUN")
        self.assertEqual(visuals["counts"]["SKIPPED"], 1)
        self.assertEqual(visuals["counts"]["RENDERED"], 0)
        self.assertTrue(list(out.glob("*_BORRADOR.zip")))
        self.assertFalse(list(out.glob("*ENTREGA*.zip")))
        with fitz.open(out / "ensayo_EDITORIAL.pdf") as pdf:
            self.assertIn("flowchart TD", "\n".join(page.get_text() for page in pdf))

    def test_final_paragraph_is_present_in_the_real_last_pdf_page(self):
        self.require_success(self.basic_result)
        self.assertEqual((self.basic_output / "ensayo_ORIGINAL.md").read_bytes(), MANUSCRIPT)
        with fitz.open(self.basic_output / "ensayo_EDITORIAL.pdf") as pdf:
            self.assertGreaterEqual(len(pdf), 4)
            self.assertIn(FINAL_PARAGRAPH, " ".join(pdf[-1].get_text().split()))

    def test_family_and_toc_numbers_match_real_pdf_destinations(self):
        self.require_success(self.basic_result)
        layout = read_json(self.basic_output / "MAQUETACION.json")
        self.assertEqual(layout["metadata"]["family"], "sintesis")
        self.assertEqual(layout["metadata"]["volume_number"], 12)
        self.assertEqual(layout["engine"], "weasyprint")
        with fitz.open(self.basic_output / "ensayo_EDITORIAL.pdf") as pdf:
            toc = pdf[1]
            # PDF engines may emit named destinations and separate annotations
            # for the title, dotted leader and number within the same anchor.
            links = [link for link in toc.get_links()
                     if link["kind"] in (fitz.LINK_GOTO, fitz.LINK_NAMED) and link.get("page", -1) >= 0]
            destinations = {link["page"] for link in links}
            self.assertEqual(len(destinations), 2)
            rows = [max((link for link in links if link["page"] == page),
                        key=lambda link: fitz.Rect(link["from"]).width)
                    for page in destinations]
            for link in rows:
                row = toc.get_text("text", clip=fitz.Rect(link["from"]) + (-1, -1, 1, 1))
                self.assertRegex(row.strip(), rf"\b{link['page'] + 1}\s*$")
                self.assertGreaterEqual(link["page"], 2)


if __name__ == "__main__":
    unittest.main()
