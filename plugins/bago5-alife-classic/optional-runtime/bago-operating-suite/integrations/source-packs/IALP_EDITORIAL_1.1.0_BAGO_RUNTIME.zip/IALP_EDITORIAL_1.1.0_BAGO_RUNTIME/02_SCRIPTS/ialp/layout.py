"""Composición HTML/PDF con recursos locales y títulos derivados del parser real."""
from __future__ import annotations

import hashlib
import html
import json
import logging
import os
import re
import shutil
import subprocess
import unicodedata
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlparse

import mistune
from jinja2 import Environment, FileSystemLoader, select_autoescape
from markupsafe import Markup
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import TextLexer, get_lexer_by_name
from pygments.util import ClassNotFound

from .source import split_frontmatter

PLUGINS = ["table", "strikethrough", "task_lists", "footnotes", "def_list"]
KIT_ROOT = Path(__file__).resolve().parents[2]
ROMAN = {0: "0", 1: "I", 2: "II", 3: "III", 4: "IV", 5: "V", 6: "VI", 7: "VII", 8: "VIII", 9: "IX", 10: "X", 11: "XI", 12: "XII", 13: "XIII", 14: "XIV"}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class PlainHTML(HTMLParser):
    """Texto visible aproximado; nunca ejecuta ni solicita recursos."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self.hidden += 1
        if tag in ("br", "p", "div", "li", "tr", "td", "th", "h1", "h2", "h3", "pre"):
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self.hidden = max(0, self.hidden - 1)
        if tag in ("p", "div", "li", "tr", "td", "th", "h1", "h2", "h3", "pre"):
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def plain_html(value):
    parser = PlainHTML()
    parser.feed(value)
    return "".join(parser.parts)


def slug(value):
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", value).strip("-") or "seccion"


def family_for(number, requested="auto"):
    if requested in ("puerta", "doctrina", "sintesis"):
        return requested
    if requested not in (None, "", "auto"):
        raise ValueError(f"Familia editorial desconocida: {requested}")
    return "puerta" if number == 0 else "doctrina" if number <= 11 else "sintesis"


def editorial_metadata(meta, body, filename, family="auto"):
    ast = mistune.create_markdown(renderer="ast")(body)
    heading = next((x for x in ast if x["type"] == "heading"), None)
    heading_title = token_text(heading) if heading else ""
    inferred = re.search(r"^Volumen\s+(\d+)\b", heading_title, re.I) or re.search(r"Volumen[_\s]+(\d+)", filename, re.I)
    number = int(meta.get("volume_number", inferred.group(1) if inferred else 0))
    if number < 0:
        raise ValueError("volume_number debe ser no negativo")
    toc_depth = int(meta.get("toc_depth", 3))
    if toc_depth not in (1, 2, 3):
        raise ValueError("toc_depth debe ser 1, 2 o 3")
    title = str(meta.get("volume_title") or meta.get("title") or "").strip()
    if not title:
        title = re.sub(r"^Volumen\s+\d+\s*[—-]\s*", "", heading_title, flags=re.I) if heading else Path(filename).stem
    return {
        "title": title,
        "subtitle": str(meta.get("subtitle", "")),
        "collection": str(meta.get("collection", "IA. LA PREGUNTA")),
        "author": str(meta.get("author", "Marc Valls")),
        "volume_number": number,
        "cover_label": str(meta.get("cover_label", "VOLUMEN " + ROMAN.get(number, str(number)))),
        "cover_style": "plain" if meta.get("cover_style") == "plain" else "diagonal",
        "family": family_for(number, family if family != "auto" else meta.get("family", "auto")),
        "edition": str(meta.get("edition", "")),
        "toc_depth": toc_depth,
    }


def token_text(token):
    """Vista textual del AST fuente, independiente del HTML generado."""
    kind = token.get("type", "")
    if kind in ("image", "blank_line", "thematic_break", "footnote_ref"):
        return ""
    if kind in ("block_html", "inline_html"):
        return plain_html(token.get("raw", ""))
    if kind in ("softbreak", "linebreak"):
        return "\n"
    if "children" in token:
        parts = [token_text(child) for child in token["children"]]
        separator = "\n" if kind in ("table", "table_head", "table_body", "table_row", "list", "list_item", "block_quote", "footnotes", "footnote_item", "def_list") else ""
        return separator.join(parts)
    raw = token.get("raw", "")
    if kind in ("block_code", "codespan"):
        return raw
    return html.unescape(raw)


def expected_text_from_markdown(body):
    ast = mistune.create_markdown(renderer="ast", plugins=PLUGINS)(body)
    parts = []
    for token in ast:
        # El salto de página es una orden de composición, no texto de lectura.
        if token.get("type") == "paragraph" and all(line.strip() == "\\newpage" for line in token_text(token).strip().splitlines()) and not any(c["type"] == "codespan" for c in token.get("children", [])):
            continue
        parts.append(token_text(token))
    return "\n\n".join(parts)


class PortableResources:
    def __init__(self, output_dir, source_dir=None):
        self.output_dir = Path(output_dir).resolve()
        self.source_dir = Path(source_dir or output_dir).resolve()
        self.records = []

    def local_reference(self, reference):
        parsed = urlparse(reference)
        if parsed.scheme == "data":
            return reference
        if parsed.scheme in ("http", "https", "ftp") or reference.startswith("//"):
            raise ValueError(f"Recurso remoto no materializado: {reference}. Guárdalo junto a la fuente.")
        if parsed.scheme and parsed.scheme != "file":
            # Permitir unidades de Windows solo en Windows.
            if not (os.name == "nt" and len(parsed.scheme) == 1):
                raise ValueError(f"Esquema de recurso no admitido: {reference}")
        value = unquote(parsed.path if parsed.scheme == "file" else reference.split("#", 1)[0].split("?", 1)[0])
        rel = Path(value)
        roots = [self.output_dir, self.source_dir] if value.replace("\\", "/").startswith("assets/") else [self.source_dir, self.output_dir]
        candidates = [rel.resolve()] if rel.is_absolute() else [(root / rel).resolve() for root in roots]
        path = next((p for p in candidates if p.is_file()), None)
        if path is None:
            raise FileNotFoundError(f"No existe el recurso local {reference!r}")
        if not any(path.is_relative_to(root) for root in roots):
            raise ValueError(f"Recurso fuera de la carpeta fuente/salida: {reference}")
        digest = sha256(path)
        if path.is_relative_to(self.output_dir):
            target = path
        else:
            safe = re.sub(r"[^\w.\-]+", "_", path.name)
            target = self.output_dir / "assets" / "source" / f"{digest[:12]}_{safe}"
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        result = target.relative_to(self.output_dir).as_posix()
        record = {"reference": reference, "path": result, "sha256": digest, "bytes": target.stat().st_size}
        if record not in self.records:
            self.records.append(record)
        return result + ("#" + parsed.fragment if parsed.fragment else "")


class ResourceHTML(HTMLParser):
    """Reubica también imágenes HTML explícitas sin tocar su contenido textual."""
    def __init__(self, resources):
        super().__init__(convert_charrefs=False)
        self.resources = resources
        self.parts = []

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "iframe", "object", "embed", "meta", "base", "link"):
            raise ValueError(f"Elemento activo no admitido en manuscrito editorial: {tag}")
        out = []
        for key, value in attrs:
            if key.startswith("on"):
                raise ValueError("Los atributos de eventos no forman parte del HTML editorial")
            if tag == "img" and key == "src":
                value = self.resources.local_reference(value or "")
            if tag == "img" and key == "srcset":
                raise ValueError("Usa una imagen local mediante src; srcset no está soportado")
            out.append(key if value is None else f'{key}="{html.escape(value, quote=True)}"')
        # HTMLParser normaliza los nombres de atributos: preservar el original
        # evita convertir viewBox en viewbox en los SVG escritos en el manuscrito.
        if tag != "img":
            self.parts.append(self.get_starttag_text())
        else:
            self.parts.append("<" + tag + (" " + " ".join(out) if out else "") + ">")

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        self.parts.append(f"</{tag}>")

    def handle_data(self, data):
        self.parts.append(data)

    def handle_entityref(self, name):
        self.parts.append(f"&{name};")

    def handle_charref(self, name):
        self.parts.append(f"&#{name};")

    def handle_comment(self, data):
        self.parts.append("<!--" + data + "-->")


class EditorialRenderer(mistune.HTMLRenderer):
    def __init__(self, resources):
        super().__init__(escape=False)
        self.resources = resources
        self.headings = []
        self.seen = {}
        self.used_ids = set()
        self.code_languages = []

    def heading(self, text, level, **attrs):
        label = plain_html(text).strip()
        base = slug(label)
        self.seen[base] = self.seen.get(base, 0) + 1
        identifier = base if self.seen[base] == 1 else f"{base}-{self.seen[base]}"
        while identifier in self.used_ids:
            self.seen[base] += 1
            identifier = f"{base}-{self.seen[base]}"
        self.used_ids.add(identifier)
        self.headings.append({"level": level, "title": label, "id": identifier})
        return f'<h{level} id="{identifier}">{text}</h{level}>\n'

    def paragraph(self, text):
        lines = html.unescape(text).strip().splitlines()
        if lines and all(line.strip() == "\\newpage" for line in lines):
            return '<div class="page-break"></div>\n' * len(lines)
        return super().paragraph(text)

    def image(self, text, url, title=None):
        return super().image(text, self.resources.local_reference(url), title)

    def block_code(self, code, info=None):
        language = (info or "text").split(None, 1)[0].lower()
        self.code_languages.append(language)
        if language == "math":
            return '<div class="math-block"><pre>' + html.escape(code) + '</pre></div>\n'
        try:
            lexer = get_lexer_by_name(language)
        except ClassNotFound:
            lexer = TextLexer()
        return highlight(code, lexer, HtmlFormatter(cssclass="highlight", nowrap=False))


def css_string(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ").replace("<", "\\3c ") + '"'


def build_document(markdown_text, output_dir, *, source_dir=None, filename="documento.md", family="auto"):
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    meta, body = split_frontmatter(markdown_text)
    editorial = editorial_metadata(meta, body, filename, family)
    resources = PortableResources(output_dir, source_dir)
    renderer = EditorialRenderer(resources)
    markdown = mistune.create_markdown(renderer=renderer, plugins=PLUGINS)
    body_html = markdown(body)
    resource_html = ResourceHTML(resources)
    resource_html.feed(body_html)
    body_html = "".join(resource_html.parts)
    fonts = KIT_ROOT / "04_CSS" / "fonts"
    if fonts.exists():
        target = output_dir / "assets" / "fonts"
        shutil.copytree(fonts, target, dirs_exist_ok=True)
    css = (KIT_ROOT / "04_CSS" / "ialp_base.css").read_text(encoding="utf-8")
    css += "\n" + (KIT_ROOT / "04_CSS" / f"ialp_{editorial['family']}.css").read_text(encoding="utf-8")
    css += "\n" + (KIT_ROOT / "04_CSS" / "ialp_extended.css").read_text(encoding="utf-8")
    css += "\n" + HtmlFormatter(style="friendly").get_style_defs(".highlight")
    css += "\n@page { @top-left {content:" + css_string(editorial["collection"]) + ";} @bottom-left {content:" + css_string(editorial["author"]) + ";} }"
    env = Environment(loader=FileSystemLoader(KIT_ROOT / "09_PLANTILLAS"), autoescape=select_autoescape(default=True))
    template = env.get_template("documento.html.j2")
    toc = [h for h in renderer.headings if h["level"] <= editorial["toc_depth"]]
    document = template.render(meta=editorial, body=Markup(body_html), css=Markup(css), headings=toc)
    report = {
        "schema": "ialp.layout.v1", "metadata": editorial, "headings": renderer.headings,
        "resources": resources.records, "code_languages": renderer.code_languages,
        "content_reference": "Texto extraído del AST Markdown tras expansión declarativa de visuales; excluye metadatos, código fuente de diagramas y texto alternativo de imágenes.",
    }
    return document, expected_text_from_markdown(body), report


def find_browser():
    for name in ("msedge", "chrome", "chromium", "chromium-browser", "google-chrome"):
        found = shutil.which(name)
        if found:
            return found
    if os.name == "nt":
        for env in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            for suffix in ("Microsoft/Edge/Application/msedge.exe", "Google/Chrome/Application/chrome.exe"):
                path = Path(os.environ.get(env, ".")) / suffix
                if path.is_file():
                    return str(path)
    return None


def render_pdf(html_path, pdf_path, engine="weasyprint", browser_no_sandbox=False):
    html_path, pdf_path = Path(html_path).resolve(), Path(pdf_path).resolve()
    messages = []
    if engine in ("auto", "weasyprint"):
        try:
            from weasyprint import HTML, default_url_fetcher
        except ImportError:
            if engine == "weasyprint":
                raise RuntimeError("Falta WeasyPrint. Instala requirements.txt y sus dependencias nativas.")
        else:
            class Collector(logging.Handler):
                def emit(self, record):
                    messages.append({"level": record.levelname, "message": record.getMessage()})

            def local_fetcher(url, *args, **kwargs):
                parsed = urlparse(url)
                if parsed.scheme == "data":
                    return default_url_fetcher(url, *args, **kwargs)
                if parsed.scheme != "file":
                    raise ValueError("El PDF solo puede cargar recursos locales materializados")
                path = Path(unquote(parsed.path)).resolve()
                if os.name == "nt" and re.match(r"^/[A-Za-z]:", unquote(parsed.path)):
                    path = Path(unquote(parsed.path)[1:]).resolve()
                if not path.is_relative_to(html_path.parent) or not path.is_file():
                    raise ValueError(f"Recurso local inexistente o fuera de la entrega: {path.name}")
                return default_url_fetcher(url, *args, **kwargs)

            logger = logging.getLogger("weasyprint")
            handler = Collector()
            logger.addHandler(handler)
            temp = pdf_path.with_suffix(".partial.pdf")
            try:
                HTML(filename=str(html_path), url_fetcher=local_fetcher).write_pdf(str(temp))
                errors = [m for m in messages if m["level"] in ("ERROR", "CRITICAL")]
                if errors:
                    raise RuntimeError("WeasyPrint detectó errores de recursos/render: " + "; ".join(x["message"] for x in errors))
                if not temp.is_file() or temp.stat().st_size == 0:
                    raise RuntimeError("WeasyPrint no produjo un PDF válido")
                temp.replace(pdf_path)
            finally:
                logger.removeHandler(handler)
                if temp.exists():
                    temp.unlink()
            return {"engine": "weasyprint", "pdf_sha256": sha256(pdf_path), "messages": messages, "toc_page_numbers": True}
    browser = find_browser()
    if not browser:
        raise RuntimeError("No se encontró navegador; usa WeasyPrint o instala Edge/Chrome para el modo browser")
    temp = pdf_path.with_suffix(".partial.pdf")
    command = [browser, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", f"--print-to-pdf={temp}", html_path.as_uri()]
    if browser_no_sandbox:
        command.insert(1, "--no-sandbox")
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=180)
        if result.returncode or not temp.is_file() or temp.stat().st_size == 0:
            raise RuntimeError("Falló el motor browser: " + result.stderr[-2000:])
        temp.replace(pdf_path)
    finally:
        if temp.exists():
            temp.unlink()
    return {"engine": "browser", "pdf_sha256": sha256(pdf_path), "messages": [], "toc_page_numbers": False,
            "limitations": ["Modo de compatibilidad: no acredita contadores de páginas del índice ni paridad de paginación con WeasyPrint."]}
