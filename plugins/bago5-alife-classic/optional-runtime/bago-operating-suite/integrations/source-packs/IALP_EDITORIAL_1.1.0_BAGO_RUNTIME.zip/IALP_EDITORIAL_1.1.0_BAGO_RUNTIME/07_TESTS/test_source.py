"""Regressions for observed content loss and explicit-cleaning boundaries."""
from __future__ import annotations
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "02_SCRIPTS"))
from ialp.source import clean_source, preflight_source, reconstruct_source, sha256_text, split_frontmatter


class SourcePreservationTests(unittest.TestCase):
    def test_legitimate_risks_and_metadata_preserved_by_default(self):
        text = "# Manual\n\n## Riesgos residuales del sistema\nContenido publicable.\n\n**Estado:** estable\n"
        cleaned, report = clean_source(text, names=["riesgos residuales"])
        self.assertEqual(cleaned, text)
        self.assertEqual(report["removed"], [])

    def test_literal_fenced_heading_cannot_delete_following_content(self):
        text = "# Manual\n\n```markdown\n## Estado final\nEjemplo.\n```\n\nPárrafo legítimo.\n\n## Otro\nContenido.\n"
        for mode in ("preserve", "explicit", "legacy"):
            with self.subTest(mode=mode):
                self.assertEqual(clean_source(text, mode, ["estado final"])[0], text)

    def test_exact_whitespace_crlf_bom_and_newpage_preserved(self):
        text = '\ufeff---\r\nvolume_title: "Título"\r\nstatus: "PUBLICABLE"\r\n---\r\n# Título\r\n\r\nPrimera.  \r\nSegunda.\r\n\\newpage\r\n\\newpage\r\n\r\n\r\n\r\nFin\t'
        for mode in ("preserve", "explicit"):
            cleaned, report = clean_source(text, mode)
            self.assertEqual(cleaned.encode("utf-8"), text.encode("utf-8"))
            self.assertEqual(report["input_sha256"], report["output_sha256"])

    def test_explicit_blocks_removed_with_exact_reconstruction(self):
        text = "A  \r\n<!-- IALP_CONTROL_START -->\r\nEstado interno: válido á.\r\n<!-- IALP_CONTROL_END -->\r\nB\n<!-- CONTROL INTERNO FUERA DEL LIBRO:\nexpediente\n-->\nC"
        cleaned, report = clean_source(text)
        self.assertEqual(cleaned, "A  \r\n\r\nB\n\nC")
        self.assertEqual(report["removed_count"], 2)
        serialized = json.loads(json.dumps(report, ensure_ascii=False))
        self.assertEqual(reconstruct_source(cleaned, serialized), text)
        self.assertTrue(report["preservation"]["reconstruction_verified"])

    def test_preserve_mode_keeps_explicit_internal_blocks(self):
        text = "<!-- IALP_CONTROL_START -->interno<!-- IALP_CONTROL_END -->"
        self.assertEqual(clean_source(text, "preserve")[0], text)

    def test_markers_inside_code_are_protected(self):
        marker = "<!-- IALP_CONTROL_START -->x<!-- IALP_CONTROL_END -->"
        comment = "<!-- CONTROL INTERNO FUERA DEL LIBRO: x -->"
        examples = [
            f"```html\n{marker}\n{comment}\n```\n",
            f"~~~~\n{marker}\n~~~\n{comment}\n~~~~\n",
            f"Texto `{marker}` y ``{comment}``.\n",
            f"    {marker}\n\t{comment}\n",
            f"> ```html\n> {marker}\n> ```\n",
            f"- ```html\n  {marker}\n  ```\n",
            f"```html\n{marker}\n",
        ]
        for text in examples:
            with self.subTest(text=text):
                self.assertEqual(clean_source(text)[0], text)

    def test_internal_comment_can_contain_code_fence(self):
        text = "A\n<!-- CONTROL INTERNO FUERA DEL LIBRO:\n```\nprivado\n-->\nB\n<!-- IALP_CONTROL_START -->x<!-- IALP_CONTROL_END -->\nC"
        cleaned, report = clean_source(text)
        self.assertEqual(cleaned, "A\n\nB\n\nC")
        self.assertEqual(reconstruct_source(cleaned, report), text)

    def test_markers_inside_frontmatter_remain_literal(self):
        text = '---\nsubtitle: "<!-- IALP_CONTROL_START -->ejemplo<!-- IALP_CONTROL_END -->"\n---\n# Texto\n'
        self.assertEqual(clean_source(text)[0], text)

    def test_unbalanced_or_nested_markers_raise(self):
        for text in ["<!-- IALP_CONTROL_START -->sin cierre", "<!-- IALP_CONTROL_END -->",
                     "<!-- CONTROL INTERNO FUERA DEL LIBRO: sin cierre",
                     "<!-- IALP_CONTROL_START --><!-- IALP_CONTROL_START --><!-- IALP_CONTROL_END -->"]:
            with self.subTest(text=text), self.assertRaises(ValueError):
                clean_source(text)

    def test_legacy_rules_and_full_record(self):
        text = '---\nvolume_title: "Título"\nstatus: PUBLICABLE\nvalidation:\n  notes: interna\nauthor: Marc\n---\n# Manual\n\n**Estado:** cerrado\n\n## Riesgos residuales\nPrivado.\n\n## Publicable\nFinal.  \n'
        cleaned, report = clean_source(text, "legacy", ["riesgos residuales"])
        self.assertNotIn("Privado", cleaned)
        self.assertNotIn("**Estado:**", cleaned)
        meta, body = split_frontmatter(cleaned)
        self.assertNotIn("status", meta)
        self.assertNotIn("validation", meta)
        self.assertEqual(meta["author"], "Marc")
        self.assertIn("Final.  \n", body)
        self.assertEqual(reconstruct_source(cleaned, report), text)

    def test_changed_output_or_audit_cannot_reconstruct_as_original(self):
        text = "A<!-- IALP_CONTROL_START -->interno<!-- IALP_CONTROL_END -->B"
        cleaned, report = clean_source(text)
        with self.assertRaises(ValueError):
            reconstruct_source(cleaned + "X", report)
        damaged = copy.deepcopy(report)
        damaged["removed"][0]["text"] += "X"
        with self.assertRaises(ValueError):
            reconstruct_source(cleaned, damaged)

    def test_legacy_does_not_publish_broken_yaml_alias(self):
        text = "---\nvalidation: &source valor\nsubtitle: *source\n---\n# Título\n"
        with self.assertRaises(ValueError):
            clean_source(text, "legacy")

    def test_legacy_refuses_flow_mapping_instead_of_deleting_editorial_fields(self):
        text = "---\n{status: interno, volume_title: Publicable}\n---\n# Título\n"
        self.assertEqual(clean_source(text)[0], text)
        with self.assertRaises(ValueError):
            clean_source(text, "legacy")


class FrontmatterAndPreflightTests(unittest.TestCase):
    def test_real_yaml_nested_values_and_body_unchanged(self):
        source = '---\nvolume_title: "Título: especial"\noptions:\n  scale: 2\n---\n# Texto\n'
        meta, body = split_frontmatter(source)
        self.assertEqual(meta["volume_title"], "Título: especial")
        self.assertEqual(meta["options"], {"scale": 2})
        self.assertEqual(body, "# Texto\n")

    def test_horizontal_rule_in_body_is_not_frontmatter(self):
        text = "# Manual\n\n---\n\n## A\n\n## B\n"
        self.assertEqual(split_frontmatter(text), ({}, text))
        report = preflight_source(text)
        self.assertEqual(report["exit_code"], 2)
        self.assertIn("Sin frontmatter YAML inicial.", report["warnings"])

    def test_invalid_frontmatter_is_error(self):
        for text in ("---\ntitle: [\n---\n# Título", "---\ntitle: Título\n", "---\n- item\n---\n# Título"):
            with self.subTest(text=text):
                with self.assertRaises(ValueError):
                    split_frontmatter(text)
                self.assertEqual(preflight_source(text)["exit_code"], 1)

    def test_headings_and_patterns_in_fences_do_not_count(self):
        text = "---\nvolume_title: Manual\n---\n# Manual\n```markdown\n## Ejemplo\n## Otro\nDICTAMEN CONCEPTUAL\n```\n"
        report = preflight_source(text, [r"DICTAMEN\s+CONCEPTUAL"])
        self.assertEqual(report["headings"], {"h1": 1, "h2": 0})
        self.assertEqual(report["pattern_hits"], [])
        self.assertEqual(report["exit_code"], 2)

    def test_preflight_pass_and_real_pattern_review(self):
        text = "---\nvolume_title: Manual\n---\n# Manual\n## A\nTexto.\n## B\nOtro.\n"
        self.assertEqual(preflight_source(text)["exit_code"], 0)
        report = preflight_source(text + "DICTAMEN CONCEPTUAL\n", [r"DICTAMEN\s+CONCEPTUAL"])
        self.assertEqual(report["exit_code"], 2)
        self.assertEqual(report["pattern_hits"][0]["line"], 9)


class SourceCliTests(unittest.TestCase):
    def test_cli_preserves_bytes_and_writes_report(self):
        original = b"# Manual\r\n\r\nPrimera.  \r\nSegunda.\r\n\\newpage\r\n\\newpage\r\n"
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp)
            source, output, report_path = folder / "source.md", folder / "output.md", folder / "report.json"
            source.write_bytes(original)
            result = subprocess.run([sys.executable, str(ROOT / "02_SCRIPTS" / "01_limpiar_fuente_editorial.py"), str(source), str(output), "--report", str(report_path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(source.read_bytes(), original)
            self.assertEqual(output.read_bytes(), original)
            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["input_sha256"], sha256_text(original.decode("utf-8")))
            self.assertEqual(reconstruct_source(output.read_bytes().decode("utf-8"), report), original.decode("utf-8"))

    def test_preflight_cli_exit_codes(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source.md"
            for text, expected in (("# Corto\n", 2), ("---\ntitle: [\n---\n", 1)):
                source.write_text(text, encoding="utf-8")
                result = subprocess.run([sys.executable, str(ROOT / "02_SCRIPTS" / "00_preflight_fuente.py"), str(source)], capture_output=True, text=True)
                self.assertEqual(result.returncode, expected, result.stdout + result.stderr)

    def test_preflight_usage_error_is_not_editorial_review(self):
        result = subprocess.run([sys.executable, str(ROOT / "02_SCRIPTS" / "00_preflight_fuente.py"), "--unknown"], capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)


if __name__ == "__main__":
    unittest.main()
