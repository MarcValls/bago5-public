"""Declarative visual fences with per-block evidence and no arbitrary Python.

Top-level mermaid, dot/graphviz, chart and spreadsheet fences are supported.
Longer fences quoting examples remain opaque. Output images must exist and
validate before their block receives RENDERED status.
"""
from __future__ import annotations

import hashlib
import html
import io
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
from typing import Iterator
from urllib.parse import quote
import xml.etree.ElementTree as ET
from xml.parsers import expat

KINDS = {"mermaid": "mermaid", "dot": "dot", "graphviz": "dot", "chart": "chart", "spreadsheet": "spreadsheet"}
OPEN_FENCE = re.compile(r"^ {0,3}(`{3,}|~{3,})([^\r\n]*)[\r\n]*$")


class VisualRenderError(RuntimeError):
    """The complete report and Markdown with failed fences preserved."""
    def __init__(self, message: str, report: dict, transformed_markdown: str = ""):
        super().__init__(message)
        self.report = report
        self.transformed_markdown = transformed_markdown


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _relative(path: Path, root: Path) -> str:
    return Path(os.path.relpath(path, root)).as_posix()


def _fences(text: str) -> Iterator[tuple[str, str | None, str, int]]:
    """Keep unknown fences opaque; follow top-level CommonMark fence rules.

    An unclosed fence extends to EOF. Indented code and quoted/list-contained
    blocks are left untouched. Backtick and tilde delimiters never mix.
    """
    lines = text.splitlines(keepends=True)
    plain: list[str] = []
    i = 0
    while i < len(lines):
        match = OPEN_FENCE.match(lines[i])
        if not match or (match.group(1)[0] == "`" and "`" in match.group(2)):
            plain.append(lines[i])
            i += 1
            continue
        if plain:
            yield "".join(plain), None, "", 0
            plain = []
        start = i
        delimiter, info = match.groups()
        language = info.strip().split(None, 1)[0].lower() if info.strip() else ""
        closing = re.compile(r"^ {0,3}" + re.escape(delimiter[0]) + "{" + str(len(delimiter)) + r",}[ \t]*[\r\n]*$")
        i += 1
        body_start = i
        while i < len(lines) and not closing.match(lines[i]):
            i += 1
        body = "".join(lines[body_start:i])
        if i < len(lines):
            i += 1
        yield "".join(lines[start:i]), language, body, start + 1
    if plain:
        yield "".join(plain), None, "", 0


def _executable(name: str, override: str | Path | None = None) -> str:
    target = str(override) if override is not None else name
    found = shutil.which(target)
    if not found:
        raise RuntimeError(f"No se encuentra el ejecutable {target!r}. Instálelo y compruebe PATH; no basta con el paquete Python.")
    return found


def _mermaid_command(executable: str) -> list[str]:
    """Launch npm Windows shims through Node, without a command shell."""
    path = Path(executable)
    if os.name == "nt" and path.suffix.lower() in {".cmd", ".bat"}:
        candidates = [path.parent / "node_modules" / "@mermaid-js" / "mermaid-cli" / "src" / "cli.js",
                      path.parent.parent / "@mermaid-js" / "mermaid-cli" / "src" / "cli.js"]
        for candidate in candidates:
            if candidate.is_file():
                return [_executable("node"), str(candidate)]
        raise RuntimeError("No se localiza cli.js junto al lanzador npm; revise la instalación de @mermaid-js/mermaid-cli.")
    return [executable]


def _run(command: list[str], timeout: float, item: dict) -> None:
    item["command"] = command
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"El renderizador superó el límite de {timeout:g} segundos.") from exc
    item["returncode"] = result.returncode
    item["stderr"] = (result.stderr or "")[-4000:]
    if result.returncode:
        detail = (result.stderr or result.stdout or "sin detalles")[-2000:].strip()
        raise RuntimeError(f"El renderizador terminó con código {result.returncode}: {detail}")


def _validate_image(path: Path, fmt: str) -> None:
    if not path.is_file() or not path.stat().st_size:
        raise RuntimeError("El renderizador no produjo una imagen no vacía.")
    if fmt == "svg":
        node = ET.parse(path).getroot()
        if node.tag.rsplit("}", 1)[-1] != "svg":
            raise RuntimeError("La salida no contiene un elemento SVG raíz válido.")
    else:
        from PIL import Image
        with Image.open(path) as image:
            if image.format != "PNG":
                raise RuntimeError("La salida solicitada no es PNG.")
            image.verify()


def _normalize_mermaid_svg(path: Path, item: dict) -> None:
    """Give percentage-sized Mermaid SVG an intrinsic ratio for paged renderers.

    Only root width/height attributes are changed. Re-serializing the XML tree
    would rewrite namespace prefixes and embedded style/font markup, so locate
    the real root through Expat and preserve all remaining bytes exactly.
    """
    data = path.read_bytes()
    root = ET.fromstring(data)
    viewbox = root.get("viewBox")
    before = {key: root.get(key) for key in ("width", "height")}
    if viewbox is None:
        # Some valid SVG backends already return fixed dimensions without a box.
        try:
            dimensions = [float(before[key]) for key in ("width", "height")]
        except (ValueError, TypeError) as exc:
            raise ValueError("El SVG Mermaid necesita viewBox o dimensiones numéricas completas.") from exc
        if not all(math.isfinite(value) and value > 0 for value in dimensions):
            raise ValueError("El SVG Mermaid tiene dimensiones intrínsecas inválidas.")
        item.setdefault("postprocessing", []).append({
            "operation": "svg_intrinsic_dimensions", "status": "UNCHANGED",
            "reason": "Sin viewBox; conserva dimensiones numéricas ya presentes.",
            "before": before, "after": before,
            "input_sha256": _sha(data), "output_sha256": _sha(data),
        })
        return
    try:
        values = [float(value) for value in re.split(r"[\s,]+", viewbox.strip())]
    except ValueError as exc:
        raise ValueError("El viewBox del SVG Mermaid no contiene números válidos.") from exc
    if len(values) != 4 or not all(math.isfinite(value) for value in values) or values[2] <= 0 or values[3] <= 0:
        raise ValueError("El viewBox del SVG Mermaid necesita cuatro números finitos y dimensiones positivas.")
    after = {"width": format(values[2], ".15g"), "height": format(values[3], ".15g")}
    output = data
    if before != after:
        parser = expat.ParserCreate()
        start = None

        def start_element(_name, _attributes):
            nonlocal start
            if start is None:
                start = parser.CurrentByteIndex

        parser.StartElementHandler = start_element
        parser.Parse(data, True)
        if start is None:
            raise ValueError("No se localiza la raíz del SVG Mermaid.")
        quote_char = None
        end = start
        while end < len(data):
            character = data[end]
            if quote_char is not None:
                if character == quote_char:
                    quote_char = None
            elif character in (ord('"'), ord("'")):
                quote_char = character
            elif character == ord(">"):
                end += 1
                break
            end += 1
        opening = data[start:end]
        attribute = re.compile(rb"\s+([A-Za-z_:][A-Za-z0-9_.:-]*)\s*=\s*(?:\"[^\"]*\"|'[^']*')")
        opening = attribute.sub(lambda match: b"" if match[1] in (b"width", b"height") else match[0], opening)
        closing = 2 if opening.endswith(b"/>") else 1
        fixed = f' width="{after["width"]}" height="{after["height"]}"'.encode("ascii")
        opening = opening[:-closing] + fixed + opening[-closing:]
        output = data[:start] + opening + data[end:]
        path.write_bytes(output)
    item.setdefault("postprocessing", []).append({
        "operation": "svg_intrinsic_dimensions", "status": "APPLIED" if output != data else "UNCHANGED",
        "viewBox": viewbox, "before": before, "after": after,
        "input_sha256": _sha(data), "output_sha256": _sha(output),
        "scope": "Solo width/height de la raíz; conserva viewBox, cuerpo vectorial y fuentes embebidas.",
    })


def _json_spec(body: str, kind: str) -> dict:
    def invalid_constant(value):
        raise ValueError(f"Número JSON no finito: {value}")
    spec = json.loads(body, parse_constant=invalid_constant)
    if not isinstance(spec, dict):
        raise ValueError(f"El bloque {kind} debe contener un objeto JSON.")
    return spec


def _numbers(values, label: str) -> list[float]:
    if not isinstance(values, list) or not values or len(values) > 50000:
        raise ValueError(f"{label} debe ser una lista no vacía de hasta 50000 números.")
    if any(isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) for value in values):
        raise ValueError(f"{label} solo admite números finitos.")
    return values


def _labels(values, length: int, label: str) -> list[str]:
    if not isinstance(values, list) or len(values) != length:
        raise ValueError(f"{label} debe contener {length} etiquetas.")
    if any(not isinstance(value, (str, int, float)) for value in values):
        raise ValueError(f"{label} solo admite textos o números.")
    return [str(value) for value in values]


def _render_chart(body: str, output: Path, item: dict) -> None:
    try:
        import matplotlib
        from matplotlib.figure import Figure
        from matplotlib.backends.backend_svg import FigureCanvasSVG
    except ImportError as exc:
        raise RuntimeError("Falta matplotlib para renderizar bloques chart.") from exc
    spec = _json_spec(body, "chart")
    kind = spec.get("type")
    if kind not in {"bar", "line", "heatmap"}:
        raise ValueError("chart.type debe ser bar, line o heatmap.")
    item.update(chart_type=kind, backend="matplotlib", backend_version=matplotlib.__version__, title=str(spec.get("title", "")))
    with matplotlib.rc_context({"svg.fonttype": "none", "svg.hashsalt": "ialp", "font.family": "DejaVu Sans", "font.size": 10}):
        figure = Figure(figsize=(6.4, 3.8))
        FigureCanvasSVG(figure)
        ax = figure.subplots()
        try:
            if kind in {"bar", "line"}:
                values = _numbers(spec.get("values", spec.get("y")), "values/y")
                raw_x = spec.get("labels", spec.get("x", list(range(1, len(values) + 1))))
                labels = _labels(raw_x, len(values), "labels/x")
                numeric_x = "labels" not in spec and all(isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) for value in raw_x)
                positions = raw_x if kind == "line" and numeric_x else list(range(len(values)))
                color = spec.get("color", "#173d57")
                if kind == "bar":
                    ax.bar(positions, values, color=color)
                else:
                    ax.plot(positions, values, marker="o", color=color, linewidth=1.8)
                if kind == "bar" or not numeric_x:
                    ax.set_xticks(positions, labels, rotation=20 if len(labels) > 6 else 0)
                ax.grid(axis="y", alpha=0.2)
                ax.set_axisbelow(True)
            else:
                matrix = spec.get("values", spec.get("data"))
                if not isinstance(matrix, list) or not matrix:
                    raise ValueError("heatmap.values debe ser una matriz numérica no vacía.")
                rows = [_numbers(row, "fila de heatmap") for row in matrix]
                width = len(rows[0])
                if any(len(row) != width for row in rows) or len(rows) * width > 50000:
                    raise ValueError("La matriz heatmap debe ser rectangular y tener como máximo 50000 celdas.")
                image = ax.imshow(rows, cmap=spec.get("cmap", "Blues"), aspect="auto")
                figure.colorbar(image, ax=ax, shrink=0.8)
                if "xlabels" in spec:
                    ax.set_xticks(range(width), _labels(spec["xlabels"], width, "xlabels"))
                if "ylabels" in spec:
                    ax.set_yticks(range(len(rows)), _labels(spec["ylabels"], len(rows), "ylabels"))
            ax.set_title(item["title"], loc="left", fontweight="bold", pad=14)
            ax.set_xlabel(str(spec.get("xlabel", "")))
            ax.set_ylabel(str(spec.get("ylabel", "")))
            figure.tight_layout()
            figure.savefig(output, format="svg", bbox_inches="tight", metadata={"Date": None, "Creator": "IALP editorial kit"})
        finally:
            figure.clear()


def _table_cell(value) -> str:
    if value is None:
        return ""
    if hasattr(value, "isoformat"):
        value = value.isoformat()
    text = html.escape(str(value), quote=False).replace("\\", "\\\\")
    for character in ("|", "`", "*", "_", "[", "]"):
        text = text.replace(character, "\\" + character)
    return text.replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>")


def _render_spreadsheet(body: str, output: Path, source_dir: Path, asset_dir: Path, output_dir: Path, item: dict) -> str:
    try:
        import openpyxl
        from openpyxl.utils.cell import range_boundaries
    except ImportError as exc:
        raise RuntimeError("Falta openpyxl para bloques spreadsheet.") from exc
    spec = _json_spec(body, "spreadsheet")
    if not isinstance(spec.get("path"), str) or not spec["path"]:
        raise ValueError("spreadsheet.path debe identificar un libro Excel local.")
    relative = Path(spec["path"])
    if relative.is_absolute():
        raise ValueError("spreadsheet.path debe ser relativo a la carpeta de la fuente.")
    workbook_path = (source_dir / relative).resolve()
    try:
        workbook_path.relative_to(source_dir)
    except ValueError as exc:
        raise ValueError("El libro spreadsheet debe estar dentro de la carpeta de la fuente.") from exc
    if workbook_path.suffix.lower() not in {".xlsx", ".xlsm", ".xltx", ".xltm"}:
        raise ValueError("spreadsheet admite libros OOXML: .xlsx, .xlsm, .xltx o .xltm.")
    data = workbook_path.read_bytes()
    digest = _sha(data)
    copied_input = asset_dir / f"workbook-{digest[:16]}{workbook_path.suffix.lower()}"
    copied_input.write_bytes(data)
    item.update(input_path=spec["path"], input_sha256=digest, input_copy_path=_relative(copied_input, output_dir), backend="openpyxl", backend_version=openpyxl.__version__)
    formulas = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=False)
    cached = None
    try:
        cached = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        sheet_name = spec.get("sheet", formulas.sheetnames[0])
        if sheet_name not in formulas.sheetnames:
            raise ValueError(f"No existe la hoja {sheet_name!r}.")
        ws, value_ws = formulas[sheet_name], cached[sheet_name]
        selected = spec.get("range", ws.calculate_dimension())
        if not isinstance(selected, str):
            raise ValueError("spreadsheet.range debe ser un rango como A1:C5.")
        min_col, min_row, max_col, max_row = range_boundaries(selected)
        if None in (min_col, min_row, max_col, max_row) or min_col > max_col or min_row > max_row or min_row < 1 or min_col < 1:
            raise ValueError("El rango spreadsheet debe delimitar filas y columnas válidas.")
        if (max_col - min_col + 1) * (max_row - min_row + 1) > 25000:
            raise ValueError("El rango spreadsheet excede 25000 celdas; seleccione un rango editorial menor.")
        rows = []
        formula_count = 0
        bounds = dict(min_row=min_row, max_row=max_row, min_col=min_col, max_col=max_col)
        for formula_row, value_row in zip(ws.iter_rows(**bounds), value_ws.iter_rows(**bounds)):
            row = []
            for source_cell, value_cell in zip(formula_row, value_row):
                if source_cell.data_type == "f":
                    formula_count += 1
                    if value_cell.value is None:
                        raise ValueError(f"Fórmula sin resultado utilizable en caché: {sheet_name}!{source_cell.coordinate}. Recalcule y guarde el libro con Excel o LibreOffice antes de exportar.")
                    if value_cell.data_type == "e":
                        raise ValueError(f"Fórmula con error en caché: {sheet_name}!{source_cell.coordinate}: {value_cell.value}")
                row.append(_table_cell(value_cell.value))
            rows.append(row)
        if not rows:
            raise ValueError("El rango spreadsheet no contiene filas.")
        table = "| " + " | ".join(rows[0]) + " |\n"
        table += "| " + " | ".join("---" for _ in rows[0]) + " |\n"
        table += "".join("| " + " | ".join(row) + " |\n" for row in rows[1:])
        output.write_text(table, encoding="utf-8")
        item.update(sheet=sheet_name, range=selected, row_count=len(rows), column_count=len(rows[0]), formulas_with_cached_values=formula_count)
        return table
    finally:
        formulas.close()
        if cached is not None:
            cached.close()


def render_visuals(text: str, output_dir: str | Path, *, source_dir: str | Path | None = None,
                   mermaid_mode: str = "required", mmdc: str | Path | None = None,
                   timeout: float = 90, mermaid_format: str = "svg",
                   assets_dir: str | Path | None = None,
                   puppeteer_config: str | Path | None = None) -> tuple[str, dict]:
    """Return transformed Markdown and an evidence report, or VisualRenderError.

    Mermaid skip preserves the original fence with SKIPPED status; other
    kinds remain required. PNG requires an explicit mermaid_format='png'.
    Generated links and report paths are relative to output_dir. Spreadsheet
    paths resolve inside source_dir. Failed fences remain in the exception's
    transformed_markdown for diagnosis, never as successful visual output.
    """
    if mermaid_mode not in {"required", "skip"}:
        raise ValueError("mermaid_mode debe ser required o skip.")
    if mermaid_format not in {"svg", "png"}:
        raise ValueError("mermaid_format debe ser svg o png.")
    if not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout debe ser un número positivo finito.")
    output_dir = Path(output_dir).resolve()
    source_dir = Path(source_dir).resolve() if source_dir is not None else Path.cwd().resolve()
    asset_dir = Path(assets_dir).resolve() if assets_dir is not None else output_dir / "assets_visuals"
    output_dir.mkdir(parents=True, exist_ok=True)
    asset_dir.mkdir(parents=True, exist_ok=True)
    report = {"schema_version": "1.0", "status": "NO_VISUALS", "counts": {"total": 0, "RENDERED": 0, "SKIPPED": 0, "FAILED": 0}, "items": [], "warnings": []}
    rendered_parts = []
    for original, language, body, line in _fences(text):
        if language not in KINDS:
            rendered_parts.append(original)
            continue
        kind = KINDS[language]
        index = len(report["items"]) + 1
        digest = _sha(body.encode("utf-8"))
        identifier = f"{index:03d}-{kind}-{digest[:12]}"
        suffix = {"mermaid": ".mmd", "dot": ".dot", "chart": ".chart.json", "spreadsheet": ".spreadsheet.json"}[kind]
        source_path = asset_dir / (identifier + suffix)
        item = {"id": identifier, "kind": kind, "line": line, "status": "FAILED", "source_path": _relative(source_path, output_dir), "source_sha256": digest, "output_path": None, "output_sha256": None, "error": None}
        report["items"].append(item)
        replacement = original
        staging: tempfile.TemporaryDirectory | None = None
        try:
            source_path.write_text(body, encoding="utf-8")
            if kind == "mermaid" and mermaid_mode == "skip":
                item["status"] = "SKIPPED"
                item["reason"] = "Omisión de Mermaid solicitada explícitamente; se conserva el bloque original."
                report["warnings"].append(f"{identifier}: {item['reason']}")
            else:
                fmt = mermaid_format if kind == "mermaid" else ("md" if kind == "spreadsheet" else "svg")
                target = asset_dir / (identifier + "." + fmt)
                target.unlink(missing_ok=True)
                staging = tempfile.TemporaryDirectory(prefix=".ialp-render-", dir=asset_dir)
                temporary = Path(staging.name) / ("render." + fmt)
                if kind == "mermaid":
                    executable = _executable("mmdc", mmdc)
                    config = asset_dir / "mermaid.config.json"
                    config.write_text(json.dumps({
                        "htmlLabels": False, "theme": "base", "look": "classic", "fontFamily": "DejaVu Sans",
                        "themeCSS": ".edgeLabel rect { opacity: 1 !important; fill: #ffffff !important; } .labelBkg { fill: #ffffff !important; opacity: 1 !important; }",
                        "themeVariables": {"fontFamily": "DejaVu Sans", "fontSize": "18px",
                            "primaryColor": "#eef3f5", "primaryTextColor": "#0f2b40",
                            "primaryBorderColor": "#173d57", "lineColor": "#65727d",
                            "secondaryColor": "#e9dfbe", "edgeLabelBackground": "#ffffff"},
                        "flowchart": {"minNodeWidth": 0, "nodeSpacing": 25, "rankSpacing": 35,
                            "diagramPadding": 8, "padding": 10, "useMaxWidth": False},
                    }, indent=2) + "\n", encoding="utf-8")
                    item.update(backend="mermaid-cli", format=fmt, config_path=_relative(config, output_dir), config_sha256=_sha(config.read_bytes()))
                    command = _mermaid_command(executable) + ["-i", str(source_path), "-o", str(temporary), "-b", "transparent", "-c", str(config)]
                    launch_config = puppeteer_config or os.environ.get("IALP_PUPPETEER_CONFIG")
                    if launch_config:
                        launch_path = Path(launch_config).resolve()
                        if not launch_path.is_file():
                            raise ValueError(f"No existe la configuración de Puppeteer: {launch_path}")
                        item["puppeteer_config_sha256"] = _sha(launch_path.read_bytes())
                        command.extend(["-p", str(launch_path)])
                    _run(command, timeout, item)
                elif kind == "dot":
                    item.update(backend="graphviz", format="svg")
                    _run([_executable("dot"), "-Tsvg", str(source_path), "-o", str(temporary)], timeout, item)
                elif kind == "chart":
                    _render_chart(body, temporary, item)
                    item["format"] = "svg"
                else:
                    replacement = "\n" + _render_spreadsheet(body, temporary, source_dir, asset_dir, output_dir, item) + "\n"
                    item["format"] = "markdown-table"
                if kind != "spreadsheet":
                    _validate_image(temporary, fmt)
                if kind == "mermaid" and fmt == "svg":
                    _normalize_mermaid_svg(temporary, item)
                    _validate_image(temporary, fmt)
                temporary.replace(target)
                item.update(status="RENDERED", output_path=_relative(target, output_dir), output_sha256=_sha(target.read_bytes()))
                if kind != "spreadsheet":
                    alt = _table_cell(item.get("title") or f"{kind.capitalize()} {index}")
                    uri = quote(item["output_path"], safe="/.-_")
                    replacement = f"\n![{alt}]({uri})\n"
        except Exception as exc:
            item["error"] = f"{type(exc).__name__}: {exc}"
            item["status"] = "FAILED"
            replacement = original
        finally:
            if staging is not None:
                staging.cleanup()
        rendered_parts.append(replacement)
        report["counts"][item["status"]] += 1
        report["counts"]["total"] += 1
    transformed = "".join(rendered_parts)
    if report["counts"]["FAILED"]:
        report["status"] = "FAILED"
        errors = "; ".join(f"{item['id']}: {item['error']}" for item in report["items"] if item["status"] == "FAILED")
        raise VisualRenderError(f"Fallaron {report['counts']['FAILED']} recursos visuales: {errors}", report, transformed)
    if report["counts"]["SKIPPED"]:
        report["status"] = "PARTIAL" if report["counts"]["RENDERED"] else "SKIPPED"
    elif report["counts"]["RENDERED"]:
        report["status"] = "RENDERED"
    return transformed, report
