"""Explicit visual-review records, bound to the reviewed PDF and its evidence.

This module does not look at pages or infer a visual verdict. A named reviewer
must supply that declaration, page coverage and the seven checklist items.
Hashes bind the declaration to files; they do not authenticate the reviewer or
prove that the inspection took place. ``validate_visual_review`` must be run
again before delivery: an unchanged receipt alone is not a current approval.

Public API:
    record_visual_review(pdf_path, *, reviewer, inspected_pages, result,
        checklist, notes='', findings=None, preview_path=None, audit_path=None,
        run_path=None, reviewed_at=None, output_path=None) -> dict
    validate_visual_review(receipt_path, *, pdf_path=None, preview_path=None,
        audit_path=None, run_path=None) -> dict

``inspected_pages`` is an explicit list of 1-based page numbers, or a declaration
such as ``all`` or ``1,3-5``. ``result`` is PASS or FAIL. ``checklist`` must contain
every key in CHECKLIST_ITEMS; entries are objects with ``status`` and optional
``notes``. Status is PASS, FAIL, NOT_APPLICABLE or NOT_RUN. FAIL and
NOT_APPLICABLE require notes. Missing checks are never inferred from the verdict.
``findings`` is a list of objects with a description, severity
(INFO/WARNING/ERROR), optional page and optional checklist item. An ERROR blocks
a pass. Timestamps are ISO 8601 with timezone; the default is the current UTC time.

Default evidence paths are AUDITORIA.json and verificacion_visual/PREVIEW.json
beside the PDF; RUN.json is bound too when present. All referenced preview
images and contact sheets are hash-checked. The default receipt destination is
REVISION_VISUAL.json beside the PDF. Writing is atomic. No input or RUN is changed.
"""
from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import re
import tempfile


CHECKLIST_ITEMS = {
    "portada": "Portada: jerarquía, título y composición.",
    "indice": "Índice: legibilidad, entradas y correspondencia con páginas.",
    "cortes_desbordes": "Cortes y desbordes: texto, imágenes y márgenes.",
    "diagramas_etiquetas": "Diagramas y etiquetas: integridad, escala y legibilidad.",
    "tablas_cuadriculas": "Tablas y cuadrículas: filas, columnas, cortes y alineación.",
    "cabeceras_pies": "Cabeceras y pies: contenido, numeración y superposiciones.",
    "fuentes_contraste": "Fuentes y contraste: glifos, tamaños y contraste visual.",
}
_STATUSES = {"PASS", "FAIL", "NOT_APPLICABLE", "NOT_RUN"}
_HASH = re.compile(r"^[0-9a-f]{64}$")


def _digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def _json_file(path: Path) -> tuple[dict, dict]:
    data = path.read_bytes()
    value = json.loads(data.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Se esperaba un objeto JSON: {path.name}")
    return value, {"path": path, "sha256": sha256(data).hexdigest(), "bytes": len(data)}


def _utc(value: str | None = None) -> str:
    if value is None:
        return datetime.now(timezone.utc).isoformat()
    if not isinstance(value, str):
        raise ValueError("La fecha debe ser texto ISO 8601 con zona horaria.")
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("Fecha inválida; usa ISO 8601 con zona horaria.") from exc
    if stamp.tzinfo is None or stamp.utcoffset() is None:
        raise ValueError("La fecha de revisión necesita zona horaria.")
    return stamp.astimezone(timezone.utc).isoformat()


def _integer(value, name: str) -> int:
    if type(value) is not int or value < 1:
        raise ValueError(f"{name} debe ser un entero positivo.")
    return value


def _pages(value, total: int, *, allow_empty: bool = False) -> list[int]:
    if isinstance(value, str):
        if value.strip().lower() == "all":
            return list(range(1, total + 1))
        result = []
        for token in value.split(","):
            match = re.fullmatch(r"\s*(\d+)(?:\s*-\s*(\d+))?\s*", token)
            if not match:
                raise ValueError("Páginas inválidas: usa all o una lista como 1,3-5.")
            first, last = int(match[1]), int(match[2] or match[1])
            if first < 1 or last < first or last > total:
                raise ValueError(f"Páginas fuera del intervalo 1–{total}.")
            result.extend(range(first, last + 1))
    elif isinstance(value, (list, tuple)):
        result = list(value)
    else:
        raise ValueError("Las páginas inspeccionadas deben declararse explícitamente.")
    if (not result and not allow_empty) or any(type(n) is not int or n < 1 or n > total for n in result):
        raise ValueError(f"Declara páginas válidas dentro del intervalo 1–{total}.")
    if len(set(result)) != len(result):
        raise ValueError("La lista de páginas contiene duplicados.")
    return sorted(result)


def _checklist(value: dict) -> dict:
    if not isinstance(value, dict) or set(value) != set(CHECKLIST_ITEMS):
        missing = sorted(set(CHECKLIST_ITEMS) - set(value)) if isinstance(value, dict) else list(CHECKLIST_ITEMS)
        extra = sorted(set(value) - set(CHECKLIST_ITEMS)) if isinstance(value, dict) else []
        raise ValueError(f"Checklist inválido. Faltan: {missing}; claves desconocidas: {extra}.")
    result = {}
    for key in CHECKLIST_ITEMS:
        entry = value[key]
        if not isinstance(entry, dict) or entry.get("status") not in _STATUSES:
            raise ValueError(f"Checklist {key}: declara status PASS, FAIL, NOT_APPLICABLE o NOT_RUN.")
        if set(entry) - {"status", "notes"}:
            raise ValueError(f"Checklist {key}: sólo se admiten status y notes.")
        note = entry.get("notes", "")
        if not isinstance(note, str):
            raise ValueError(f"Checklist {key}: notes debe ser texto.")
        if entry["status"] in {"FAIL", "NOT_APPLICABLE"} and not note.strip():
            raise ValueError(f"Checklist {key}: {entry['status']} necesita una justificación.")
        result[key] = {"status": entry["status"], "notes": note.strip()}
    return result


def _findings(value, pages: list[int]) -> list[dict]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError("Los hallazgos deben ser una lista JSON.")
    result = []
    for finding in value:
        if not isinstance(finding, dict) or set(finding) - {"description", "severity", "page", "item"}:
            raise ValueError("Cada hallazgo admite description, severity, page e item.")
        description = finding.get("description", "")
        severity = finding.get("severity", "WARNING")
        if not isinstance(description, str) or not description.strip() or severity not in {"INFO", "WARNING", "ERROR"}:
            raise ValueError("Cada hallazgo necesita description y severity INFO, WARNING o ERROR.")
        entry = {"description": description.strip(), "severity": severity}
        if "page" in finding:
            if type(finding["page"]) is not int or finding["page"] not in pages:
                raise ValueError("La página de un hallazgo debe estar entre las páginas inspeccionadas.")
            entry["page"] = finding["page"]
        if "item" in finding:
            if finding["item"] not in CHECKLIST_ITEMS:
                raise ValueError("El ítem de un hallazgo debe pertenecer al checklist.")
            entry["item"] = finding["item"]
        result.append(entry)
    return result


def _preview_file(folder: Path, entry: dict) -> dict:
    if not isinstance(entry, dict):
        raise ValueError("Entrada de imagen inválida en PREVIEW.json.")
    name, expected = entry.get("path"), entry.get("sha256")
    if not isinstance(name, str) or "\\" in name:
        raise ValueError("Ruta de imagen inválida en PREVIEW.json.")
    relative = PurePosixPath(name)
    if relative.is_absolute() or ".." in relative.parts or not relative.parts:
        raise ValueError("La imagen de revisión debe estar dentro de la carpeta preview.")
    path = (folder / name).resolve()
    if not path.is_relative_to(folder.resolve()):
        raise ValueError("La imagen de revisión sale de la carpeta preview.")
    if not isinstance(expected, str) or not _HASH.fullmatch(expected) or _digest(path) != expected:
        raise ValueError(f"La imagen de revisión no corresponde a su SHA-256: {name}")
    return {"path": path, "sha256": expected, "bytes": path.stat().st_size}


def _collect(pdf: Path, preview_path: Path, audit_path: Path, run_path: Path | None) -> dict:
    _integer(pdf.stat().st_size, "Tamaño del PDF")
    pdf_hash = _digest(pdf)
    preview, preview_file = _json_file(preview_path)
    audit, audit_file = _json_file(audit_path)
    if preview.get("schema") != "ialp.preview.v1" or audit.get("schema") != "ialp.pdf_audit.v1":
        raise ValueError("Esquema de PREVIEW.json o AUDITORIA.json no reconocido.")
    if preview.get("pdf_sha256") != pdf_hash or audit.get("pdf_sha256") != pdf_hash:
        raise ValueError("PDF modificado o evidencias de otro PDF: SHA-256 no coincide.")
    if preview.get("status") != "PREVIEW_GENERATED":
        raise ValueError("PREVIEW.json no registra vistas generadas.")
    total = _integer(audit.get("pages"), "Número de páginas")
    if _integer(preview.get("total_pages"), "Páginas de PREVIEW.json") != total:
        raise ValueError("El total de páginas de auditoría y preview no coincide.")
    selected = _pages(preview.get("selected_pages"), total)
    images = preview.get("images")
    sheets = preview.get("contact_sheets", [])
    if not isinstance(images, list) or not isinstance(sheets, list):
        raise ValueError("PREVIEW.json necesita listas images y contact_sheets.")
    image_pages = [entry.get("page") if isinstance(entry, dict) else None for entry in images]
    if _pages(image_pages, total) != selected:
        raise ValueError("PREVIEW.json no contiene exactamente una imagen por página declarada.")
    verified = [_preview_file(preview_path.parent, entry) for entry in images + sheets]
    if len({entry["path"] for entry in verified}) != len(verified):
        raise ValueError("PREVIEW.json repite rutas de imágenes.")
    for key, allowed in (("TEXT_AUDIT", {"PASS", "FAIL"}),
                         ("CONTENT_CHECK", {"PASS", "FAIL", "NOT_RUN"}),
                         ("automatic_status", {"PASS", "FAIL"})):
        if audit.get(key) not in allowed:
            raise ValueError(f"AUDITORIA.json no declara un estado válido para {key}.")
    artifacts = {"pdf": {"path": pdf, "sha256": pdf_hash, "bytes": pdf.stat().st_size},
                 "preview": preview_file, "audit": audit_file}
    automatic = {key: audit[key] for key in ("TEXT_AUDIT", "CONTENT_CHECK", "automatic_status")}
    if run_path is not None:
        run, run_file = _json_file(run_path)
        if run.get("schema") != "ialp.run.v1" or run.get("pdf_sha256") != pdf_hash:
            raise ValueError("RUN.json no corresponde a este PDF o su esquema no es válido.")
        artifacts["run"] = run_file
        automatic["run_status"] = run.get("status", "NOT_RUN")
    return {"total_pages": total, "selected_pages": selected, "artifacts": artifacts,
            "verified_images": verified, "automatic_checks": automatic,
            "evidence_checks": {"pdf_hash": "PASS", "preview_images": "PASS",
                                "images_verified": len(images), "contact_sheets_verified": len(sheets)}}


def _conclusion(snapshot: dict, pages: list[int], result: str, checklist: dict, findings: list[dict]) -> dict:
    blockers = []
    failed = result == "FAIL"
    if failed:
        blockers.append("El revisor declara FAIL.")
    if pages != list(range(1, snapshot["total_pages"] + 1)):
        blockers.append("La inspección no cubre todas las páginas del PDF.")
    for key, entry in checklist.items():
        if entry["status"] == "FAIL":
            failed = True
            blockers.append(f"Checklist {key}: FAIL.")
        elif entry["status"] == "NOT_RUN":
            blockers.append(f"Checklist {key}: NOT_RUN.")
    if any(entry["severity"] == "ERROR" for entry in findings):
        failed = True
        blockers.append("Hay hallazgos visuales con severity ERROR.")
    for key, value in snapshot["automatic_checks"].items():
        expected = "AUTOMATIC_CHECKS_PASSED" if key == "run_status" else "PASS"
        if value != expected:
            blockers.append(f"Control automático {key}: {value}.")
    state = "FAIL" if failed else ("PARTIAL" if blockers else "PASS")
    return {"VISUAL_REVIEW": state, "eligible_for_final_delivery": state == "PASS", "blockers": blockers}


def _assert_unchanged(snapshot: dict) -> None:
    for entry in list(snapshot["artifacts"].values()) + snapshot["verified_images"]:
        if _digest(entry["path"]) != entry["sha256"]:
            raise ValueError(f"La evidencia cambió durante el registro: {entry['path'].name}")


def record_visual_review(pdf_path: str | Path, *, reviewer: str, inspected_pages,
                         result: str, checklist: dict, notes: str = "", findings=None,
                         preview_path: str | Path | None = None, audit_path: str | Path | None = None,
                         run_path: str | Path | None = None, reviewed_at: str | None = None,
                         output_path: str | Path | None = None) -> dict:
    """Write and return an explicit review. Incomplete/failed reviews are retained.

    PASS eligibility requires all pages, all applicable checks PASS, the three
    audit states PASS and, when RUN exists, AUTOMATIC_CHECKS_PASSED. This function
    does not package files or change pipeline evidence. Invalid/mismatched
    evidence raises ValueError/OSError before writing a receipt.
    """
    pdf = Path(pdf_path).resolve()
    preview = Path(preview_path).resolve() if preview_path else pdf.parent / "verificacion_visual" / "PREVIEW.json"
    audit = Path(audit_path).resolve() if audit_path else pdf.parent / "AUDITORIA.json"
    run = Path(run_path).resolve() if run_path else (pdf.parent / "RUN.json" if (pdf.parent / "RUN.json").exists() else None)
    output = Path(output_path).resolve() if output_path else pdf.parent / "REVISION_VISUAL.json"
    snapshot = _collect(pdf, preview, audit, run)
    if not isinstance(reviewer, str) or not reviewer.strip():
        raise ValueError("Es obligatorio identificar al revisor.")
    if result not in {"PASS", "FAIL"}:
        raise ValueError("El veredicto debe declararse como PASS o FAIL.")
    if not isinstance(notes, str):
        raise ValueError("Las notas deben ser texto.")
    pages = _pages(inspected_pages, snapshot["total_pages"])
    if not set(pages).issubset(snapshot["selected_pages"]):
        raise ValueError("Se declaran páginas inspeccionadas que no están en PREVIEW.json.")
    checks = _checklist(checklist)
    observations = _findings(findings, pages)
    verdict = _conclusion(snapshot, pages, result, checks, observations)
    record = {
        "schema": "ialp.visual_review.v1", "pdf": pdf.name,
        "pdf_sha256": snapshot["artifacts"]["pdf"]["sha256"],
        "reviewer": reviewer.strip(), "reviewed_at": _utc(reviewed_at), "recorded_at": _utc(),
        "declared_verdict": result, "total_pages": snapshot["total_pages"],
        "inspected_pages": pages,
        "coverage": "ALL_PAGES" if len(pages) == snapshot["total_pages"] else "PARTIAL",
        "checklist": checks, "notes": notes.strip(), "findings": observations,
        **verdict, "automatic_checks": snapshot["automatic_checks"],
        "evidence_checks": snapshot["evidence_checks"],
        "evidence": {key: {**entry, "path": Path(os.path.relpath(entry["path"], output.parent)).as_posix()}
                     for key, entry in snapshot["artifacts"].items()},
        "scope": "Declaración explícita del revisor. Las huellas vinculan los archivos; no prueban la inspección ni autentican su identidad. Validar de nuevo antes de la entrega.",
    }
    protected = {entry["path"] for entry in list(snapshot["artifacts"].values()) + snapshot["verified_images"]}
    if output in protected:
        raise ValueError("El recibo no puede sobrescribir el PDF ni una evidencia de entrada.")
    _assert_unchanged(snapshot)
    data = json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=output.parent, prefix=".review-", suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        os.replace(temporary, output)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()
    return record


def validate_visual_review(receipt_path: str | Path, *, pdf_path: str | Path | None = None,
                           preview_path: str | Path | None = None, audit_path: str | Path | None = None,
                           run_path: str | Path | None = None) -> dict:
    """Recheck integrity and eligibility without modifying any artifact.

    Returns status VALID or INVALIDATED, VISUAL_REVIEW, eligible_for_final_delivery,
    issues (integrity/schema errors), blockers, receipt_sha256 and the receipt.
    A VALID receipt can still be PARTIAL or FAIL. Optional paths relocate bound
    artifacts, but their exact bytes must match the recorded SHA-256 values.
    """
    validation = {"schema": "ialp.visual_review_validation.v1", "status": "INVALIDATED",
                  "VISUAL_REVIEW": "INVALIDATED", "eligible_for_final_delivery": False,
                  "issues": [], "blockers": [], "receipt_sha256": None, "receipt": {}}
    try:
        source = Path(receipt_path).resolve()
        receipt, receipt_file = _json_file(source)
        validation.update(receipt=receipt, receipt_sha256=receipt_file["sha256"])
        if receipt.get("schema") != "ialp.visual_review.v1":
            raise ValueError("Esquema de revisión visual no reconocido.")
        evidence = receipt.get("evidence")
        if not isinstance(evidence, dict) or not {"pdf", "preview", "audit"}.issubset(evidence) or set(evidence) - {"pdf", "preview", "audit", "run"}:
            raise ValueError("El recibo no identifica las evidencias obligatorias.")
        overrides = {"pdf": pdf_path, "preview": preview_path, "audit": audit_path, "run": run_path}
        if run_path is not None and "run" not in evidence:
            raise ValueError("RUN.json no estaba vinculado a esta revisión; registra una nueva revisión.")
        paths = {}
        for key, entry in evidence.items():
            if not isinstance(entry, dict) or not isinstance(entry.get("path"), str) or not isinstance(entry.get("sha256"), str) or not _HASH.fullmatch(entry["sha256"]):
                raise ValueError(f"Referencia de evidencia inválida: {key}.")
            _integer(entry.get("bytes"), f"Tamaño de evidencia {key}")
            paths[key] = Path(overrides[key]).resolve() if overrides[key] else (source.parent / entry["path"]).resolve()
        snapshot = _collect(paths["pdf"], paths["preview"], paths["audit"], paths.get("run"))
        for key, entry in snapshot["artifacts"].items():
            if entry["sha256"] != evidence[key]["sha256"] or entry["bytes"] != evidence[key]["bytes"]:
                raise ValueError(f"Evidencia modificada desde la revisión: {key}.")
        if not isinstance(receipt.get("reviewer"), str) or not receipt["reviewer"].strip():
            raise ValueError("El recibo no identifica al revisor.")
        if any(not isinstance(receipt.get(key), str) for key in ("reviewed_at", "recorded_at")):
            raise ValueError("El recibo no contiene fechas explícitas de revisión y registro.")
        _utc(receipt.get("reviewed_at", ""))
        _utc(receipt.get("recorded_at", ""))
        if receipt.get("declared_verdict") not in {"PASS", "FAIL"} or not isinstance(receipt.get("notes"), str):
            raise ValueError("El recibo no contiene una declaración de revisión válida.")
        pages = _pages(receipt.get("inspected_pages"), snapshot["total_pages"])
        if not set(pages).issubset(snapshot["selected_pages"]):
            raise ValueError("El recibo declara páginas sin vistas verificables.")
        checks = _checklist(receipt.get("checklist"))
        observations = _findings(receipt.get("findings"), pages)
        verdict = _conclusion(snapshot, pages, receipt["declared_verdict"], checks, observations)
        expected = {**verdict, "pdf_sha256": snapshot["artifacts"]["pdf"]["sha256"],
                    "total_pages": snapshot["total_pages"], "inspected_pages": pages,
                    "coverage": "ALL_PAGES" if len(pages) == snapshot["total_pages"] else "PARTIAL",
                    "checklist": checks, "findings": observations,
                    "automatic_checks": snapshot["automatic_checks"], "evidence_checks": snapshot["evidence_checks"]}
        for key, value in expected.items():
            if receipt.get(key) != value:
                raise ValueError(f"Estado incoherente en el recibo: {key}.")
        _assert_unchanged(snapshot)
        if _digest(source) != receipt_file["sha256"]:
            raise ValueError("El recibo cambió durante la validación.")
        validation.update(status="VALID", **verdict)
    except (OSError, ValueError, TypeError, KeyError) as exc:
        validation["issues"].append(str(exc))
    return validation
