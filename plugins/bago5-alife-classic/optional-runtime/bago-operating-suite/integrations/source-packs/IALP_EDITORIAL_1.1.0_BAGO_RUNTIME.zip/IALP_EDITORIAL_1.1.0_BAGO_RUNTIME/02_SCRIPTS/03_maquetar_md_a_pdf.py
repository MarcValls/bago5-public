#!/usr/bin/env python3
"""Markdown -> HTML editable -> PDF. La revisión visual es un paso separado."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from ialp.layout import build_document, render_pdf, sha256


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("pdf")
    parser.add_argument("--html")
    parser.add_argument("--family", default="auto", choices=["auto", "puerta", "doctrina", "sintesis"])
    parser.add_argument("--engine", default="weasyprint", choices=["weasyprint", "auto", "browser"])
    parser.add_argument("--source-dir", help="Carpeta original de los recursos del manuscrito")
    parser.add_argument("--report")
    parser.add_argument("--expected-text")
    parser.add_argument("--browser-no-sandbox", action="store_true")
    args = parser.parse_args()
    source, pdf = Path(args.source).resolve(), Path(args.pdf).resolve()
    html_path = Path(args.html).resolve() if args.html else pdf.with_suffix(".html")
    if html_path.parent != pdf.parent:
        parser.error("HTML y PDF deben compartir carpeta para conservar recursos portables")
    pdf.parent.mkdir(parents=True, exist_ok=True)
    try:
        document, expected, report = build_document(source.read_text(encoding="utf-8"), html_path.parent,
            source_dir=args.source_dir or source.parent, filename=source.name, family=args.family)
        html_path.write_text(document, encoding="utf-8")
        expected_path = Path(args.expected_text) if args.expected_text else pdf.with_suffix(".expected.txt")
        expected_path.write_text(expected, encoding="utf-8")
        report.update(render_pdf(html_path, pdf, args.engine, args.browser_no_sandbox))
        report.update(status="GENERATED", source_sha256=sha256(source), html_sha256=sha256(html_path),
                      expected_text_sha256=sha256(expected_path), visual_review="NOT_RUN")
        report_path = Path(args.report) if args.report else pdf.with_suffix(".layout.json")
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except Exception as exc:
        parser.exit(1, f"ERROR de maquetación: {exc}\n")
    print(f"GENERATED: {pdf.name} | motor={report['engine']} | familia={report['metadata']['family']} | revisión visual=NOT_RUN")


if __name__ == "__main__":
    main()
