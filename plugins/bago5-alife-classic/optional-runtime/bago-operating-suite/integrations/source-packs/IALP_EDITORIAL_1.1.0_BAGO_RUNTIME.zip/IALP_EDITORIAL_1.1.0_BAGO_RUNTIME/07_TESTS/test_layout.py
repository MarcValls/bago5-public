"""Independent HTML composition regressions; no PDF generation in these tests."""
from __future__ import annotations

import hashlib
import re
import sys
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "02_SCRIPTS"))

from ialp.layout import build_document, expected_text_from_markdown


class DocumentProbe(HTMLParser):
    """Inspect output semantics without relying on the renderer's report."""
    def __init__(self, document):
        super().__init__(convert_charrefs=True)
        self.in_main = False
        self.in_toc = False
        self.main_text = []
        self.main_headings = []
        self.toc_links = []
        self.images = []
        self.page_breaks = 0
        self.heading = None
        self.feed(document)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "main":
            self.in_main = True
        if tag == "section" and "toc" in attrs.get("class", "").split():
            self.in_toc = True
        if self.in_toc and tag == "a":
            self.toc_links.append(attrs.get("href"))
        if self.in_main and re.fullmatch(r"h[1-6]", tag):
            self.heading = {"tag": tag, "id": attrs.get("id"), "text": ""}
        if self.in_main and tag == "img":
            self.images.append(attrs.get("src"))
        if self.in_main and "page-break" in attrs.get("class", "").split():
            self.page_breaks += 1

    def handle_endtag(self, tag):
        if self.heading and tag == self.heading["tag"]:
            self.main_headings.append(self.heading)
            self.heading = None
        if tag == "main":
            self.in_main = False
        if tag == "section" and self.in_toc:
            self.in_toc = False
        if self.in_main and tag in {"p", "div", "li", "td", "th", "pre", "h1", "h2", "h3"}:
            self.main_text.append("\n")

    def handle_data(self, data):
        if self.in_main:
            self.main_text.append(data)
        if self.heading:
            self.heading["text"] += data

    @property
    def visible_main(self):
        return "".join(self.main_text)


class LayoutIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.source = self.folder / "source"
        self.output = self.folder / "output"
        self.source.mkdir()

    def build(self, markdown, **kwargs):
        document, expected, report = build_document(
            markdown, self.output, source_dir=self.source, **kwargs,
        )
        return DocumentProbe(document), expected, report, document

    def svg(self, relative, color="navy"):
        path = self.source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"><rect width="20" height="20" fill="{color}"/></svg>', encoding="utf-8")
        return path

    def test_headings_in_code_stay_visible_but_are_not_index_entries(self):
        source = "# Apertura\n\n```markdown\n# Encabezado ficticio\n## Otro ejemplo\n```\n\n## Sección real\nContenido.\n"
        probe, expected, _, _ = self.build(source)
        self.assertEqual([h["text"] for h in probe.main_headings], ["Apertura", "Sección real"])
        self.assertEqual(len(probe.toc_links), 2)
        self.assertIn("# Encabezado ficticio", probe.visible_main)
        self.assertIn("# Encabezado ficticio", expected)

    def test_consecutive_h1_chapters_are_all_in_index(self):
        probe, _, _, _ = self.build("# Uno\n\n# Dos\n\n# Tres\n")
        self.assertEqual([h["text"] for h in probe.main_headings], ["Uno", "Dos", "Tres"])
        self.assertEqual(probe.toc_links, ["#" + h["id"] for h in probe.main_headings])

    def test_repeated_and_suffix_shaped_titles_have_unique_targets(self):
        probe, _, _, _ = self.build("# Tema\n\n# Tema\n\n# Tema-2\n\n# Tema\n")
        identifiers = [h["id"] for h in probe.main_headings]
        self.assertEqual(len(identifiers), len(set(identifiers)))
        self.assertEqual(probe.toc_links, ["#" + identifier for identifier in identifiers])

    def test_setext_heading_is_included_but_h4_not_in_three_level_index(self):
        probe, _, _, _ = self.build("Capítulo real\n=============\n\n## Sección\n\n#### Detalle\nTexto.\n")
        self.assertEqual([h["text"] for h in probe.main_headings], ["Capítulo real", "Sección", "Detalle"])
        self.assertEqual(probe.toc_links, ["#" + h["id"] for h in probe.main_headings[:2]])

    def test_yaml_frontmatter_drives_family_and_does_not_leak_to_body(self):
        for volume, family in ((0, "puerta"), (1, "doctrina"), (11, "doctrina"), (12, "sintesis"), (13, "sintesis")):
            with self.subTest(volume=volume):
                probe, expected, report, document = self.build(
                    f'---\nvolume_number: {volume}\nvolume_title: "Título: editorial"\nauthor: "Marc"\n---\n# Contenido\nTexto íntegro.\n'
                )
                self.assertEqual(report["metadata"]["family"], family)
                self.assertEqual(report["metadata"]["title"], "Título: editorial")
                self.assertIn("Título: editorial", document)
                self.assertNotIn("volume_number", probe.visible_main)
                self.assertNotIn("volume_number", expected)
                self.assertIn("Texto íntegro.", expected)

    def test_explicit_family_override_has_priority(self):
        _, _, report, _ = self.build("---\nvolume_number: 13\nfamily: sintesis\n---\n# Contenido\n", family="puerta")
        self.assertEqual(report["metadata"]["family"], "puerta")
        with self.assertRaises(ValueError):
            self.build("# Contenido\n", family="desconocida")

    def test_volume_inference_from_real_title_preserves_legacy_capability(self):
        _, _, report, _ = self.build("# Volumen 13 — Arquitectura\n\n## Contenido\nTexto.\n")
        self.assertEqual(report["metadata"]["volume_number"], 13)
        self.assertEqual(report["metadata"]["family"], "sintesis")

    def test_volume_inference_from_filename_does_not_read_example_code(self):
        _, _, report, _ = self.build("```markdown\n# Volumen 99 — Ejemplo\n```\n\n# Contenido\nTexto.\n", filename="Volumen_12_Anexo.md")
        self.assertEqual(report["metadata"]["volume_number"], 12)
        self.assertEqual(report["metadata"]["family"], "sintesis")

    def test_markdown_and_html_images_are_copied_with_portable_references(self):
        first = self.svg("figuras/diagrama azul.svg")
        second = self.svg("figuras/secundario.svg", "gold")
        probe, _, report, _ = self.build('![Diagrama](<figuras/diagrama azul.svg>)\n\n<img src="figuras/secundario.svg" alt="Segundo">\n')
        self.assertEqual(len(probe.images), 2)
        expected_bytes = {first.read_bytes(), second.read_bytes()}
        copied_bytes = set()
        for reference in probe.images:
            path = (self.output / reference).resolve()
            self.assertTrue(path.is_relative_to(self.output.resolve()))
            self.assertTrue(path.is_file())
            copied_bytes.add(path.read_bytes())
        self.assertEqual(copied_bytes, expected_bytes)
        recorded_hashes = {entry["sha256"] for entry in report["resources"]}
        self.assertEqual(recorded_hashes, {hashlib.sha256(value).hexdigest() for value in expected_bytes})

    def test_same_basename_different_images_cannot_overwrite_each_other(self):
        first = self.svg("uno/imagen.svg", "red")
        second = self.svg("dos/imagen.svg", "blue")
        probe, _, _, _ = self.build("![Rojo](uno/imagen.svg)\n\n![Azul](dos/imagen.svg)\n")
        self.assertEqual(len(set(probe.images)), 2)
        self.assertEqual({(self.output / ref).read_bytes() for ref in probe.images}, {first.read_bytes(), second.read_bytes()})

    def test_missing_local_resource_blocks_document(self):
        for markup in ('![Ausente](no_existe.svg)', '<img src="no_existe.svg">'):
            with self.subTest(markup=markup), self.assertRaises(FileNotFoundError):
                self.build(markup)

    def test_remote_and_outside_resources_are_not_silently_used(self):
        for markup in ('![Remoto](https://example.invalid/figura.svg)', '<img src="https://example.invalid/figura.svg">'):
            with self.subTest(markup=markup), self.assertRaises(ValueError):
                self.build(markup)
        outside = self.folder / "outside.svg"
        outside.write_text('<svg xmlns="http://www.w3.org/2000/svg"/>', encoding="utf-8")
        with self.assertRaises(ValueError):
            self.build("![Exterior](../outside.svg)")

    def test_expected_text_keeps_readable_content_tables_footnotes_and_escapes(self):
        source = "# Título principal\n\nTexto íntegro: A &amp; B, \\*literal\\*, `a < b && c`, [enlace visible](https://example.invalid).\n\n| Nombre | Valor |\n|---|---|\n| Entidad | 23,5 |\n\nTérmino\n: Definición completa\n\nReferencia[^nota].\n\n[^nota]: Nota al pie conservada.\n"
        probe, expected, _, _ = self.build(source)
        expected_normal = " ".join(expected.split())
        actual_normal = " ".join(probe.visible_main.split())
        for visible in ("Título principal", "Texto íntegro", "A & B", "*literal*", "a < b && c", "enlace visible", "Nombre", "Valor", "Entidad", "23,5", "Término", "Definición completa", "Nota al pie conservada"):
            with self.subTest(visible=visible):
                self.assertIn(visible, expected_normal)
                self.assertIn(visible, actual_normal)

    def test_code_entities_are_literal_in_expected_text(self):
        source = "Ejemplo `&amp;` y `&lt;` con `\\*x\\*`.\n\n```text\n&lt;visible&gt;\n```\n"
        probe, expected, _, _ = self.build(source)
        for literal in ("&amp;", "&lt;", r"\*x\*", "&lt;visible&gt;"):
            self.assertIn(literal, expected)
            self.assertIn(literal, probe.visible_main)

    def test_inline_newpage_example_is_not_removed_from_expected_text(self):
        source = "`" + chr(92) + "newpage`\n"
        self.assertIn(chr(92) + "newpage", expected_text_from_markdown(source))
        probe, expected, _, _ = self.build(source)
        self.assertEqual(probe.page_breaks, 0)
        self.assertIn(chr(92) + "newpage", probe.visible_main)
        self.assertIn(chr(92) + "newpage", expected)

    def test_pagebreak_lines_are_commands_but_fenced_example_stays_visible(self):
        directive = chr(92) + "newpage"
        source = "# Título\n\nAntes.\n\n" + directive + "\n" + directive + "\n\nDespués.\n\n```text\n" + directive + "\n```\n"
        probe, expected, _, _ = self.build(source)
        self.assertGreaterEqual(probe.page_breaks, 1)
        self.assertIn("Antes.", expected)
        self.assertIn("Después.", expected)
        self.assertEqual(expected.count(directive), 1)
        self.assertEqual(probe.visible_main.count(directive), 1)
        self.assertNotIn("ewpage", [line.strip() for line in probe.visible_main.splitlines()])

    def test_benign_raw_html_keeps_text_and_formatting(self):
        probe, expected, _, document = self.build('<div class="card"><strong>A &amp; B</strong> <em>contenido íntegro</em>.</div>\n')
        self.assertIn("A & B", probe.visible_main)
        self.assertIn("contenido íntegro", expected)
        self.assertIn('<div class="card">', document)
        self.assertIn("<strong>", document)

    def test_active_raw_html_is_rejected_before_render(self):
        for markup in ('<script>alert(1)</script>', '<iframe src="https://example.invalid"></iframe>', '<div onclick="alert(1)">Texto</div>', '<meta http-equiv="refresh" content="0;url=https://example.invalid/">', '<base href="https://example.invalid/">'):
            with self.subTest(markup=markup), self.assertRaises(ValueError):
                self.build(markup)

    def test_metadata_is_escaped_and_cannot_inject_active_tags(self):
        _, _, _, document = self.build('---\nvolume_title: "<script>alert(1)</script>"\nauthor: "<b>Autor</b>"\n---\n# Contenido\n')
        self.assertNotIn("<script>", document)
        self.assertIn("&lt;script&gt;", document)
        self.assertIn("&lt;b&gt;Autor&lt;/b&gt;", document)


if __name__ == "__main__":
    unittest.main()
