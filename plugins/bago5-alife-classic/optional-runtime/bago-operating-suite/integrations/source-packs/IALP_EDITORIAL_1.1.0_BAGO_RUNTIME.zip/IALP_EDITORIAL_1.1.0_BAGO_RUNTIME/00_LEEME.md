# IA. LA PREGUNTA — KIT DE MAQUETACIÓN EDITORIAL v1.1.0

Este kit transforma una fuente Markdown en una edición con portada, índice paginado, estructuras visuales y PDF mediante HTML/CSS y WeasyPrint. Conserva las fuentes y los recursos, registra las transformaciones y separa generación, controles automáticos, revisión visual y cierre de entrega.

**Empieza por el manual del propio kit:** fuente `10_MANUAL/MANUAL_DEL_KIT.md` y PDF de la demostración incluida en `10_MANUAL/GENERADO/MANUAL_DEL_KIT_EDITORIAL.pdf`. El manual se produce con el mismo pipeline que se utiliza para los demás documentos. Los informes y el recibo que acompañan al PDF indican el alcance real de la comprobación.

## Qué incluye

| Necesidad | Componente y alcance |
| --- | --- |
| Texto, portadas e índice | Mistune, plantillas Jinja2, CSS editorial y WeasyPrint. Familias `puerta`, `doctrina` y `sintesis`. |
| Código y metadatos | Pygments para resaltado y PyYAML para frontmatter. Los ejemplos de código se conservan como código. |
| Mermaid y mapas conceptuales | Mermaid CLI local, SVG por defecto y etiquetas HTML desactivadas. |
| Grafos DOT | Bloques `dot` o `graphviz` a SVG mediante el ejecutable externo `dot`. |
| Gráficos de datos | Bloques `chart` JSON a SVG con Matplotlib: barras, líneas y mapas de calor. |
| Tablas desde XLSX | Bloques `spreadsheet` JSON con ruta, hoja y rango; openpyxl extrae valores a una tabla Markdown. |
| Hojas editables | XlsxWriter genera XLSX desde JSON, con cabeceras, formatos simples, filtros e inmovilización. |
| Auditoría e imágenes de revisión | PyMuPDF y Pillow; controles textuales, conservación de texto, PNG por página y contact sheets. |
| Trazabilidad | Fuentes originales, informes JSON, huellas SHA-256, recibo visual y paquetes con inventario. |

No incorpora composición matemática LaTeX ni cartografía geográfica. Un bloque `math` se muestra como código; un mapa conceptual Mermaid o un gráfico de calor no es un mapa geográfico. Importar un rango XLSX no reproduce el diseño completo de una hoja de Excel ni calcula sus fórmulas.

## Instalación

Ejecuta los comandos desde la raíz del kit. Esta edición se ha trabajado con Python 3.12 en Linux; las instrucciones para otros sistemas no equivalen a una prueba de ejecución en ellos.

### Entorno Python

Linux o macOS, con Python 3.12 disponible:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

Windows/PowerShell, con Python 3.12 disponible:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\Activate.ps1
```

Los comandos posteriores usan `python` del entorno activado. Si no activas el entorno, sustituye `python` por la ruta de su ejecutable, por ejemplo `.\.venv\Scripts\python.exe` en Windows.

`requirements.txt` incluye el núcleo editorial y los componentes visuales Python, con versiones directas fijadas para esta edición. No instala Pango, Node, el navegador de Puppeteer ni el ejecutable nativo de Graphviz. Las dependencias de pruebas se encuentran por separado en `requirements-dev.txt`.

WeasyPrint necesita sus bibliotecas del sistema. Sigue la [instalación oficial de WeasyPrint 68.0](https://doc.courtbouillon.org/weasyprint/v68.0/first_steps.html), especialmente el apartado Windows para Pango/MSYS2 y la localización de DLL. Comprueba la instalación del entorno con:

```text
python -m weasyprint --info
```

Windows y el wrapper PowerShell figuran como `NOT_RUN` en la comprobación de esta edición. No se garantiza su funcionamiento a partir de la ejecución Linux; los comandos se proporcionan como procedimiento de instalación que debe verificarse en el sistema de destino.

### Mermaid

Instala Node **22.13.0 o posterior** y npm. Desde la raíz:

```text
node --version
npm ci
```

El lockfile fija `@mermaid-js/mermaid-cli` **12.0.0** y el pipeline busca su ejecutable local. No requiere una instalación global. Si falta el navegador que usa Puppeteer:

```text
npx puppeteer browsers install chrome-headless-shell
```

La instalación del navegador requiere descarga y puede necesitar bibliotecas del sistema. Consulta la [documentación de Puppeteer](https://pptr.dev/guides/installation) si su lanzamiento falla. El navegador de Mermaid renderiza diagramas; no cambia el motor WeasyPrint del PDF editorial.

### Graphviz

Instala [Graphviz para tu sistema](https://graphviz.org/download/) y deja `dot` accesible en `PATH`. El paquete Python `graphviz` no instala ese ejecutable. Comprueba:

```text
dot -V
```

DOT solo es necesario para documentos con bloques `dot` o `graphviz`. Mermaid solo es necesario cuando se renderizan bloques Mermaid. El manual de demostración utiliza ambos.

## Generar el manual con el propio kit

La hoja editable del ejemplo está incluida. Para volver a generarla desde sus datos declarativos:

```text
python 02_SCRIPTS/08_crear_hoja.py 10_MANUAL/DATOS_MANUAL.json 10_MANUAL/DATOS_MANUAL.xlsx --report 10_MANUAL/DATOS_MANUAL_GENERACION.json
```

Después genera el manual:

```text
python 02_SCRIPTS/07_pipeline_ialp.py 10_MANUAL/MANUAL_DEL_KIT.md --outdir SALIDA_MANUAL
```

Obtendrás `SALIDA_MANUAL/MANUAL_DEL_KIT_EDITORIAL.pdf`, HTML editable, fuentes, recursos, informes, vistas de todas las páginas y `MANUAL_DEL_KIT_BORRADOR.zip`. Una generación completa sigue necesitando inspección visual y cierre. La carpeta de salida debe ser nueva o estar vacía; para corregir y repetir, usa otra, por ejemplo `SALIDA_MANUAL_02`.

## Generar un volumen propio

Parte de `01_PLANTILLA/PLANTILLA_VOLUMEN_IALP.md`. Mantén las imágenes y datos del documento dentro de la carpeta de su fuente o de sus subcarpetas:

```text
python 02_SCRIPTS/07_pipeline_ialp.py MI_VOLUMEN.md --outdir SALIDA
```

Opciones principales:

| Opción | Efecto |
| --- | --- |
| `--clean-mode explicit` | Predeterminada: solo elimina los marcadores internos documentados. |
| `--clean-mode preserve` | Conserva el texto sin eliminaciones de limpieza. |
| `--clean-mode legacy` | Activa reglas históricas adicionales; requiere revisar sus posibles eliminaciones. |
| `--family puerta`, `doctrina` o `sintesis` | Fuerza una familia; el valor predeterminado es `auto`. |
| `--mmdc RUTA` | Indica un ejecutable Mermaid específico. |
| `--pages all` | Predeterminada: genera vistas de todas las páginas. |
| `--pages sample` | Genera una muestra para diagnóstico; no permite acreditar revisión completa. |
| `--skip-mermaid` | Conserva los bloques Mermaid como código y registra los omitidos como `SKIPPED`. |
| `--patterns ARCHIVO` | Usa un perfil de patrones de auditoría específico y trazable. |

WeasyPrint es el motor predeterminado. Las opciones avanzadas `--engine auto` y `--engine browser` existen, pero el motor de navegador figura como `NOT_RUN` y no se presenta como equivalente verificado: una salida sin índice paginado queda con limitaciones.

El wrapper PowerShell conserva una vía de entrada alternativa:

```powershell
.\02_SCRIPTS\pipeline_ialp.ps1 -InputMd .\MI_VOLUMEN.md -OutDir .\SALIDA
```

## Limpieza: conservar la fuente y registrar cada retirada

El modo predeterminado `explicit` no elimina secciones por sus títulos ni palabras por aparecer en una lista. Solo retira los bloques internos delimitados fuera de código y del frontmatter YAML:

```html
<!-- IALP_CONTROL_START -->
Contenido de producción que se conserva en LIMPIEZA.json.
<!-- IALP_CONTROL_END -->
```

También reconoce el comentario `<!-- CONTROL INTERNO FUERA DEL LIBRO: ... -->`. Los marcadores incompletos o anidados provocan error. Los ejemplos de marcadores dentro de código no son instrucciones de limpieza.

`preserve` no realiza eliminaciones. `legacy` añade reglas históricas sobre determinados metadatos YAML, líneas como metadatos de estado/versión y secciones de `05_CONFIG/encabezados_control.txt`. Puede retirar contenido legítimo y secciones completas: úsalo expresamente, lee `LIMPIEZA.json` y contrasta los fragmentos retirados con la fuente. El registro conserva posiciones, motivos, texto y huellas, y comprueba que puede reconstruirse la entrada.

Las advertencias del preflight no dan permiso para una eliminación semántica. En un manual técnico, nombres de archivos, comandos, estados y procedimientos de revisión forman parte del contenido: no se consideran expediente por su sola presencia. Para decisiones editoriales asistidas usa los prompts de auditoría y limpieza.

## Estructuras visuales y hojas de cálculo

Los bloques `mermaid`, `dot`, `graphviz`, `chart` y `spreadsheet` se procesan al nivel principal del Markdown. Los ejemplos dentro de un bloque exterior de código se conservan; utiliza una cerca exterior de cuatro backticks para enseñar un ejemplo que use tres.

Mermaid funciona en modo `required` por defecto: si hay diagramas y falta `mmdc`, su navegador o falla el render, el pipeline falla y conserva el informe. Omitirlos exige `--skip-mermaid`. Si se omite algún bloque, `VISUALES.json` registra `SKIPPED`, `RUN.json` declara `GENERATED_WITH_LIMITATIONS` y no puede cerrarse una entrega final. El nombre histórico `02_render_mermaid_opcional.py` no implica omisión silenciosa.

SVG es el formato gráfico principal. El script de visuales admite `--format png` para Mermaid solo por elección expresa; no realiza un cambio automático de SVG a PNG. El SVG Mermaid recibe dimensiones intrínsecas a partir de su `viewBox`, conservando proporción, vectores y fuentes; el postproceso queda registrado. Los informes distinguen `RENDERED`, `SKIPPED` y `FAILED` y registran fuentes, resultados, errores y hashes.

`chart` admite barras, líneas y mapas de calor con datos internos en JSON, sin ejecutar código Python arbitrario. `spreadsheet` usa, por ejemplo, `{"path":"datos.xlsx","sheet":"Resumen","range":"A1:C5"}`; la primera fila del rango es la cabecera. Lee los valores guardados en el XLSX: una fórmula sin caché o con error provoca fallo, y el kit no la calcula.

`08_crear_hoja.py FUENTE.json SALIDA.xlsx --report INFORME.json` genera una hoja editable y conserva la fuente como `SALIDA.source.json`. Admite texto, enteros, decimales, porcentajes, valores básicos y fórmulas explícitas con resultado declarado. Un texto que empieza por `=` sigue siendo texto. Los resultados de fórmulas se guardan tal como se aportan; no se calculan ni se certifica su exactitud. Consulta el esquema y los ejemplos completos en el manual.

Las imágenes locales existentes se resuelven desde la carpeta original, se copian a la salida y quedan registradas. Las imágenes remotas deben guardarse antes junto a la fuente; no se descargan silenciosamente durante la maquetación.

## Revisar y cerrar una entrega

### 1. Inspección tras el render

Abre las imágenes de `verificacion_visual/` e inspecciona **todas las páginas** a tamaño legible. El índice, las tablas, los diagramas y el código requieren atención a detalle. Los contact sheets ayudan a comparar páginas, pero no sustituyen su lectura ampliada. Una muestra no aprueba las páginas omitidas.

### 2. Inspección tras cada corrección

Corrige fuente, datos o CSS y repite el pipeline en una carpeta nueva. Vuelve a auditar, generar vistas e inspeccionar todas las páginas de la versión final. El recibo de un PDF con otro SHA-256 no acredita la versión corregida. No modifiques a mano los archivos de generación para hacerlos coincidir con una aprobación previa.

### 3. Registrar la revisión antes del cierre

Copia `05_CONFIG/CHECKLIST_VISUAL.json` a `SALIDA/CHECKLIST_VISUAL_COMPLETADO.json` y complétalo tras la inspección. Incluye portada, índice, cortes/desbordes, diagramas/etiquetas, tablas/cuadrículas, cabeceras/pies y fuentes/contraste. Cada entrada acepta `PASS`, `FAIL`, `NOT_RUN` o `NOT_APPLICABLE`; los dos últimos no equivalen a una comprobación aprobada, y `NOT_APPLICABLE` requiere explicar por qué el elemento no existe. `FAIL` también requiere notas.

Solo cuando se hayan revisado todas las páginas y el checklist lo sustente:

```text
python 02_SCRIPTS/09_registrar_revision_visual.py SALIDA/MI_VOLUMEN_EDITORIAL.pdf --reviewer "Nombre real del revisor" --pages all --verdict PASS --checklist SALIDA/CHECKLIST_VISUAL_COMPLETADO.json --note "Inspección completa de esta versión final; observaciones en el checklist."
```

El comando escribe `REVISION_VISUAL.json`, con identidad declarada del revisor, cobertura, veredicto, checklist y huellas de las evidencias. Si revisó un agente, identifica al agente; no atribuyas esa revisión al usuario. Un hash vincula archivos, pero no prueba que alguien los haya inspeccionado.

Si hay defectos, registra `--verdict FAIL` con sus notas y corrige. Una revisión parcial o con ítems `NOT_RUN` no habilita entrega final. Una categoría realmente ausente puede marcarse `NOT_APPLICABLE` con justificación.

### 4. Validar la versión exacta y cerrar

Justo antes del cierre, comprueba que la revisión sigue correspondiendo al PDF y a sus evidencias actuales:

```text
python 02_SCRIPTS/09_registrar_revision_visual.py --validate SALIDA/REVISION_VISUAL.json
python 02_SCRIPTS/10_cerrar_entrega.py SALIDA
```

El cierre exige revisión visual completa `PASS`, controles automáticos superados, ningún visual `SKIPPED` o `FAILED` e integridad de los archivos de generación. Escribe `ENTREGA.json` con estado `FINAL_REVIEWED` y crea `MI_VOLUMEN_ENTREGA.zip` con inventario SHA-256. No incluye el ZIP borrador dentro del final y no modifica `RUN.json`.

## Interpretar los estados

| Estado o evidencia | Qué permite afirmar |
| --- | --- |
| `PREFLIGHT: REVIEW` | Hay advertencias de fuente que deben leerse; no autorizan borrado automático. |
| Visual `RENDERED` | Se generó el archivo del visual; falta comprobar cómo se ve en el PDF. |
| `RUN: AUTOMATIC_CHECKS_PASSED` | Se superaron los controles automáticos de esa ejecución. |
| `visual_review: NOT_RUN` en `RUN.json` | La generación no había recibido una inspección declarada; permanece como registro histórico. |
| `RUN: GENERATED_WITH_LIMITATIONS` | Se generó una salida con una limitación declarada; no habilita cierre final. |
| `RUN: FAILED` | La ejecución falló; el error y las evidencias disponibles permiten diagnosticarla. |
| `VISUAL_REVIEW: PASS` en un recibo válido | Se ha registrado una declaración completa, sin bloqueos, vinculada a los archivos actuales. |
| `ENTREGA: FINAL_REVIEWED` | El cierre comprobó sus requisitos y produjo el paquete final. |

La auditoría textual y la comparación de contenido no certifican significado ni legibilidad. La revisión visual no certifica la doctrina, la corrección matemática de fórmulas declaradas ni conformidad PDF/A o PDF/UA.

## Scripts y resultados

| Script | Función |
| --- | --- |
| `00_preflight_fuente.py` | Inspecciona la estructura de la fuente y advierte sin modificarla. |
| `01_limpiar_fuente_editorial.py` | Aplica `preserve`, `explicit` o `legacy`, con registro de eliminaciones. |
| `02_render_mermaid_opcional.py` | Procesa Mermaid, DOT, gráficos y rangos XLSX; informa fallos y omisiones. |
| `03_maquetar_md_a_pdf.py` | Genera HTML editable, recursos y PDF; informa motor y familia. |
| `04_auditar_pdf.py` | Ejecuta controles textuales y, con referencia, de conservación del texto. |
| `05_renderizar_verificacion.py` | Genera PNG y contact sheets; no declara una revisión visual. |
| `06_empaquetar_entrega.py` | Empaqueta archivos con inventario; por sí solo no otorga aprobación editorial. |
| `07_pipeline_ialp.py` | Orquesta generación, controles y borrador. |
| `08_crear_hoja.py` | Genera XLSX editable desde JSON. |
| `09_registrar_revision_visual.py` | Registra o valida una inspección declarada. |
| `10_cerrar_entrega.py` | Comprueba las evidencias actuales y cierra la entrega. |

La salida conserva el original, Markdown limpio y transformado, HTML, PDF, recursos y fuentes de visuales. Los informes principales son `PREFLIGHT.json`, `LIMPIEZA.json`, `VISUALES.json`, `MAQUETACION.json`, `AUDITORIA.json`, `RUN.json` y `verificacion_visual/PREVIEW.json`. El recibo visual y el cierre se añaden después de las comprobaciones correspondientes.

## Personalización y prompts

`04_CSS/` y `09_PLANTILLAS/` contienen la identidad y la composición. El volumen 0 usa `puerta`; los volúmenes 1–11, `doctrina`; y los volúmenes 12 en adelante, `sintesis`. La portada conserva la línea azul marino, diagonal clara y acento dorado.

`05_CONFIG/patrones_no_editoriales.txt` define patrones de auditoría. `05_CONFIG/encabezados_control.txt` interviene en la limpieza `legacy`, no en el modo predeterminado. Cambia una configuración por un motivo editorial explícito y vuelve a comprobar el resultado.

`03_PROMPTS/` conserva el flujo asistido: maestro, auditoría de fuente, limpieza, maquetación, QA visual, validación final, regeneración de colección y selección de gráficos. Todos exigen conservar contenido, distinguir estados y comprobar la versión final completa.

## Alcance de la evidencia

`06_EJEMPLO/` conserva un informe y una imagen heredados de v1.0 que mencionan un Volumen 13 de 105 páginas. El original no incluía el manuscrito ni ese PDF; la ejecución histórica no se ha reproducido. Su `PASS` no valida v1.1.0.

Para la edición actual, consulta la demostración del manual, sus informes y su recibo vigente. Las pruebas de `07_TESTS/` comprueban contratos concretos; algunas sustituyen herramientas externas mediante mocks y no equivalen a ejecutarlas. Windows y el motor editorial de navegador permanecen `NOT_RUN`; no extrapoles una verificación de WeasyPrint a esos entornos.
