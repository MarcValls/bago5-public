---
collection: "IA. LA PREGUNTA"
volume_number: "13"
volume_title: "Título del volumen"
subtitle: "Subtítulo del volumen"
author: "Marc Valls"
family: "auto"
status: "PUBLICABLE"
---

# Título del volumen

Texto de apertura. Este archivo debe contener únicamente contenido publicable.
Los estados de validación, dictámenes, notas de chat, siguiente acción y controles internos deben vivir fuera del manuscrito.

## Propósito del volumen

Explique qué incorpora este volumen al corpus y qué problema resuelve.

## Alcance

Delimite qué incluye y qué excluye. Evite lenguaje de expediente interno.

## Mapa del volumen

Presente la progresión de módulos o bloques en forma narrativa o tabular.

\newpage

# Módulo 13.1 — Título del módulo

## 1. Objeto del módulo

Defina el objeto con precisión.

## 2. Tesis central

Introduzca la tesis sin referencias a validación, revisión o estado editorial.

```math
\boxed{A \neq B}
```

## 3. Desarrollo

Texto principal.

> **Principio**
> Un recuadro debe contener una idea que mejore la lectura, no una nota de control del proyecto.

### Caso mínimo

Describa un ejemplo autocontenido. No use ejemplos que dependan de la conversación que originó el libro.

### Tabla de síntesis

| Concepto | Definición | Función |
|---|---|---|
| A | Definición | Uso |
| B | Definición | Uso |

## 4. Cierre del módulo

Cierre conceptual del módulo. No incluya “VALIDADO”, “siguiente acción”, nombres de archivos ni instrucciones de trabajo.

\newpage

# Conclusión del volumen

Cierre editorial del volumen.

# Glosario

| Término | Significado |
|---|---|
| `U` | Expresión humana |

<!--
CONTROL INTERNO FUERA DEL LIBRO:
Guardar auditorías, estado, versión, dictamen, archivos fuente y siguiente acción en un expediente separado.
No publicar este bloque.
-->
