"""Motor editorial IALP: fuentes, visuales, composición y evidencia."""

__version__ = "1.1.0"
