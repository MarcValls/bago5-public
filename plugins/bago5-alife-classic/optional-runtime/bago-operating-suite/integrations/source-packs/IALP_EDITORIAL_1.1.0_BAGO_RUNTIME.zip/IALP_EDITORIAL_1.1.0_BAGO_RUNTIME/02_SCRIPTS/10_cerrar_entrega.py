#!/usr/bin/env python3
"""Cierra una salida después de validar la revisión visual explícita y vigente."""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
from ialp.review import validate_visual_review
from ialp.quality import file_sha256, package_files


def close_delivery(output_dir):
    root = Path(output_dir).resolve()
    required = ["RUN.json", "AUDITORIA.json", "VISUALES.json", "MAQUETACION.json", "REVISION_VISUAL.json"]
    for name in required:
        if not (root / name).is_file():
            raise FileNotFoundError(f"Falta el archivo obligatorio {name}")
    run = json.loads((root / "RUN.json").read_text(encoding="utf-8"))
    pdf = (root / run["pdf"]).resolve()
    if not pdf.is_relative_to(root) or not pdf.is_file():
        raise ValueError("El PDF debe estar dentro de la salida que se cierra.")
    review = validate_visual_review(root / "REVISION_VISUAL.json", pdf_path=pdf,
        audit_path=root / "AUDITORIA.json", preview_path=root / "verificacion_visual" / "PREVIEW.json",
        run_path=root / "RUN.json")
    if review["status"] != "VALID" or review["VISUAL_REVIEW"] != "PASS" or review["eligible_for_final_delivery"] is not True:
        raise ValueError("La revisión visual no permite el cierre: " + "; ".join(review.get("issues", []) + review.get("blockers", [])))
    visuals = json.loads((root / "VISUALES.json").read_text(encoding="utf-8"))
    layout = json.loads((root / "MAQUETACION.json").read_text(encoding="utf-8"))
    if run.get("status") != "AUTOMATIC_CHECKS_PASSED":
        raise ValueError("La ejecución debe superar sus controles sin limitaciones.")
    if not run.get("generation_files"):
        raise ValueError("Falta el inventario de la generación en RUN.json.")
    for relative, digest in run["generation_files"].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file() or file_sha256(path) != digest:
            raise ValueError(f"Archivo de la generación alterado o ausente: {relative}")
    counts = visuals.get("counts", {})
    if counts.get("SKIPPED", 0) or counts.get("FAILED", 0):
        raise ValueError("No se cierra una entrega con recursos omitidos o fallidos.")
    if not layout.get("toc_page_numbers"):
        raise ValueError("El motor empleado no acredita el índice paginado.")
    pdf = (root / run["pdf"]).resolve()
    if not pdf.is_relative_to(root) or not pdf.is_file() or file_sha256(pdf) != run["pdf_sha256"]:
        raise ValueError("El PDF actual no coincide con la generación registrada.")
    for item in visuals.get("items", []):
        for path_key, hash_key in (("source_path", "source_sha256"), ("output_path", "output_sha256"), ("input_copy_path", "input_sha256")):
            if item.get(path_key):
                path = (root / item[path_key]).resolve()
                if not path.is_relative_to(root) or not path.is_file() or file_sha256(path) != item.get(hash_key):
                    raise ValueError(f"Recurso alterado o ausente: {item[path_key]}")
    for item in layout.get("resources", []):
        path = (root / item["path"]).resolve()
        if not path.is_relative_to(root) or not path.is_file() or file_sha256(path) != item["sha256"]:
            raise ValueError(f"Imagen alterada o ausente: {item['path']}")
    html = pdf.with_suffix(".html")
    if not html.is_file():
        raise FileNotFoundError("Falta el HTML editable junto al PDF.")
    delivery = {
        "schema": "ialp.delivery.v1", "status": "FINAL_REVIEWED",
        "pdf": pdf.name, "pdf_sha256": file_sha256(pdf),
        "VISUAL_REVIEW": "PASS", "review_sha256": review["receipt_sha256"],
        "evidence": {name: file_sha256(root / name) for name in required},
        "scope": "Cierre de una generación con revisión visual declarada, completa y vigente. No certifica identidad del revisor ni conformidad PDF/A o PDF/UA.",
    }
    receipt_path = root / "ENTREGA.json"
    previous_receipt = receipt_path.read_bytes() if receipt_path.exists() else None
    receipt_path.write_text(json.dumps(delivery, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stem = pdf.stem.removesuffix("_EDITORIAL")
    package = root / f"{stem}_ENTREGA.zip"
    files = sorted(p for p in root.rglob("*") if p.is_file() and p != package and not p.name.endswith("_BORRADOR.zip") and not p.name.endswith("_ENTREGA.zip"))
    try:
        package_files(package, files, root=root)
    except Exception:
        # El empaquetador conserva el ZIP anterior; conservar también su recibo.
        if previous_receipt is None:
            receipt_path.unlink(missing_ok=True)
        else:
            receipt_path.write_bytes(previous_receipt)
        raise
    return {"status": "FINAL_REVIEWED", "package": str(package), "sha256": file_sha256(package)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_dir", help="Carpeta de salida del pipeline con REVISION_VISUAL.json")
    args = parser.parse_args()
    try:
        result = close_delivery(args.output_dir)
    except Exception as exc:
        print(f"FAILED: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
