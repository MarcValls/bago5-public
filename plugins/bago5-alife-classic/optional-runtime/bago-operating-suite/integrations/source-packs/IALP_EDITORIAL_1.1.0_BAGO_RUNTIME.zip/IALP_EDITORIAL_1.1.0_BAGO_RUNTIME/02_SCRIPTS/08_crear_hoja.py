#!/usr/bin/env python3
"""Crear una hoja editable: python 08_crear_hoja.py SOURCE.json OUTPUT.xlsx.

Conserva SOURCE como OUTPUT.source.json. --report guarda hashes e inventario.
Admite formatos text/integer/decimal/percent; no calcula fórmulas.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

from ialp.workbook import create_workbook, _atomic_bytes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--report", default=None)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output = Path(args.output).absolute()
    report_path = Path(args.report).absolute() if args.report else None
    try:
        if source == output.resolve():
            raise ValueError("La salida no puede sustituir la fuente JSON.")
        protected = {source, output.resolve(), output.with_suffix(".source.json").resolve()}
        if report_path is not None and (report_path.resolve() in protected or report_path.is_symlink()):
            raise ValueError("El informe requiere una ruta distinta de fuente, copia JSON y XLSX; no puede ser un enlace.")
        if report_path is not None and report_path.exists() and not report_path.is_file():
            raise ValueError("La ruta del informe debe ser un archivo regular.")
        raw = source.read_bytes()
        def invalid_constant(value):
            raise ValueError(f"Número JSON no finito: {value}")
        spec = json.loads(raw, parse_constant=invalid_constant)
        report = create_workbook(spec, output, source_bytes=raw)
        report["source_path"] = str(source)
        report["source_sha256"] = hashlib.sha256(raw).hexdigest()
        if report_path is not None:
            report_path.parent.mkdir(parents=True, exist_ok=True)
            _atomic_bytes(report_path, (json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    except Exception as exc:
        print(f"FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    print(f"CREATED: {output} | hojas={len(report['sheets'])} | SHA-256={report['output_sha256']}")
    if report_path is not None:
        print(f"Informe: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
