# PROMPT — SELECCIÓN DE GRÁFICOS Y MERMAID

Detecta oportunidades de representación visual con criterio editorial. Conserva el contenido y los datos del documento; cada visual debe aclarar una relación concreta.

## Cuándo representar

Considera un diagrama cuando haya una secuencia con decisiones, un ciclo de reparación o reintento, una arquitectura por capas, dependencias entre fases o una relación de entrada, operación, evidencia y cierre. No conviertas automáticamente cada procedimiento o lista en un dibujo.

Evita gráficos redundantes para conclusiones, listas de definiciones, criterios de cierre, ejercicios o tablas ya claras. La existencia de un apartado de validación no obliga a dibujarlo. Si una estructura gana claridad con una tabla o unas frases, conserva esa forma.

Antes de añadir visuales nuevos, presenta candidatos con sección, relación que aclaran, tipo y número de nodos o series. Materializa los que reduzcan carga de lectura dentro del alcance autorizado. No elimines ni sustituyas un visual existente sin explicar el motivo.

## Componentes implementados

| Bloque o herramienta | Uso y límites |
| --- | --- |
| `mermaid` | Diagramas y mapas conceptuales mediante Mermaid CLI. SVG por defecto, con etiquetas HTML desactivadas. |
| `dot` o `graphviz` | Grafos DOT a SVG mediante el ejecutable externo `dot`. |
| `chart` | JSON declarativo a SVG mediante Matplotlib: `bar`, `line` y `heatmap`, con datos internos. No ejecuta código Python del manuscrito. |
| `spreadsheet` | JSON con `path`, `sheet` y `range`, por ejemplo `{"path":"datos.xlsx","sheet":"Resumen","range":"A1:C5"}`. Extrae valores a una tabla Markdown; la primera fila seleccionada es la cabecera. No conserva la maqueta de Excel. |
| `08_crear_hoja.py` | Genera un XLSX editable desde JSON: cabeceras, columnas, filas, filtros, inmovilización y formatos simples. Las fórmulas necesitan un resultado declarado y no se calculan. |

Para `chart`, usa `{"type":"bar","labels":["A","B"],"values":[3,5]}`; una línea acepta `labels`/`values` o `x`/`y`; un mapa de calor acepta una matriz numérica en `values` y etiquetas opcionales `xlabels`/`ylabels`. No inventes mediciones para llenar un ejemplo: indica cuándo los datos son demostrativos.

Los rangos XLSX se resuelven respecto de la carpeta del manuscrito. Una fórmula sin valor en caché o con un error no se presenta como un dato válido. El kit importa valores; no calcula ni verifica matemáticamente los resultados declarados por otro programa.

## Dependencias y tratamiento de fallos

Usa la versión local de Mermaid CLI instalada con `npm ci` según el lockfile del kit. Si falta `mmdc`, su navegador o falla el diagrama, el modo `required` debe fallar. El nombre histórico `02_render_mermaid_opcional.py` no implica que un fallo se omita silenciosamente.

`--skip-mermaid` en el pipeline, o `--mode skip` en el script de visuales, conserva expresamente los bloques Mermaid y registra `SKIPPED`. El resultado queda con limitaciones y no permite cierre final. No sustituye los requisitos de DOT, gráficos o hojas de cálculo.

SVG es la salida principal. Solo solicita `--format png` al script de visuales cuando haya una necesidad expresa de PNG; no uses una conversión automática para ocultar un error. Conserva fuentes, datos, archivos generados, rutas, errores y huellas del informe `VISUALES.json`.

## Sintaxis y comprobación

Coloca los bloques que deban procesarse al nivel principal del Markdown. Para enseñar un ejemplo de bloque sin ejecutarlo, enciérralo dentro de una cerca exterior más larga, por ejemplo cuatro backticks alrededor de un ejemplo con tres. No interpretes el contenido de un bloque exterior de código como nuevos diagramas.

Revisa en el PDF todas las etiquetas, flechas, escalas, contrastes, cuadrículas y cortes. Una imagen existente o un archivo SVG válido no garantiza su legibilidad al tamaño de impresión. Después de corregir un visual, regenera y repite la comprobación del PDF final.

Este kit no incorpora cartografía geográfica ni composición matemática LaTeX. Un mapa conceptual Mermaid y un gráfico `heatmap` no son un mapa geográfico; un bloque `math` se conserva como código.
