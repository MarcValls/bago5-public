# IALP 1.1.0 — runtime integrado en BAGO 1.4.0

Derivación explícita del kit suministrado. Scripts Python conservados byte a byte.
La única adaptación editorial es resolver las fuentes por nombre local en CSS;
no se incluyen archivos tipográficos. No se promete identidad visual entre equipos.
Consulte SOURCE_DERIVATION.json y UPSTREAM_MANIFEST.json para la procedencia completa.
Las salidas históricas, demostraciones y archivos tipográficos no forman parte del runtime.

Use el orquestador central para trabajo sobre documentos. El pipeline IALP no
concede permisos, no realiza una revisión visual por generar PNG y no decide
la verificación funcional de BAGO5/ADL. El módulo fuerza conservación por defecto,
WeasyPrint y vistas de todas las páginas.

Los requisitos y el lockfile npm se conservan sin modificaciones; instálelos
únicamente en un entorno externo y explícito. Nunca dentro del árbol verificado.
