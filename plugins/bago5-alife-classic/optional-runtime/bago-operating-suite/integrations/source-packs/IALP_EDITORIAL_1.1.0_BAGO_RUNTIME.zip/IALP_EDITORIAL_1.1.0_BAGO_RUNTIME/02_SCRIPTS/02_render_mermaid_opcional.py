#!/usr/bin/env python3
"""Render visual fences with evidence; retains the v1.0 source/output/--assets CLI.

Mermaid is required when present unless --mode skip is supplied explicitly.
DOT, declarative charts and spreadsheet tables are also supported.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

from ialp.visuals import VisualRenderError, render_visuals


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--assets", default=None, help="Carpeta de recursos; por defecto assets_visuals junto a la salida.")
    parser.add_argument("--report", default=None, help="Informe JSON; por defecto <output>.visuals.json.")
    parser.add_argument("--mode", choices=["required", "skip"], default="required", help="skip omite solo Mermaid y conserva sus bloques.")
    parser.add_argument("--format", choices=["svg", "png"], default="svg", help="Formato Mermaid; PNG exige solicitud explícita.")
    parser.add_argument("--mmdc", default=None, help="Ruta al ejecutable mmdc.")
    parser.add_argument("--timeout", type=float, default=90)
    parser.add_argument("--source-dir", default=None, help="Carpeta original de libros spreadsheet.")
    parser.add_argument("--puppeteer-config", default=None, help="Configuración explícita de lanzamiento Puppeteer.")
    args = parser.parse_args()
    source, output = Path(args.source).resolve(), Path(args.output).resolve()
    report_path = Path(args.report).resolve() if args.report else output.with_suffix(".visuals.json")
    report = None
    try:
        if source == output:
            raise ValueError("La salida debe ser distinta de la fuente para conservar el manuscrito original.")
        if report_path in {source, output}:
            raise ValueError("El informe debe tener una ruta distinta de la fuente y la salida.")
        text = source.read_text(encoding="utf-8")
        transformed, report = render_visuals(
            text, output.parent, source_dir=args.source_dir or source.parent,
            mermaid_mode=args.mode, mmdc=args.mmdc, timeout=args.timeout,
            mermaid_format=args.format, assets_dir=args.assets,
            puppeteer_config=args.puppeteer_config,
        )
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(transformed, encoding="utf-8")
    except VisualRenderError as exc:
        report = exc.report
        print(f"FAILED: {exc}", file=sys.stderr)
        return_code = 2
    except Exception as exc:
        print(f"FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    else:
        counts = report["counts"]
        print(f"{report['status']}: {counts['RENDERED']} renderizados, {counts['SKIPPED']} omitidos, {counts['FAILED']} fallidos -> {output}")
        return_code = 0
    if report is not None:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"Informe: {report_path}")
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
