# PROMPT — MAQUETACIÓN IA. LA PREGUNTA

Maqueta el Markdown editorial limpio mediante el kit v1.1.0 y WeasyPrint. Conserva el contenido y aplica la identidad visual de la colección. Generar el PDF y revisar su apariencia son pasos distintos.

## Identidad y composición

- A4 vertical.
- Portada azul marino dominante, diagonal clara, volumen en dorado, título blanco y subtítulo gris claro.
- Interior blanco, texto oscuro, acento dorado y azul para la jerarquía.
- Índice real y paginado, vinculado a los encabezados del documento.
- Encabezado discreto con colección o capítulo, y pie con autor y paginación.
- H1/H2/H3 jerarquizados sin un salto de página innecesario por título.
- Tablas con cabecera azul, filas distinguibles y tamaño legible; revisar columnas, repeticiones de cabecera y cortes.
- Código monoespaciado con fondo claro y bloques técnicos para las fórmulas textuales.
- Callouts con barra dorada lateral.
- Control de viudas, huérfanas, desbordes y portadillas innecesarias mediante comprobación del PDF renderizado.

## Familias

- `puerta`, volumen 0: más aire pedagógico.
- `doctrina`, volúmenes 1–11: densidad media.
- `sintesis`, volúmenes 12 en adelante: composición algo más compacta para arquitectura y contenido técnico, conservando legibilidad.

Usa `--family` si la inferencia automática no corresponde. Documenta la elección sin modificar el contenido para forzarlo a una maqueta.

## Estructuras y recursos

Procesa Mermaid, DOT, `chart` y `spreadsheet` mediante sus componentes declarados. Usa SVG como salida gráfica principal y conserva la fuente del visual. No sustituyas un render fallido por un éxito aparente. Las imágenes existentes deben resolverse desde su carpeta original y copiarse a los recursos portables de la salida.

Un bloque `math` se conserva como código: este kit no incorpora composición matemática LaTeX. Tampoco incorpora cartografía geográfica. Si el documento exige esas capacidades, identifica el requisito pendiente antes de afirmar que la edición lo satisface.

Separa las notas de producción del contenido publicable por su función. En el manual del kit, los nombres de archivos, estados y procedimientos de validación son contenido técnico legítimo.

## Verificar el resultado

Guarda HTML editable, PDF, recursos e informe de maquetación. Audita el texto y su conservación; después renderiza e inspecciona todas las páginas, incluidas las de tablas, gráficos y código. Comprueba portada, índice, cabeceras, pies y final del contenido.

Si corriges CSS, fuente, metadatos, datos o gráficos, regenera en una salida nueva y vuelve a comprobar todas las páginas del PDF final. Una inspección parcial sirve para diagnosticar; no autoriza el cierre. Registra la revisión con el SHA-256 final antes de empaquetar la entrega.

WeasyPrint es el motor predeterminado. No declares comprobada una ejecución con navegador o Windows a partir de una ejecución Linux con WeasyPrint.
