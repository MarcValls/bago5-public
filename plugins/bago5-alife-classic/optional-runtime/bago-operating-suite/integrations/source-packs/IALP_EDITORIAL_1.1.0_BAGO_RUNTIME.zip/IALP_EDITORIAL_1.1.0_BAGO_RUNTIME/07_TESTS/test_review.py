"""Visual review records: real file hashes, explicit declarations and invalidation.

Fixtures are opaque byte files, not rendered PDFs or inspected page images.
This module tests receipt integrity and state transitions only; no test here
claims that a visual inspection has occurred. Rendering is covered separately.
"""
from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "02_SCRIPTS"))
from ialp import review


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name) / "bundle"
        self.folder.mkdir()
        self.pdf = self.folder / "documento.data"
        self.pdf.write_bytes(b"opaque document fixture, not a generated PDF")
        self.preview_dir = self.folder / "verificacion_visual"
        self.preview_dir.mkdir()
        self.preview_path = self.preview_dir / "PREVIEW.json"
        self.audit_path = self.folder / "AUDITORIA.json"
        self.run_path = self.folder / "RUN.json"
        self.receipt_path = self.folder / "REVISION_VISUAL.json"
        images = []
        for page in range(1, 4):
            path = self.preview_dir / f"page-{page:03}.png"
            path.write_bytes(f"opaque raster fixture {page}".encode())
            images.append({"page": page, "path": path.name, "sha256": digest(path)})
        sheet = self.preview_dir / "VERIFICACION_VISUAL.jpg"
        sheet.write_bytes(b"opaque contact sheet fixture")
        self.preview = {"schema": "ialp.preview.v1", "status": "PREVIEW_GENERATED",
                        "pdf_sha256": digest(self.pdf), "total_pages": 3,
                        "selected_pages": [1, 2, 3], "images": images,
                        "contact_sheets": [{"path": sheet.name, "sha256": digest(sheet)}]}
        self.audit = {"schema": "ialp.pdf_audit.v1", "pdf_sha256": digest(self.pdf),
                      "pages": 3, "TEXT_AUDIT": "PASS", "CONTENT_CHECK": "PASS", "automatic_status": "PASS"}
        self.run = {"schema": "ialp.run.v1", "pdf_sha256": digest(self.pdf),
                    "pdf": self.pdf.name, "status": "AUTOMATIC_CHECKS_PASSED", "visual_review": "NOT_RUN"}
        self.checklist = {key: {"status": "PASS", "notes": "Declaración sintética sólo para la prueba del registro."}
                          for key in review.CHECKLIST_ITEMS}
        write_json(self.preview_path, self.preview)
        write_json(self.audit_path, self.audit)
        write_json(self.run_path, self.run)

    def record(self, **overrides):
        arguments = {"reviewer": "REVISOR FICTICIO DE PRUEBAS; sin inspección real", "inspected_pages": "all",
                     "result": "PASS", "checklist": self.checklist, "notes": "Fixture de validación del recibo.",
                     "reviewed_at": "2026-10-21T10:00:00+00:00"}
        arguments.update(overrides)
        return review.record_visual_review(self.pdf, **arguments)

    def validate(self):
        return review.validate_visual_review(self.receipt_path)

    def test_complete_explicit_declaration_is_bound_to_all_evidence(self):
        original_run = self.run_path.read_bytes()
        receipt = self.record()
        self.assertEqual(receipt["VISUAL_REVIEW"], "PASS")
        self.assertTrue(receipt["eligible_for_final_delivery"])
        self.assertEqual(receipt["inspected_pages"], [1, 2, 3])
        self.assertEqual(receipt["evidence"]["preview"]["sha256"], digest(self.preview_path))
        self.assertEqual(receipt["evidence"]["audit"]["sha256"], digest(self.audit_path))
        self.assertEqual(receipt["evidence"]["run"]["sha256"], digest(self.run_path))
        self.assertEqual(self.run_path.read_bytes(), original_run)
        result = self.validate()
        self.assertEqual(result["status"], "VALID")
        self.assertEqual(result["receipt_sha256"], digest(self.receipt_path))
        self.assertTrue(result["eligible_for_final_delivery"])

    def test_partial_pages_are_recorded_but_cannot_close_delivery(self):
        receipt = self.record(inspected_pages="1-2")
        self.assertEqual(receipt["declared_verdict"], "PASS")
        self.assertEqual(receipt["VISUAL_REVIEW"], "PARTIAL")
        self.assertFalse(receipt["eligible_for_final_delivery"])
        self.assertEqual(self.validate()["status"], "VALID")
        self.assertFalse(self.validate()["eligible_for_final_delivery"])

    def test_pages_without_generated_views_are_rejected(self):
        self.preview["selected_pages"] = [1, 3]
        self.preview["images"] = [self.preview["images"][0], self.preview["images"][2]]
        write_json(self.preview_path, self.preview)
        with self.assertRaisesRegex(ValueError, "no están en PREVIEW"):
            self.record()
        self.assertFalse(self.receipt_path.exists())
        self.assertEqual(self.record(inspected_pages=[1, 3])["VISUAL_REVIEW"], "PARTIAL")

    def test_not_run_checklist_never_inherits_pass_from_verdict(self):
        self.checklist["cortes_desbordes"] = {"status": "NOT_RUN", "notes": "Pendiente."}
        receipt = self.record()
        self.assertEqual(receipt["VISUAL_REVIEW"], "PARTIAL")
        self.assertFalse(receipt["eligible_for_final_delivery"])

    def test_all_seven_checklist_keys_are_required(self):
        del self.checklist["indice"]
        with self.assertRaisesRegex(ValueError, "Faltan.*indice"):
            self.record()
        self.assertFalse(self.receipt_path.exists())

    def test_unknown_checklist_key_is_rejected(self):
        self.checklist["tipografia"] = {"status": "PASS"}
        with self.assertRaisesRegex(ValueError, "claves desconocidas"):
            self.record()

    def test_not_applicable_requires_specific_reason(self):
        self.checklist["diagramas_etiquetas"] = {"status": "NOT_APPLICABLE", "notes": " "}
        with self.assertRaisesRegex(ValueError, "justificación"):
            self.record()
        self.checklist["diagramas_etiquetas"]["notes"] = "El documento de esta prueba no contiene diagramas."
        self.assertTrue(self.record()["eligible_for_final_delivery"])

    def test_failed_checklist_and_error_finding_override_pass_verdict(self):
        self.checklist["fuentes_contraste"] = {"status": "FAIL", "notes": "Etiqueta ilegible en la página 2 (caso sintético)."}
        self.assertEqual(self.record()["VISUAL_REVIEW"], "FAIL")
        self.checklist["fuentes_contraste"]["status"] = "PASS"
        receipt = self.record(findings=[{"description": "Desborde sintético.", "severity": "ERROR", "page": 2, "item": "cortes_desbordes"}])
        self.assertEqual(receipt["VISUAL_REVIEW"], "FAIL")
        self.assertFalse(receipt["eligible_for_final_delivery"])

    def test_explicit_fail_is_preserved(self):
        receipt = self.record(result="FAIL")
        self.assertEqual(receipt["VISUAL_REVIEW"], "FAIL")
        self.assertEqual(self.validate()["status"], "VALID")
        self.assertFalse(self.validate()["eligible_for_final_delivery"])

    def test_uninspected_finding_page_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "páginas inspeccionadas"):
            self.record(inspected_pages=[1], findings=[{"description": "Caso sintético", "page": 2}])

    def test_automatic_checks_must_each_pass(self):
        for key, state in (("TEXT_AUDIT", "FAIL"), ("CONTENT_CHECK", "FAIL"),
                           ("CONTENT_CHECK", "NOT_RUN"), ("automatic_status", "FAIL")):
            with self.subTest(check=key, state=state):
                previous = self.audit[key]
                self.audit[key] = state
                write_json(self.audit_path, self.audit)
                receipt = self.record()
                self.assertEqual(receipt["VISUAL_REVIEW"], "PARTIAL")
                self.assertFalse(receipt["eligible_for_final_delivery"])
                self.audit[key] = previous
                write_json(self.audit_path, self.audit)

    def test_run_limitations_block_eligibility_without_modifying_run(self):
        self.run["status"] = "GENERATED_WITH_LIMITATIONS"
        write_json(self.run_path, self.run)
        self.assertEqual(self.record()["VISUAL_REVIEW"], "PARTIAL")
        self.assertEqual(json.loads(self.run_path.read_text())["status"], "GENERATED_WITH_LIMITATIONS")

    def test_standalone_audited_pdf_can_be_reviewed_without_run(self):
        self.run_path.unlink()
        receipt = self.record()
        self.assertNotIn("run", receipt["evidence"])
        self.assertTrue(self.validate()["eligible_for_final_delivery"])

    def test_changed_pdf_invalidates_existing_receipt(self):
        self.record()
        self.pdf.write_bytes(b"changed document bytes")
        result = self.validate()
        self.assertEqual(result["status"], "INVALIDATED")
        self.assertEqual(result["VISUAL_REVIEW"], "INVALIDATED")
        self.assertFalse(result["eligible_for_final_delivery"])
        with self.assertRaisesRegex(ValueError, "SHA-256 no coincide"):
            self.record()

    def test_evidence_json_changes_invalidate_even_if_statuses_unchanged(self):
        for path in (self.audit_path, self.preview_path, self.run_path):
            with self.subTest(path=path.name):
                original = path.read_bytes()
                self.record()
                data = json.loads(original)
                data["extra_note"] = "Cambio posterior a la revisión."
                write_json(path, data)
                result = self.validate()
                self.assertEqual(result["status"], "INVALIDATED")
                self.assertTrue(any("modificada" in issue for issue in result["issues"]))
                path.write_bytes(original)

    def test_changed_preview_image_and_contact_sheet_invalidate(self):
        for path in (self.preview_dir / "page-002.png", self.preview_dir / "VERIFICACION_VISUAL.jpg"):
            with self.subTest(path=path.name):
                original = path.read_bytes()
                self.record()
                path.write_bytes(b"altered visual evidence")
                self.assertEqual(self.validate()["status"], "INVALIDATED")
                path.write_bytes(original)

    def test_missing_evidence_prevents_a_new_receipt(self):
        self.audit_path.unlink()
        with self.assertRaises(FileNotFoundError):
            self.record()
        self.assertFalse(self.receipt_path.exists())

    def test_mismatched_page_counts_are_rejected(self):
        self.preview["total_pages"] = 4
        write_json(self.preview_path, self.preview)
        with self.assertRaisesRegex(ValueError, "total de páginas"):
            self.record()

    def test_preview_paths_cannot_escape_preview_folder(self):
        escaped = self.folder / "outside.png"
        escaped.write_bytes(b"fixture")
        self.preview["images"][0].update(path="../outside.png", sha256=digest(escaped))
        write_json(self.preview_path, self.preview)
        with self.assertRaisesRegex(ValueError, "dentro de la carpeta"):
            self.record()

    def test_duplicate_image_paths_are_rejected(self):
        self.preview["images"][1].update(path=self.preview["images"][0]["path"], sha256=self.preview["images"][0]["sha256"])
        write_json(self.preview_path, self.preview)
        with self.assertRaisesRegex(ValueError, "repite rutas"):
            self.record()

    def test_bad_page_declarations_and_naive_date_are_rejected(self):
        for pages in ([0], [4], [1, 1], [True], [], "3-1", "sample"):
            with self.subTest(pages=pages), self.assertRaises(ValueError):
                self.record(inspected_pages=pages)
        with self.assertRaisesRegex(ValueError, "zona horaria"):
            self.record(reviewed_at="2026-10-21T10:00:00")

    def test_blank_reviewer_and_absent_verdict_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "revisor"):
            self.record(reviewer=" ")
        with self.assertRaisesRegex(ValueError, "veredicto"):
            self.record(result="NOT_RUN")

    def test_receipt_cannot_overwrite_an_input(self):
        for path in (self.pdf, self.audit_path, self.preview_dir / "page-001.png"):
            with self.subTest(path=path.name):
                before = path.read_bytes()
                with self.assertRaisesRegex(ValueError, "sobrescribir"):
                    self.record(output_path=path)
                self.assertEqual(path.read_bytes(), before)

    def test_change_during_recording_writes_no_receipt(self):
        original = review._assert_unchanged
        def changed(snapshot):
            self.pdf.write_bytes(b"changed between hash capture and commit")
            original(snapshot)
        with patch.object(review, "_assert_unchanged", side_effect=changed):
            with self.assertRaisesRegex(ValueError, "cambió durante"):
                self.record()
        self.assertFalse(self.receipt_path.exists())

    def test_status_cannot_be_upgraded_by_editing_the_computed_boolean(self):
        receipt = self.record(inspected_pages=[1])
        receipt["VISUAL_REVIEW"] = "PASS"
        receipt["eligible_for_final_delivery"] = True
        receipt["blockers"] = []
        write_json(self.receipt_path, receipt)
        self.assertEqual(self.validate()["status"], "INVALIDATED")

    def test_bundle_can_move_without_breaking_relative_evidence_paths(self):
        self.record()
        moved = Path(self.temp.name) / "copied_bundle"
        shutil.copytree(self.folder, moved)
        self.assertEqual(review.validate_visual_review(moved / "REVISION_VISUAL.json")["status"], "VALID")

    def test_missing_or_invalid_receipt_returns_invalidated(self):
        self.assertEqual(self.validate()["status"], "INVALIDATED")
        self.receipt_path.write_text("not json", encoding="utf-8")
        self.assertEqual(self.validate()["status"], "INVALIDATED")

    def test_null_timestamp_is_not_replaced_with_current_time_during_validation(self):
        receipt = self.record()
        receipt["reviewed_at"] = None
        write_json(self.receipt_path, receipt)
        self.assertEqual(self.validate()["status"], "INVALIDATED")

    def test_empty_document_cannot_produce_a_review_receipt(self):
        self.pdf.write_bytes(b"")
        with self.assertRaisesRegex(ValueError, "Tamaño del PDF"):
            self.record()
        self.assertFalse(self.receipt_path.exists())

    def test_shipped_template_is_pending_and_complete(self):
        value = json.loads((ROOT / "05_CONFIG" / "CHECKLIST_VISUAL.json").read_text(encoding="utf-8"))
        self.assertEqual(set(value), set(review.CHECKLIST_ITEMS))
        self.assertTrue(all(item["status"] == "NOT_RUN" for item in value.values()))
        self.assertEqual(self.record(checklist=value)["VISUAL_REVIEW"], "PARTIAL")

    def test_cli_requires_explicit_checklist(self):
        run = subprocess.run([sys.executable, "-B", str(ROOT / "02_SCRIPTS" / "09_registrar_revision_visual.py"),
                              str(self.pdf), "--reviewer", "Fixture", "--pages", "all", "--verdict", "PASS"],
                             capture_output=True, text=True)
        self.assertEqual(run.returncode, 2)
        self.assertIn("--checklist", run.stderr)
        self.assertFalse(self.receipt_path.exists())

    def test_cli_registers_and_validates_without_touching_run(self):
        checklist = self.folder / "checks.json"
        write_json(checklist, self.checklist)
        command = [sys.executable, "-B", str(ROOT / "02_SCRIPTS" / "09_registrar_revision_visual.py")]
        before = self.run_path.read_bytes()
        registered = subprocess.run(command + [str(self.pdf), "--reviewer", "Fixture", "--pages", "all", "--verdict", "PASS",
                                               "--checklist", str(checklist), "--note", "Declaración sintética"], capture_output=True, text=True)
        self.assertEqual(registered.returncode, 0, registered.stderr)
        self.assertEqual(json.loads(registered.stdout)["VISUAL_REVIEW"], "PASS")
        validated = subprocess.run(command + ["--validate", str(self.receipt_path)], capture_output=True, text=True)
        self.assertEqual(validated.returncode, 0, validated.stderr)
        self.assertEqual(json.loads(validated.stdout)["status"], "VALID")
        self.assertEqual(self.run_path.read_bytes(), before)
        self.pdf.write_bytes(b"changed")
        invalid = subprocess.run(command + ["--validate", str(self.receipt_path)], capture_output=True, text=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertEqual(json.loads(invalid.stdout)["status"], "INVALIDATED")

    def test_cli_keeps_failed_review_and_returns_exit_two(self):
        checklist = self.folder / "checks.json"
        write_json(checklist, self.checklist)
        run = subprocess.run([sys.executable, "-B", str(ROOT / "02_SCRIPTS" / "09_registrar_revision_visual.py"),
                              str(self.pdf), "--reviewer", "Fixture", "--pages", "1", "--verdict", "FAIL",
                              "--checklist", str(checklist)], capture_output=True, text=True)
        self.assertEqual(run.returncode, 2)
        self.assertEqual(json.loads(self.receipt_path.read_text())["VISUAL_REVIEW"], "FAIL")


if __name__ == "__main__":
    unittest.main()
