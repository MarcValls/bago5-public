# PROMPT — LIMPIEZA EDITORIAL CONSERVADORA

Aplica únicamente los cambios autorizados dentro del alcance de la auditoría y de la tarea. Produce un Markdown editorial limpio manteniendo íntegro el contenido conceptual y una copia de la fuente original.

## Elegir el modo de limpieza

El modo predeterminado del kit es `explicit`. Solo retira material delimitado mediante estos marcadores fuera de código y del frontmatter YAML:

```html
<!-- IALP_CONTROL_START -->
Contenido interno que se conservará en el registro de limpieza.
<!-- IALP_CONTROL_END -->
```

También reconoce el comentario `<!-- CONTROL INTERNO FUERA DEL LIBRO: ... -->`. No interpretes una demostración de estos marcadores dentro de un bloque de código como una orden de borrado. Los marcadores incompletos o anidados son un error que debe resolverse antes de limpiar.

`preserve` conserva el contenido sin eliminaciones. El modo `legacy` es optativo: además de los marcadores, aplica reglas históricas a ciertos metadatos YAML, líneas de metadatos y secciones cuyos encabezados coincidan con la configuración. Puede retirar secciones completas o campos legítimos como versión, estado o fecha. No lo actives como solución rápida a una auditoría fallida; compara cada eliminación con la fuente.

## Criterio editorial

- Retira metadatos operativos y secciones de expediente solo cuando su función interna sea inequívoca y la acción esté autorizada. Conserva en el manual los ejemplos que expliquen esas mismas estructuras.
- No elimines palabras como `PDF`, `repositorio`, `agente`, `usuario`, `PASS` o nombres de archivos por aparecer en una lista. Decide por función y contexto.
- Conserva espacios significativos, saltos de línea, listas, código, fórmulas, tablas, símbolos e invariantes. No normalices todo el documento como efecto secundario de una limpieza.
- Si un ejemplo depende del chat, propón una versión autocontenida manteniendo su concepto. Una reescritura semántica no la realiza el limpiador automático y debe constar como cambio editorial separado.
- No transformes una corrección de estilo en una reescritura doctrinal. Registra las dudas que no puedan resolverse con certeza y conserva el contenido afectado.
- Verifica las rutas de las imágenes y de los datos desde la carpeta original. La salida debe mantener los recursos necesarios para maquetar.

## Evidencia de conservación

Revisa `LIMPIEZA.json`: modo, huellas de entrada y salida, fragmentos retirados, motivos y comprobación de reconstrucción. El registro conserva lo eliminado y permite contrastar la limpieza; no demuestra por sí solo que una decisión editorial sea correcta. No edites ese informe para disimular un cambio.

Entrega el Markdown limpio, la fuente original, el registro automático y el registro de cambios editoriales adicionales, además de las dudas pendientes. Las correcciones posteriores a la maquetación obligan a generar otra versión del PDF y a repetir su comprobación visual completa.
