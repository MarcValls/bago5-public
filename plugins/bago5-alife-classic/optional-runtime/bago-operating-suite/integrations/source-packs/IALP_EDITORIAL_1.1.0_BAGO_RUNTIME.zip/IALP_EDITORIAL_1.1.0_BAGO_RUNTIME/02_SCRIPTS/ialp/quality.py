"""Bounded PDF checks, review images and reproducible delivery packages.

No function in this module approves a visual review. Text coverage is a bounded
check of extracted tokens, not proof of graphical or semantic equivalence.
"""
from __future__ import annotations

from bisect import bisect_right
from collections import Counter, defaultdict
from hashlib import sha256
import json
import math
import os
from pathlib import Path
import re
import tempfile
import unicodedata
import zipfile

import fitz
from PIL import Image, ImageDraw


def file_sha256(path: str | Path) -> str:
    digest = sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalized_tokens(text: str, *, vocabulary: set[str] | None = None) -> list[str]:
    """Ignore ligatures, discretionary hyphens, case and punctuation typography."""
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"(?<=\w)\u00ad[ \t]*\r?\n[ \t]*(?=\w)", "", text)
    # A real hyphen in e.g. "técnico-editorial" must survive a line break.
    # WeasyPrint may emit U+2010 at line breaks. Merge either hyphen only when
    # the expected vocabulary contains the combined word.
    def join_line(match):
        combined = match.group(1) + match.group(3)
        if vocabulary is None or combined.casefold() in vocabulary:
            return combined
        return match.group(1) + match.group(2) + match.group(3)
    text = re.sub(r"(\w+)([-\u2010])[ \t]*\r?\n[ \t]*(\w+)", join_line, text)
    text = text.replace("\u00ad", "")
    return re.findall(r"\w+|[=+*/<>≤≥≠≈∑∫∞√∈∉∧∨¬→←↔⇒⇐⇔]", text.casefold(), re.UNICODE)


def compare_text(expected: str, actual: str) -> dict:
    wanted = normalized_tokens(expected)
    found = normalized_tokens(actual, vocabulary=set(wanted))
    if not wanted:
        return {"status": "FAIL", "reason": "La fuente de comparación está vacía.",
                "expected_tokens": 0, "actual_tokens": len(found), "missing_tokens": [],
                "missing_groups": [], "ordered_subsequence": False}
    deficits = Counter(wanted) - Counter(found)
    positions: dict[str, list[int]] = defaultdict(list)
    for index, token in enumerate(found):
        positions[token].append(index)
    cursor, group_start = -1, 0
    groups, group = [], []
    for index, token in enumerate(wanted):
        locations = positions.get(token, [])
        pos = bisect_right(locations, cursor)
        if pos == len(locations):
            if not group:
                group_start = index
            group.append(token)
        else:
            if group:
                groups.append({"start_token": group_start, "tokens": group})
                group = []
            cursor = locations[pos]
    if group:
        groups.append({"start_token": group_start, "tokens": group})
    return {
        "status": "FAIL" if deficits or groups else "PASS",
        "expected_tokens": len(wanted), "actual_tokens": len(found),
        "missing_tokens": [{"token": t, "count": n} for t, n in sorted(deficits.items())],
        "missing_groups": groups, "ordered_subsequence": not groups,
        "method": "NFKC + tokens con multiplicidad + subsecuencia ordenada; se permite texto adicional.",
        "limits": "No compara imágenes, estilo, significado, puntuación o posición visual. El texto adicional puede ocultar pérdidas de palabras repetidas.",
    }


def _patterns(path: str | Path | None) -> list[re.Pattern]:
    path = Path(path) if path is not None else Path(__file__).resolve().parents[2] / "05_CONFIG" / "patrones_no_editoriales.txt"
    if not path.is_file():
        raise FileNotFoundError(f"No existe el archivo de patrones: {path}")
    result = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if line and not line.startswith("#"):
            try:
                result.append(re.compile(line, re.I))
            except re.error as exc:
                raise ValueError(f"Patrón inválido en {path.name}:{number}: {exc}") from exc
    return result


def _page_content(page, text: str) -> dict:
    rect = page.rect
    margin = max(28.0, min(54.0, rect.height * 0.055))
    top, bottom = rect.y0 + margin, rect.y1 - margin
    body = []
    for block in page.get_text("blocks"):
        if len(block) > 6 and block[6] != 0:
            continue
        if top <= (block[1] + block[3]) / 2 <= bottom:
            body.append(str(block[4]))
    images = len(page.get_image_info())
    vectors = 0
    for drawing in page.get_drawings():
        bounds = drawing.get("rect")
        if bounds is None:
            continue
        area = bounds.width * bounds.height
        # Ignore full-page backgrounds and hairline decorations.
        if (top <= (bounds.y0 + bounds.y1) / 2 <= bottom and bounds.width >= 2
                and bounds.height >= 2 and 0 < area < rect.width * rect.height * 0.75):
            vectors += 1
    body_chars = len(re.sub(r"\s+", "", "\n".join(body)))
    return {"text_chars": len(re.sub(r"\s+", "", text)), "body_chars": body_chars,
            "images": images, "vector_objects": vectors,
            "empty_or_header_only": body_chars == 0 and images == 0 and vectors == 0}


def audit_pdf(pdf_path: str | Path, expected_text: str | Path | None = None,
              patterns_path: str | Path | None = None, *, sparse_threshold: int = 45) -> dict:
    """expected_text is literal text, or a Path pointing to UTF-8 text."""
    path = Path(pdf_path)
    if not path.is_file():
        raise FileNotFoundError(f"No existe el PDF: {path}")
    pdf_digest = file_sha256(path)
    if isinstance(expected_text, Path):
        expected_text = expected_text.read_text(encoding="utf-8")
    patterns = _patterns(patterns_path)
    issues, warnings, page_data, alltext = [], [], [], []
    broken, empty, sparse = [], [], []
    with fitz.open(path) as doc:
        if doc.needs_pass:
            raise ValueError("El PDF requiere contraseña; no se ha auditado su contenido.")
        if len(doc) == 0:
            issues.append("El PDF no contiene páginas.")
        for index, page in enumerate(doc, 1):
            text = page.get_text("text")
            alltext.append(text)
            record = {"page": index, **_page_content(page, text)}
            page_data.append(record)
            if "\ufffd" in text or "\ufffe" in text:
                broken.append(index)
            if record["empty_or_header_only"]:
                empty.append(index)
            elif record["body_chars"] < sparse_threshold and not (record["images"] or record["vector_objects"]):
                sparse.append(index)
    fulltext = "\n".join(alltext)
    hits = []
    for number, text in enumerate(alltext, 1):
        for pattern in patterns:
            hits.extend({"page": number, "pattern": pattern.pattern, "match": m.group(0)}
                        for m in pattern.finditer(text))
    if hits:
        issues.append(f"{len(hits)} coincidencias con patrones no editoriales.")
    if broken:
        issues.append(f"Caracteres de sustitución/corrupción detectados: páginas {broken}.")
    if empty:
        issues.append(f"Páginas sin contenido de cuerpo detectable: {empty}.")
    if sparse:
        warnings.append(f"Páginas con poco texto de cuerpo que requieren revisión: {sparse}.")
    text_status = "FAIL" if issues else "PASS"
    if expected_text is None:
        comparison = {"status": "NOT_RUN", "reason": "No se suministró texto esperado para comparar."}
    else:
        comparison = compare_text(expected_text, fulltext)
        if comparison["status"] == "FAIL":
            issues.append("La cobertura textual respecto a la fuente esperada no supera la comparación.")
    if file_sha256(path) != pdf_digest:
        raise RuntimeError("El PDF cambió durante la auditoría; no se emite evidencia para otra versión.")
    return {
        "schema": "ialp.pdf_audit.v1", "pdf": path.name, "pdf_sha256": pdf_digest,
        "pages": len(page_data), "TEXT_AUDIT": text_status, "CONTENT_CHECK": comparison["status"],
        "VISUAL_REVIEW": "NOT_RUN", "automatic_status": "FAIL" if issues else "PASS",
        "page_details": page_data,
        "findings": {"pattern_hits": hits, "broken_pages": broken, "empty_pages": empty, "sparse_pages": sparse},
        "content": comparison, "issues": issues, "warnings": warnings,
        "scope": "Auditoría textual y heurística de contenido de página; no valida índice, tablas, imágenes ausentes, cortes o solapamientos.",
    }


def audit_markdown(report: dict) -> str:
    lines = [f"# Auditoría automática: {report['pdf']}", "",
             f"- SHA-256 del PDF: `{report['pdf_sha256']}`", f"- Páginas: {report['pages']}",
             f"- Auditoría textual: **{report['TEXT_AUDIT']}**",
             f"- Cobertura textual: **{report['CONTENT_CHECK']}**",
             "- Revisión visual: **NOT_RUN** (este script no la realiza).",
             f"- Resultado de estas comprobaciones automáticas: **{report['automatic_status']}**",
             "", report["scope"], ""]
    for title, values in [("Incidencias", report["issues"]), ("Avisos", report["warnings"])]:
        lines += [f"## {title}", ""]
        lines += [f"- {value}" for value in values] or ["Ninguno."]
        lines.append("")
    hits = report["findings"]["pattern_hits"]
    if hits:
        lines += ["## Patrones detectados", ""]
        lines += [f"- Página {hit['page']}: `{hit['match']}`" for hit in hits[:100]]
        lines.append("")
    content = report["content"]
    if content["status"] != "NOT_RUN":
        lines += ["## Comparación textual", "", content.get("method", content.get("reason", "")), ""]
        for group in content.get("missing_groups", [])[:30]:
            lines.append(f"- Secuencia no localizada desde token {group['start_token']}: {' '.join(group['tokens'][:40])}")
        lines += ["", content.get("limits", ""), ""]
    return "\n".join(lines).rstrip() + "\n"


def parse_pages(spec: str | None, number_of_pages: int) -> list[int]:
    if number_of_pages < 1:
        raise ValueError("El documento no contiene páginas para renderizar.")
    if spec is None or spec == "all":
        return list(range(number_of_pages))
    if spec == "sample":
        n = number_of_pages
        return list(dict.fromkeys([0, min(1, n - 1), n // 4, n // 2, 3 * n // 4, max(0, n - 2), n - 1]))
    result = []
    for part in spec.split(","):
        value = int(part.strip())
        if value == 0:
            raise ValueError("Las páginas empiezan en 1; -1 representa la última.")
        index = value - 1 if value > 0 else number_of_pages + value
        if not 0 <= index < number_of_pages:
            raise ValueError(f"Página fuera del documento: {value}")
        if index not in result:
            result.append(index)
    if not result:
        raise ValueError("La selección de páginas está vacía.")
    return result


def make_preview(pdf: str | Path, outdir: str | Path, pages: str = "all", dpi: int = 120) -> dict:
    if not 36 <= dpi <= 300:
        raise ValueError("dpi debe estar entre 36 y 300.")
    pdf, out = Path(pdf), Path(outdir)
    if not pdf.is_file():
        raise FileNotFoundError(f"No existe el PDF: {pdf}")
    pdf_digest = file_sha256(pdf)
    if out.exists() and not out.is_dir():
        raise NotADirectoryError(out)
    out.mkdir(parents=True, exist_ok=True)
    receipt_path = out / "PREVIEW.json"
    if receipt_path.exists():
        previous = json.loads(receipt_path.read_text(encoding="utf-8"))
        if previous.get("schema") != "ialp.preview.v1":
            raise ValueError("PREVIEW.json existente no pertenece a este generador.")
        # Only remove previously registered outputs with our exact basename
        # format. Unrelated files in the output directory remain untouched.
        for record in previous.get("images", []) + previous.get("contact_sheets", []):
            name = record.get("path", "")
            if re.fullmatch(r"page-\d+\.png|VERIFICACION_VISUAL(?:_\d+)?\.jpg", name):
                (out / name).unlink(missing_ok=True)
        receipt_path.unlink()
    image_records, contact_records, cards = [], [], []

    def save_sheet():
        if not cards:
            return
        width, height = max(c.width for c in cards), max(c.height for c in cards)
        sheet = Image.new("RGB", (width * 2, height * math.ceil(len(cards) / 2)), "white")
        for idx, card in enumerate(cards):
            sheet.paste(card, ((idx % 2) * width, (idx // 2) * height))
            card.close()
        name = "VERIFICACION_VISUAL.jpg" if not contact_records else f"VERIFICACION_VISUAL_{len(contact_records)+1:03d}.jpg"
        target = out / name
        sheet.save(target, quality=90)
        sheet.close()
        contact_records.append({"path": name, "sha256": file_sha256(target)})
        cards.clear()

    with fitz.open(pdf) as document:
        if document.needs_pass:
            raise ValueError("El PDF requiere contraseña.")
        selected = parse_pages(pages, len(document))
        for index in selected:
            target = out / f"page-{index+1:03d}.png"
            pix = document[index].get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72), alpha=False)
            pix.save(target)
            image_records.append({"page": index + 1, "path": target.name, "sha256": file_sha256(target)})
            with Image.open(target) as image:
                thumb_width = 500
                thumb = image.convert("RGB").resize((thumb_width, round(image.height * thumb_width / image.width)), Image.Resampling.LANCZOS)
                card = Image.new("RGB", (thumb.width + 24, thumb.height + 56), "white")
                card.paste(thumb, (12, 36))
                ImageDraw.Draw(card).text((12, 10), f"Página {index+1}", fill="black")
                cards.append(card)
                thumb.close()
            if len(cards) == 12:
                save_sheet()
        save_sheet()
        total = len(document)
    if file_sha256(pdf) != pdf_digest:
        raise RuntimeError("El PDF cambió al generar las vistas; no se emite un recibo incoherente.")
    result = {
        "schema": "ialp.preview.v1", "pdf": pdf.name, "pdf_sha256": pdf_digest,
        "status": "PREVIEW_GENERATED", "VISUAL_REVIEW": "NOT_RUN", "dpi": dpi,
        "total_pages": total, "selected_pages": [v + 1 for v in selected],
        "coverage": "ALL_PAGES" if len(selected) == total else "PARTIAL",
        "images": image_records, "contact_sheets": contact_records,
        "scope": "Imágenes generadas para inspección. Su existencia no acredita que se hayan revisado.",
    }
    receipt_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def _zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = 0o100644 << 16
    return info


def _contains_symlink(path: Path) -> bool:
    absolute = path.absolute()
    return any(part.is_symlink() for part in (absolute, *absolute.parents))


def package_files(zip_path: str | Path, files: list[str | Path], root: str | Path | None = None) -> dict:
    """Validate all inputs, then atomically create a ZIP with deterministic entries.

    MANIFEST.json includes every payload file. Its own hash is explicitly out of
    scope; a hash of the complete archive can be recorded outside the archive.
    """
    if not files:
        raise ValueError("No se han indicado entregables.")
    target = Path(zip_path)
    if _contains_symlink(target):
        raise ValueError("El destino ZIP no puede ser un enlace simbólico.")
    target = target.resolve()
    requested = []
    for value in files:
        path = Path(value)
        if _contains_symlink(path):
            raise ValueError(f"No se permiten enlaces simbólicos: {path}")
        if not path.exists():
            raise FileNotFoundError(f"Falta un entregable solicitado: {path}")
        requested.append(path.resolve())
    if root is None:
        base = Path(os.path.commonpath([str(p.parent) for p in requested]))
    else:
        if _contains_symlink(Path(root)):
            raise ValueError("La raíz no puede ser un enlace simbólico.")
        base = Path(root).resolve()
        if not base.is_dir():
            raise NotADirectoryError(base)
    entries: dict[str, Path] = {}
    portable_names: dict[str, str] = {}
    for requested_path in requested:
        candidates = sorted(requested_path.rglob("*")) if requested_path.is_dir() else [requested_path]
        included = 0
        for path in candidates:
            if path.is_symlink():
                raise ValueError(f"No se permiten enlaces simbólicos: {path}")
            if path.is_dir():
                continue
            if not path.is_file():
                raise ValueError(f"El entregable no es un archivo regular: {path}")
            path = path.resolve()
            if path == target:
                raise ValueError("El ZIP de salida no puede incluirse a sí mismo.")
            try:
                name = path.relative_to(base).as_posix()
            except ValueError as exc:
                raise ValueError(f"Archivo fuera de la raíz de entrega: {path}") from exc
            if "\\" in name or any(":" in part or part.endswith((".", " ")) for part in name.split("/")):
                raise ValueError(f"Ruta de archivo no portable a Windows: {name}")
            portable = unicodedata.normalize("NFC", name).casefold()
            if portable == "manifest.json":
                raise ValueError("MANIFEST.json está reservado para el inventario generado.")
            if portable in portable_names and portable_names[portable] != name:
                raise ValueError(f"Colisión de nombres en Windows: {name} / {portable_names[portable]}")
            if name in entries and entries[name] != path:
                raise ValueError(f"Dos archivos comparten la ruta de entrega: {name}")
            portable_names[portable] = name
            entries[name] = path
            included += 1
        if not included:
            raise ValueError(f"El directorio solicitado no contiene archivos: {requested_path}")
    if not entries:
        raise ValueError("No se creará un ZIP vacío.")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = None
    try:
        with tempfile.NamedTemporaryFile(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent, delete=False) as handle:
            temporary_path = Path(handle.name)
        manifest = {"schema": "ialp.delivery_manifest.v1", "algorithm": "sha256",
                    "hash_scope": "Todos los archivos de contenido; MANIFEST.json queda excluido de su propio inventario.", "files": []}
        with zipfile.ZipFile(temporary_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, path in sorted(entries.items()):
                before = path.stat()
                digest, size = sha256(), 0
                with path.open("rb") as source, archive.open(_zip_info(name), "w") as destination:
                    for block in iter(lambda: source.read(1024 * 1024), b""):
                        destination.write(block)
                        digest.update(block)
                        size += len(block)
                after = path.stat()
                if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                    raise RuntimeError(f"El archivo cambió durante el empaquetado: {path}")
                manifest["files"].append({"path": name, "bytes": size, "sha256": digest.hexdigest()})
            data = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")
            archive.writestr(_zip_info("MANIFEST.json"), data)
        os.replace(temporary_path, target)
        temporary_path = None
        return manifest
    finally:
        if temporary_path is not None:
            temporary_path.unlink(missing_ok=True)
