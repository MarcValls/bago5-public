"""Create a small, editable XLSX from explicit JSON data using XlsxWriter.

Supported column formats: text, integer, decimal and percent. Formulas require
an explicit numeric/text cached result. This module never calculates formulas.
Ordinary strings beginning with '=' are always written as literal strings.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import re
import tempfile


FORMATS = {"text": "@", "integer": "#,##0", "decimal": "#,##0.00", "percent": "0.0%"}
MAX_SHEETS = 64
MAX_COLUMNS = 256
MAX_ROWS = 100000
MAX_CELLS = 1000000


class WorkbookSpecError(ValueError):
    """The JSON data does not satisfy the documented workbook contract."""


def _reject_unknown(value: dict, allowed: set[str], location: str) -> None:
    extra = set(value) - allowed
    if extra:
        raise WorkbookSpecError(f"{location}: campos no admitidos: {', '.join(sorted(map(str, extra)))}")


def _number(value, location: str) -> None:
    try:
        finite = isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite:
        raise WorkbookSpecError(f"{location}: se requiere un número finito.")


def _text(value, location: str, *, nonempty: bool = False, limit: int = 32767) -> None:
    if not isinstance(value, str) or len(value) > limit or (nonempty and not value.strip()):
        raise WorkbookSpecError(f"{location}: se requiere texto{' no vacío' if nonempty else ''} de hasta {limit} caracteres.")


def _cell(value, location: str) -> bool:
    """Validate a value and return whether it is an explicit formula."""
    if isinstance(value, dict):
        _reject_unknown(value, {"formula", "result"}, location)
        if "formula" not in value or "result" not in value:
            raise WorkbookSpecError(f"{location}: una fórmula requiere formula y result explícitos; el kit no calcula resultados.")
        _text(value["formula"], location + ".formula", nonempty=True, limit=8192)
        if not value["formula"].startswith("=") or not value["formula"][1:].strip():
            raise WorkbookSpecError(f"{location}: formula debe empezar por '=' y contener una expresión.")
        result = value["result"]
        if isinstance(result, str):
            _text(result, location + ".result")
        else:
            _number(result, location + ".result")
        return True
    if value is None or isinstance(value, bool):
        return False
    if isinstance(value, str):
        _text(value, location)
    elif isinstance(value, (int, float)):
        _number(value, location)
    else:
        raise WorkbookSpecError(f"{location}: solo se admiten texto, número, booleano, null o una fórmula explícita.")
    return False


def validate_workbook_spec(spec: dict) -> dict:
    """Validate without touching files; return basic counts for reporting."""
    if not isinstance(spec, dict):
        raise WorkbookSpecError("La fuente debe contener un objeto JSON.")
    _reject_unknown(spec, {"title", "sheets"}, "libro")
    if "title" in spec:
        _text(spec["title"], "title", limit=255)
    sheets = spec.get("sheets")
    if not isinstance(sheets, list) or not 1 <= len(sheets) <= MAX_SHEETS:
        raise WorkbookSpecError(f"sheets debe contener de 1 a {MAX_SHEETS} hojas.")
    names = set()
    total_cells = 0
    summary = []
    for index, sheet in enumerate(sheets, 1):
        location = f"sheets[{index}]"
        if not isinstance(sheet, dict):
            raise WorkbookSpecError(f"{location}: se requiere un objeto.")
        _reject_unknown(sheet, {"name", "columns", "rows", "freeze_header"}, location)
        name = sheet.get("name")
        _text(name, location + ".name", nonempty=True, limit=31)
        if name != name.strip() or name.startswith("'") or name.endswith("'") or re.search(r"[\[\]:*?/\\\x00-\x1f]", name):
            raise WorkbookSpecError(f"Nombre de hoja no válido: {name!r}.")
        if name.casefold() == "history" or name.casefold() in names:
            raise WorkbookSpecError(f"Nombre de hoja duplicado o reservado: {name!r}.")
        names.add(name.casefold())
        columns = sheet.get("columns")
        if not isinstance(columns, list) or not 1 <= len(columns) <= MAX_COLUMNS:
            raise WorkbookSpecError(f"{location}.columns requiere de 1 a {MAX_COLUMNS} columnas.")
        for number, column in enumerate(columns, 1):
            col_location = f"{location}.columns[{number}]"
            if not isinstance(column, dict):
                raise WorkbookSpecError(f"{col_location}: se requiere un objeto.")
            _reject_unknown(column, {"header", "width", "format"}, col_location)
            _text(column.get("header"), col_location + ".header", nonempty=True, limit=128)
            if column.get("format", "text") not in FORMATS:
                raise WorkbookSpecError(f"{col_location}.format admite text, integer, decimal o percent.")
            if "width" in column:
                _number(column["width"], col_location + ".width")
                if not 4 <= column["width"] <= 80:
                    raise WorkbookSpecError(f"{col_location}.width debe estar entre 4 y 80.")
        rows = sheet.get("rows")
        if not isinstance(rows, list) or len(rows) > MAX_ROWS:
            raise WorkbookSpecError(f"{location}.rows debe ser una lista de hasta {MAX_ROWS} filas.")
        if not isinstance(sheet.get("freeze_header", True), bool):
            raise WorkbookSpecError(f"{location}.freeze_header debe ser booleano.")
        total_cells += (len(rows) + 1) * len(columns)
        if total_cells > MAX_CELLS:
            raise WorkbookSpecError(f"El libro supera {MAX_CELLS} celdas; divida el contenido.")
        formula_count = 0
        for row_index, row in enumerate(rows, 2):
            if not isinstance(row, list) or len(row) != len(columns):
                raise WorkbookSpecError(f"{name}, fila {row_index}: se requieren exactamente {len(columns)} valores.")
            for column_index, value in enumerate(row, 1):
                formula_count += _cell(value, f"{name}, fila {row_index}, columna {column_index}")
        summary.append({"name": name, "rows": len(rows), "columns": len(columns), "explicit_formulas": formula_count, "freeze_header": sheet.get("freeze_header", True)})
    return {"sheets": summary, "total_cells": total_cells}


def _atomic_bytes(path: Path, data: bytes) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=".ialp-source-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def create_workbook(spec: dict, output_path: str | Path, *, source_bytes: bytes | None = None) -> dict:
    """Create an XLSX atomically and preserve the exact or canonical JSON source.

    The source sidecar is <output>.source.json. Formula result caches come from
    the input, not from evaluation. Column formats control display and do not
    coerce strings into numbers. Each output file is committed atomically.
    """
    summary = validate_workbook_spec(spec)
    output = Path(output_path).absolute()
    if output.suffix.lower() != ".xlsx":
        raise WorkbookSpecError("La salida debe terminar en .xlsx.")
    if output.is_symlink() or (output.exists() and not output.is_file()):
        raise WorkbookSpecError("La salida debe ser un archivo regular, no un enlace ni un directorio.")
    source_copy = output.with_suffix(".source.json")
    if source_copy.is_symlink() or (source_copy.exists() and not source_copy.is_file()):
        raise WorkbookSpecError("La ruta de copia JSON debe ser un archivo regular.")
    raw = source_bytes if source_bytes is not None else (json.dumps(spec, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    if json.loads(raw) != spec:
        raise WorkbookSpecError("Los bytes de la fuente no corresponden a la especificación validada.")
    try:
        import xlsxwriter
    except ImportError as exc:
        raise RuntimeError("Falta XlsxWriter; instale las dependencias del kit.") from exc
    output.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=".ialp-workbook-", suffix=".xlsx", dir=output.parent)
    os.close(descriptor)
    temporary = Path(temporary_name)
    try:
        with xlsxwriter.Workbook(str(temporary), {"strings_to_formulas": False, "strings_to_urls": False, "constant_memory": True}) as workbook:
            workbook.set_properties({"title": spec.get("title", "IALP"), "author": "IALP editorial kit", "comments": "Fórmulas con resultados de caché proporcionados explícitamente; el kit no recalcula."})
            header = workbook.add_format({"bold": True, "font_color": "#FFFFFF", "bg_color": "#173D57", "text_wrap": True, "valign": "vcenter", "bottom": 2, "bottom_color": "#C9A64A", "font_name": "Calibri", "font_size": 11})
            formats = {}
            for name, number_format in FORMATS.items():
                for stripe in (False, True):
                    formats[(name, stripe)] = workbook.add_format({"num_format": number_format, "bg_color": "#F2F5F7" if stripe else "#FFFFFF", "font_color": "#1D2630", "valign": "top", "font_name": "Calibri", "font_size": 11})
            for sheet_spec in spec["sheets"]:
                sheet = workbook.add_worksheet(sheet_spec["name"])
                sheet.hide_gridlines(2)
                sheet.set_default_row(20)
                sheet.set_row(0, 32)
                columns, rows = sheet_spec["columns"], sheet_spec["rows"]
                for column_index, column in enumerate(columns):
                    width = column.get("width", min(40, max(14, len(column["header"]) + 3)))
                    sheet.set_column(column_index, column_index, width)
                    sheet.write_string(0, column_index, column["header"], header)
                if sheet_spec.get("freeze_header", True):
                    sheet.freeze_panes(1, 0)
                sheet.autofilter(0, 0, len(rows), len(columns) - 1)
                for row_index, row in enumerate(rows, 1):
                    for column_index, value in enumerate(row):
                        style = formats[(columns[column_index].get("format", "text"), row_index % 2 == 0)]
                        if isinstance(value, dict):
                            result = sheet.write_formula(row_index, column_index, value["formula"], style, value["result"])
                        elif isinstance(value, str):
                            result = sheet.write_string(row_index, column_index, value, style)
                        elif value is None:
                            result = sheet.write_blank(row_index, column_index, None, style)
                        elif isinstance(value, bool):
                            result = sheet.write_boolean(row_index, column_index, value, style)
                        else:
                            result = sheet.write_number(row_index, column_index, value, style)
                        if result != 0:
                            raise RuntimeError(f"No se pudo escribir {sheet_spec['name']}, fila {row_index + 1}, columna {column_index + 1}: código {result}.")
        if not temporary.stat().st_size:
            raise RuntimeError("XlsxWriter no generó un libro no vacío.")
        workbook_hash = hashlib.sha256(temporary.read_bytes()).hexdigest()
        _atomic_bytes(source_copy, raw)
        os.replace(temporary, output)
    finally:
        temporary.unlink(missing_ok=True)
    return {"schema_version": "1.0", "status": "CREATED", "backend": "XlsxWriter", "backend_version": xlsxwriter.__version__,
            "output_path": str(output), "output_sha256": workbook_hash,
            "source_copy_path": str(source_copy), "source_sha256": hashlib.sha256(raw).hexdigest(),
            "formula_policy": "Explicit cached results supplied by source; formulas were not calculated by the kit.",
            "sheets": summary["sheets"], "total_cells": summary["total_cells"]}
