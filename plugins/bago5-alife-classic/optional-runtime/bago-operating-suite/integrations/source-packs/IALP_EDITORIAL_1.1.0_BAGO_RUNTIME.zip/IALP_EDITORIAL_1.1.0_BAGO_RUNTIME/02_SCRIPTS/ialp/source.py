"""Preserve source text and record every intentional deletion reversibly.

Report offsets are zero-based Unicode code points in the original source, with
exclusive ends. UTF-8 hashes include original whitespace and line endings.
"""
from __future__ import annotations

import hashlib
import re
from collections.abc import Iterable
from typing import Any

import yaml

MODES = ("preserve", "explicit", "legacy")
LEGACY_KEYS = {"version", "state", "status", "close_date", "validation", "version_consolidada", "fecha_de_cierre"}
META_LINE = re.compile(r"^\s*\*\*(Proyecto|Volumen|Módulo|Versión|Versión consolidada|Estado|Fecha|Fecha de cierre|Documento):\*\*.*$", re.I)
MARKER = re.compile(r"<!--\s*IALP_CONTROL_(START|END)\s*-->", re.I)
COMMENT_START = re.compile(r"<!--\s*CONTROL INTERNO FUERA DEL LIBRO:", re.I)
HEADING = re.compile(r"^ {0,3}(#{1,6})[ \t]+(.+?)[ \t]*$", re.M)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _lines(text: str) -> list[tuple[int, str]]:
    rows, offset = [], 0
    for line in text.splitlines(keepends=True):
        rows.append((offset, line))
        offset += len(line)
    return rows


def _frontmatter(text: str) -> tuple[dict, str, int, int]:
    """Return metadata, body, YAML start and body start; zero offsets if absent."""
    rows = _lines(text)
    if not rows or rows[0][1].lstrip("\ufeff").rstrip("\r\n").rstrip(" \t") != "---":
        return {}, text, 0, 0
    yaml_start = len(rows[0][1])
    for offset, line in rows[1:]:
        if line.rstrip("\r\n").rstrip(" \t") in {"---", "..."}:
            try:
                meta = yaml.safe_load(text[yaml_start:offset])
            except yaml.YAMLError as exc:
                raise ValueError(f"Frontmatter YAML inválido: {exc}") from exc
            if meta is None:
                meta = {}
            if not isinstance(meta, dict):
                raise ValueError("El frontmatter YAML debe ser un mapa de claves y valores.")
            end = offset + len(line)
            return meta, text[end:], yaml_start, end
    raise ValueError("Frontmatter inicial sin delimitador de cierre --- o ... .")


def split_frontmatter(text: str) -> tuple[dict, str]:
    """Parse initial YAML with safe_load; absent metadata leaves text untouched."""
    meta, body, _, _ = _frontmatter(text)
    return meta, body


def _blank(text: str) -> str:
    return re.sub(r"[^\r\n]", " ", text)


def _mask_ranges(text: str, ranges: Iterable[tuple[int, int]]) -> str:
    chars = list(text)
    for start, end in ranges:
        chars[start:end] = _blank(text[start:end])
    return "".join(chars)


def _container_content(line: str) -> str:
    value = line.rstrip("\r\n")
    value = re.sub(r"^ {0,3}(?:>[ \t]?)+", "", value)
    value = re.sub(r"^ {0,3}(?:[-+*]|\d{1,9}[.)])[ \t]+", "", value)
    return value.lstrip(" \t")


def mask_code(text: str, *, mask_frontmatter: bool = True) -> str:
    """Blank code without shifting diagnostics; never change the real source.

    Protect fences, indented lines and paired inline backticks. Ambiguous
    indentation deliberately prefers preservation over removing content.
    """
    _, _, _, fm_end = _frontmatter(text) if mask_frontmatter else ({}, text, 0, 0)
    protected = [(0, fm_end)] if fm_end else []
    fence, comment = None, False
    for start, line in _lines(text):
        end = start + len(line)
        if start < fm_end:
            continue
        content = _container_content(line)
        if fence:
            protected.append((start, end))
            closing = re.fullmatch(r"(`+|~+)[ \t]*", content)
            if closing and closing[1][0] == fence[0] and len(closing[1]) >= fence[1]:
                fence = None
            continue
        if comment:
            if "-->" in line:
                comment = False
            continue
        if line.startswith("    ") or line.startswith("\t"):
            protected.append((start, end))
            continue
        if content.startswith("<!--"):
            comment = "-->" not in content
            continue
        opening = re.match(r"(`{3,}|~{3,})(.*)$", content)
        if opening and not (opening[1][0] == "`" and "`" in opening[2]):
            fence = (opening[1][0], len(opening[1]))
            protected.append((start, end))
    visible = _mask_ranges(text, protected)
    # Ignore backticks inside HTML comments while finding inline code spans;
    # leave actual comments visible for the explicit-marker detector.
    candidate = re.sub(r"<!--.*?-->", lambda m: _blank(m[0]), visible, flags=re.S)
    ticks = list(re.finditer(r"`+", candidate))
    i = 0
    while i < len(ticks):
        opening = ticks[i]
        before = candidate[:opening.start()]
        if (len(before) - len(before.rstrip("\\"))) % 2:
            i += 1
            continue
        closing = next((j for j in range(i + 1, len(ticks)) if len(ticks[j][0]) == len(opening[0])), None)
        if closing is None:
            i += 1
            continue
        protected.append((opening.start(), ticks[closing].end()))
        i = closing + 1
    return _mask_ranges(text, protected)


def _explicit_ranges(text: str, visible: str) -> list[tuple[int, int, str]]:
    ranges, comments = [], []
    for opening in COMMENT_START.finditer(visible):
        if any(a <= opening.start() < b for a, b in comments):
            continue
        closing = text.find("-->", opening.end())
        if closing < 0:
            raise ValueError("Comentario CONTROL INTERNO FUERA DEL LIBRO sin cierre -->.")
        end = closing + 3
        comments.append((opening.start(), end))
        ranges.append((opening.start(), end, "explicit_internal_comment"))
    start = None
    for marker in MARKER.finditer(_mask_ranges(visible, comments)):
        if marker[1].upper() == "START":
            if start is not None:
                raise ValueError("Bloques IALP_CONTROL anidados: no se elimina contenido ambiguo.")
            start = marker.start()
        else:
            if start is None:
                raise ValueError("IALP_CONTROL_END sin un IALP_CONTROL_START previo.")
            ranges.append((start, marker.end(), "explicit_control_block"))
            start = None
    if start is not None:
        raise ValueError("IALP_CONTROL_START sin IALP_CONTROL_END fuera de código.")
    return ranges


def _legacy_ranges(text: str, visible: str, names: Iterable[str]) -> list[tuple[int, int, str]]:
    ranges = []
    normalized = [name.strip().lower() for name in names if name.strip()]
    headings = list(HEADING.finditer(visible))
    for index, heading in enumerate(headings):
        level = len(heading[1])
        title = re.sub(r"^\d+(?:\.\d+)*[.)]?\s*", "", heading[2].strip().lower())
        if level < 2 or not any(title.startswith(name) for name in normalized):
            continue
        end = next((h.start() for h in headings[index + 1:] if len(h[1]) <= level), len(text))
        ranges.append((heading.start(), end, f"legacy_named_section:{heading[2].strip()}"))
    for start, line in _lines(visible):
        if META_LINE.match(line.rstrip("\r\n")):
            ranges.append((start, start + len(line), "legacy_metadata_line"))
    _, _, yaml_start, fm_end = _frontmatter(text)
    if fm_end:
        closing_start = next(start for start, line in _lines(text)[1:] if line.rstrip("\r\n").rstrip(" \t") in {"---", "..."})
        payload = text[yaml_start:closing_start]
        node = yaml.compose(payload, Loader=yaml.SafeLoader)
        if node is not None and node.flow_style and any(str(key.value).lower() in LEGACY_KEYS for key, _ in node.value):
            raise ValueError("legacy no retira campos de un mapa YAML en línea: use explicit o revise la fuente.")
        rows = _lines(payload)
        for key, value in node.value if node is not None else []:
            if str(key.value).lower() not in LEGACY_KEYS:
                continue
            start = rows[key.start_mark.line][0]
            end = max(start, value.end_mark.index)
            if end <= start:
                end = start + len(rows[key.start_mark.line][1])
            elif end < len(payload) and payload[end - 1] not in "\r\n":
                tail = re.search(r"\r\n|\r|\n", payload[end:])
                end = end + tail.end() if tail else len(payload)
            ranges.append((yaml_start + start, yaml_start + end, f"legacy_frontmatter:{key.value}"))
    return ranges


def _merge_ranges(ranges: Iterable[tuple[int, int, str]]) -> list[tuple[int, int, list[str]]]:
    merged = []
    for start, end, reason in sorted(ranges):
        if merged and start < merged[-1][1]:
            a, b, reasons = merged[-1]
            merged[-1] = (a, max(end, b), sorted(set(reasons + [reason])))
        else:
            merged.append((start, end, [reason]))
    return merged


def reconstruct_source(cleaned: str, report: dict[str, Any]) -> str:
    """Restore the original exactly from output plus the complete JSON report."""
    if sha256_text(cleaned) != report["output_sha256"]:
        raise ValueError("La salida no coincide con el SHA-256 del registro de limpieza.")
    parts, cursor, removed_length, last_end = [], 0, 0, 0
    for entry in report["removed"]:
        start, end, chunk = entry["start"], entry["end"], entry["text"]
        offset = start - removed_length
        if (start < last_end or end < start or len(chunk) != end - start
                or sha256_text(chunk) != entry["sha256"] or entry["output_offset"] != offset
                or not cursor <= offset <= len(cleaned)):
            raise ValueError("Registro de eliminación inconsistente.")
        parts.extend((cleaned[cursor:offset], chunk))
        cursor, last_end = offset, end
        removed_length += len(chunk)
    parts.append(cleaned[cursor:])
    restored = "".join(parts)
    if sha256_text(restored) != report["input_sha256"]:
        raise ValueError("No se puede reconstruir la fuente con el SHA-256 registrado.")
    return restored


def clean_source(text: str, mode: str = "explicit", names: Iterable[str] | None = None) -> tuple[str, dict]:
    """Apply recorded deletions only; never normalize Markdown whitespace.

    preserve is an exact copy; explicit removes marked internal material only;
    legacy opts into historical heading and metadata rules, respecting code.
    Every removed character is retained in the JSON-compatible report.
    """
    if mode not in MODES:
        raise ValueError(f"Modo desconocido: {mode}. Use {', '.join(MODES)}.")
    ranges = []
    if mode != "preserve":
        visible = mask_code(text)
        ranges = _explicit_ranges(text, visible)
        if mode == "legacy":
            ranges += _legacy_ranges(text, visible, names or [])
    parts, removed, cursor, removed_length = [], [], 0, 0
    for start, end, reasons in _merge_ranges(ranges):
        parts.append(text[cursor:start])
        chunk = text[start:end]
        removed.append({"start": start, "end": end, "output_offset": start - removed_length,
                        "start_line": text.count("\n", 0, start) + 1,
                        "end_line": text.count("\n", 0, max(start, end - 1)) + 1,
                        "reasons": reasons, "text": chunk, "sha256": sha256_text(chunk)})
        cursor = end
        removed_length += len(chunk)
    parts.append(text[cursor:])
    output = "".join(parts)
    if mode == "legacy":
        # Refuse dangling YAML aliases instead of publishing invalid metadata.
        split_frontmatter(output)
    report = {
        "schema_version": "ialp.source-cleaning/1", "mode": mode, "changed": output != text,
        "input_sha256": sha256_text(text), "output_sha256": sha256_text(output),
        "input_bytes": len(text.encode("utf-8")), "output_bytes": len(output.encode("utf-8")),
        "input_characters": len(text), "output_characters": len(output),
        "offset_unit": "unicode-codepoint", "offset_end": "exclusive",
        "removed_count": len(removed), "removed": removed,
        "preservation": {"method": "recorded_deletions_only", "reconstruction_verified": False},
    }
    report["preservation"]["reconstruction_verified"] = reconstruct_source(output, report) == text
    return output, report


def preflight_source(text: str, patterns: Iterable[re.Pattern | str] = ()) -> dict:
    """Return REVIEW for editorial warnings and ERROR for malformed structure."""
    result = {"status": "PASS", "exit_code": 0, "errors": [], "warnings": [], "pattern_hits": [], "headings": {"h1": 0, "h2": 0}}
    try:
        _, _, _, fm_end = _frontmatter(text)
        visible = mask_code(text)
        _explicit_ranges(text, visible)
    except ValueError as exc:
        result.update(status="ERROR", exit_code=1)
        result["errors"].append(str(exc))
        return result
    if not fm_end:
        result["warnings"].append("Sin frontmatter YAML inicial.")
    for heading in HEADING.finditer(visible):
        key = f"h{len(heading[1])}"
        if key in result["headings"]:
            result["headings"][key] += 1
    if result["headings"]["h1"] < 1:
        result["warnings"].append("Sin encabezados H1 fuera de código.")
    if result["headings"]["h2"] < 2:
        result["warnings"].append("Menos de dos encabezados H2 fuera de código.")
    for glyph in ("\ufffd", "\ufffe", "\uffff"):
        if glyph in visible:
            result["warnings"].append(f"Carácter sospechoso fuera de código: {glyph!r}.")
    for pattern in patterns:
        compiled = re.compile(pattern, re.I) if isinstance(pattern, str) else pattern
        for match in compiled.finditer(visible):
            result["pattern_hits"].append({"line": text.count("\n", 0, match.start()) + 1, "text": match[0], "pattern": compiled.pattern})
    if result["warnings"] or result["pattern_hits"]:
        result.update(status="REVIEW", exit_code=2)
    return result
