# PROMPT MAESTRO — IA. LA PREGUNTA · MAQUETACIÓN EDITORIAL v1.1.0

Trabaja sobre el manuscrito fuente suministrado y produce una edición publicable de IA. LA PREGUNTA. Usa el kit para generar también su propio manual, desde `10_MANUAL/MANUAL_DEL_KIT.md`. Distingue en cada informe lo propuesto, lo implementado y lo efectivamente verificado.

## Conservación y criterio editorial

1. La fuente conceptual manda. No reescribas doctrina para “mejorarla”; limita las correcciones inequívocas a ortografía, gramática y tipografía. Conserva fórmulas, tablas, listas, casos, invariantes y relaciones matemáticas.
2. Conserva una copia de la fuente original, sus recursos y sus huellas SHA-256. Trabaja en una salida nueva o vacía y conserva la ejecución anterior cuando haya correcciones.
3. Separa el contenido publicable del expediente de producción. Identifica por contexto las notas de chat, instrucciones de continuidad y estados internos. Un manual técnico puede explicar legítimamente nombres de archivos, comandos, estados y revisión visual: no los elimines por contener esas palabras.
4. Usa limpieza `explicit`, que conserva todo salvo los marcadores internos documentados. Usa `preserve` cuando no corresponda retirar nada. `legacy` requiere una elección expresa, lectura de sus reglas y revisión de cada eliminación; puede retirar metadatos o secciones legítimas.
5. Revisa `PREFLIGHT.json` y `LIMPIEZA.json`. Una advertencia de auditoría no autoriza a borrar contenido ni a reformular un concepto. Registra cualquier decisión editorial adicional.

## Composición y estructuras visuales

6. Mantén la identidad de la colección: portada azul marino con diagonal clara y acento dorado; interior blanco, jerarquía sobria, tablas legibles y paginación discreta. Evita páginas con solo un título cuando el contenido pueda comenzar en la misma página.
7. Genera con WeasyPrint un índice paginado y comprueba su correspondencia con el PDF final. Comprueba márgenes, fuentes, enlaces, imágenes y recursos locales. No declares probado el motor de navegador o Windows sin haberlos ejecutado.
8. Usa diagramas cuando clarifiquen una secuencia, dependencia, ciclo o arquitectura. El kit procesa Mermaid y DOT a SVG, gráficos declarativos `chart` y rangos XLSX `spreadsheet`. Conserva las fuentes de cada visual y sus informes. No inventes datos ni ejecutes Python procedente del manuscrito.
9. Mermaid es obligatorio si existen bloques Mermaid y no se ha pedido omitirlos. Un ejecutable ausente o un render fallido bloquea esa ejecución. `--skip-mermaid` conserva el código, registra `SKIPPED` y no permite presentar esos bloques como gráficos renderizados ni la entrega como final.
10. No prometas composición matemática LaTeX ni mapas geográficos: no están implementados. Las fórmulas pueden conservarse como texto o código; un mapa conceptual puede representarse mediante Mermaid.

## Comprobación y cierre

11. Tras generar el PDF, ejecuta la auditoría automática y genera vistas de todas las páginas. Inspecciona cada página a tamaño legible: portada, índice, cuerpo, tablas, cuadrículas, diagramas, código, cabeceras y pies. Una muestra o un contact sheet reducido no acredita el resto del documento.
12. Corrige los fallos de contenido o maquetación, regenera en otra salida y repite auditoría, vistas e inspección completa. Una revisión de un PDF anterior no aprueba el nuevo archivo: debe coincidir su SHA-256.
13. Antes del cierre, completa el checklist visual y registra la inspección con `09_registrar_revision_visual.py`, identificando a quien realmente revisó las páginas. Si revisó un agente, decláralo como tal; nunca atribuyas esa revisión al usuario.
14. Cierra con `10_cerrar_entrega.py` únicamente cuando los controles automáticos, la revisión visual completa y la integridad de las evidencias lo permitan. No edites `RUN.json` para convertir un estado pendiente en aprobación.

## Entregables

- PDF editorial y HTML editable con sus recursos locales.
- Fuente original, Markdown limpio y Markdown con visuales, con registro de transformaciones.
- Fuentes de gráficos y datos necesarios para reproducirlos; hojas XLSX editables cuando correspondan.
- Informes de preflight, limpieza, visuales, maquetación, auditoría, ejecución y vistas.
- Todas las imágenes de revisión, checklist cumplimentado y `REVISION_VISUAL.json` vinculado a la versión final.
- ZIP final `_ENTREGA.zip` con inventario SHA-256 y `ENTREGA.json`, solo después del cierre. Antes existe un paquete `_BORRADOR.zip`.

`AUTOMATIC_CHECKS_PASSED` describe controles automáticos. `visual_review: NOT_RUN` en `RUN.json` describe el momento de generación y se conserva como historial; la revisión posterior se consulta en el recibo y en `ENTREGA.json`. Una generación, una auditoría textual o un registro escrito sin inspección real no equivalen a validación visual ni conceptual.
