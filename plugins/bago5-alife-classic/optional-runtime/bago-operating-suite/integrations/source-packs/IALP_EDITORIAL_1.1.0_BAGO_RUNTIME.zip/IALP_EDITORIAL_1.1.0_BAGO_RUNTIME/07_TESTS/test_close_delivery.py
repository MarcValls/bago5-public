"""Integration: real two-page PDF -> audit/preview -> declared review -> closure.

The PDF and PNGs are rendered for real; generation metadata and reviewer
declarations are explicit synthetic fixtures to exercise release gates. These
tests do not assert that a human inspected the pages. No receipt produced here
leaves its temporary test directory.
"""
from __future__ import annotations

from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from zipfile import ZipFile

import fitz

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "02_SCRIPTS"
sys.path.insert(0, str(SCRIPTS))
from ialp.quality import audit_pdf, file_sha256, make_preview
from ialp.review import CHECKLIST_ITEMS, record_visual_review, validate_visual_review

spec = importlib.util.spec_from_file_location("ialp_close_delivery_cli", SCRIPTS / "10_cerrar_entrega.py")
closing = importlib.util.module_from_spec(spec)
spec.loader.exec_module(closing)


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def generation_inventory(folder):
    excluded = {"RUN.json", "REVISION_VISUAL.json", "ENTREGA.json"}
    return {path.relative_to(folder).as_posix(): file_sha256(path)
            for path in sorted(folder.rglob("*"))
            if path.is_file() and path.name not in excluded and path.suffix.lower() != ".zip"}


def bind_generation(folder):
    run = read_json(folder / "RUN.json")
    run["generation_files"] = generation_inventory(folder)
    write_json(folder / "RUN.json", run)


def build_fixture(folder, variant="Primero"):
    folder.mkdir(parents=True)
    texts = [
        f"{variant} documento de ensayo. Este texto ocupa el cuerpo de la primera pagina y permite comprobar su conservacion completa.",
        "La segunda pagina conserva sus palabras y sirve para probar la cobertura declarada de una revision visual completa.",
    ]
    pdf = folder / "ensayo_EDITORIAL.pdf"
    with fitz.open() as document:
        for content in texts:
            page = document.new_page(width=595, height=842)
            page.insert_textbox(fitz.Rect(72, 100, 520, 600), content, fontsize=12, fontname="helv")
        document.save(pdf)
    source = "\n\n".join(texts)
    (folder / "ensayo_ORIGINAL.md").write_text(source, encoding="utf-8")
    (folder / "ensayo_EDITORIAL_LIMPIO.md").write_text(source, encoding="utf-8")
    (folder / "CONTENIDO_ESPERADO.txt").write_text(source, encoding="utf-8")
    (folder / "ensayo_EDITORIAL.html").write_text("<!doctype html><html lang='es'><body><p>" + source + "</p></body></html>", encoding="utf-8")
    assets = folder / "assets"
    (assets / "fonts").mkdir(parents=True)
    (assets / "fonts" / "fixture-font.cff").write_bytes(fitz.Font("helv").buffer)
    illustration = assets / "figura.svg"
    illustration.write_text('<svg xmlns="http://www.w3.org/2000/svg" width="60" height="30"><rect width="60" height="30" fill="navy"/></svg>', encoding="utf-8")
    audit = audit_pdf(pdf, expected_text=source)
    if audit["TEXT_AUDIT"] != "PASS" or audit["CONTENT_CHECK"] != "PASS":
        raise AssertionError("El PDF real de la fixture no supera su auditoría: " + repr(audit))
    write_json(folder / "AUDITORIA.json", audit)
    make_preview(pdf, folder / "verificacion_visual", pages="all", dpi=72)
    write_json(folder / "VISUALES.json", {"schema_version": "1.0", "status": "NO_VISUALS",
        "counts": {"total": 0, "RENDERED": 0, "SKIPPED": 0, "FAILED": 0}, "items": [], "warnings": []})
    write_json(folder / "MAQUETACION.json", {"fixture": "Metadatos mínimos sintéticos para probar el cierre.",
        "toc_page_numbers": True, "resources": [{"path": "assets/figura.svg", "sha256": file_sha256(illustration)}]})
    write_json(folder / "RUN.json", {"schema": "ialp.run.v1", "status": "AUTOMATIC_CHECKS_PASSED",
        "pdf": pdf.name, "pdf_sha256": file_sha256(pdf), "visual_review": "NOT_RUN",
        "fixture": "Generación mínima de integración, sin declaración de inspección humana."})
    bind_generation(folder)
    return folder


class CloseDeliveryIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.shared = tempfile.TemporaryDirectory()
        cls.addClassCleanup(cls.shared.cleanup)
        cls.baseline = build_fixture(Path(cls.shared.name) / "baseline")

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)

    def fresh(self, name):
        return Path(shutil.copytree(self.baseline, self.folder / name))

    def record(self, folder, **overrides):
        args = {"reviewer": "REVISOR SINTETICO DE PRUEBAS; sin inspección humana",
                "inspected_pages": "all", "result": "PASS", "checklist": {
                    key: {"status": "PASS", "notes": "Declaración sintética para probar la transición de estado."}
                    for key in CHECKLIST_ITEMS}, "notes": "Fixture explícita de integración."}
        args.update(overrides)
        return record_visual_review(folder / "ensayo_EDITORIAL.pdf", **args)

    def seed_previous_delivery(self, folder):
        with ZipFile(folder / "ensayo_ENTREGA.zip", "w") as archive:
            archive.writestr("previous.txt", "Entrega anterior que debe conservarse si falla el cierre.")
        write_json(folder / "ENTREGA.json", {"status": "PREVIOUS_DELIVERY_SENTINEL"})

    def snapshot(self, folder):
        return {path.relative_to(folder).as_posix(): file_sha256(path)
                for path in folder.rglob("*") if path.is_file()}

    def assert_blocked_without_writes(self, folder, expected_error=None):
        before = self.snapshot(folder)
        with self.assertRaises((ValueError, FileNotFoundError)) as caught:
            closing.close_delivery(folder)
        if expected_error:
            self.assertIn(expected_error, str(caught.exception))
        self.assertEqual(self.snapshot(folder), before, "Un cierre bloqueado alteró archivos o la entrega previa.")

    def test_complete_review_closes_real_pdf_and_preserves_generation_inputs(self):
        folder = self.fresh("complete")
        self.record(folder)
        before = self.snapshot(folder)
        with ZipFile(folder / "ensayo_BORRADOR.zip", "w") as archive:
            archive.writestr("draft.txt", "Borrador excluido del paquete final.")
        self.seed_previous_delivery(folder)
        result = closing.close_delivery(folder)
        self.assertEqual(result["status"], "FINAL_REVIEWED")
        package = Path(result["package"])
        self.assertEqual(result["sha256"], file_sha256(package))
        for relative, digest in before.items():
            self.assertEqual(file_sha256(folder / relative), digest, relative)
        self.assertEqual(read_json(folder / "RUN.json")["visual_review"], "NOT_RUN")
        delivery = read_json(folder / "ENTREGA.json")
        self.assertEqual(delivery["review_sha256"], file_sha256(folder / "REVISION_VISUAL.json"))
        with ZipFile(package) as archive:
            names = archive.namelist()
            self.assertIn("ensayo_EDITORIAL.pdf", names)
            self.assertIn("REVISION_VISUAL.json", names)
            self.assertIn("ENTREGA.json", names)
            self.assertIn("assets/fonts/fixture-font.cff", names)
            self.assertFalse(any(name.endswith(".zip") for name in names))
            manifest = json.loads(archive.read("MANIFEST.json"))
            self.assertEqual({entry["path"] for entry in manifest["files"]}, set(names) - {"MANIFEST.json"})
            for entry in manifest["files"]:
                content = archive.read(entry["path"])
                self.assertEqual(entry["sha256"], sha256(content).hexdigest())
                self.assertEqual(entry["bytes"], len(content))

    def test_missing_partial_failed_or_incoherent_review_cannot_close(self):
        for state in ("missing", "partial", "failed", "incoherent"):
            with self.subTest(state=state):
                folder = self.fresh(state)
                if state != "missing":
                    receipt = self.record(folder, inspected_pages=[1] if state in {"partial", "incoherent"} else "all",
                                          result="FAIL" if state == "failed" else "PASS")
                    if state == "incoherent":
                        receipt.update(VISUAL_REVIEW="PASS", eligible_for_final_delivery=True, blockers=[])
                        write_json(folder / "REVISION_VISUAL.json", receipt)
                self.seed_previous_delivery(folder)
                self.assert_blocked_without_writes(folder)

    def test_not_run_or_failed_automatic_checks_and_limited_run_cannot_close(self):
        for key, value in (("CONTENT_CHECK", "NOT_RUN"), ("CONTENT_CHECK", "FAIL"),
                           ("TEXT_AUDIT", "FAIL"), ("RUN.status", "GENERATED_WITH_LIMITATIONS")):
            with self.subTest(key=key, value=value):
                folder = self.fresh(key.replace(".", "_") + value)
                path = folder / ("RUN.json" if key.startswith("RUN.") else "AUDITORIA.json")
                data = read_json(path)
                data["status" if key.startswith("RUN.") else key] = value
                write_json(path, data)
                bind_generation(folder)
                receipt = self.record(folder)
                self.assertFalse(receipt["eligible_for_final_delivery"])
                self.seed_previous_delivery(folder)
                self.assert_blocked_without_writes(folder)

    def test_failed_visuals_inventory_and_packaging_collision_preserve_previous_delivery(self):
        for state in ("SKIPPED", "FAILED", "NO_INVENTORY", "PACKAGING_COLLISION", "PACKAGING_COLLISION_NO_RECEIPT"):
            with self.subTest(state=state):
                folder = self.fresh(state)
                if state == "NO_INVENTORY":
                    data = read_json(folder / "RUN.json")
                    data.pop("generation_files")
                    write_json(folder / "RUN.json", data)
                elif state in {"SKIPPED", "FAILED"}:
                    data = read_json(folder / "VISUALES.json")
                    data["counts"].update(total=1, **{state: 1})
                    data["status"] = state
                    data["items"] = [{"id": "synthetic", "status": state}]
                    write_json(folder / "VISUALES.json", data)
                    bind_generation(folder)
                # The review records visual declarations; closure also checks
                # the generation inventory and the visual-renderer report.
                self.assertTrue(self.record(folder)["eligible_for_final_delivery"])
                self.seed_previous_delivery(folder)
                if state.startswith("PACKAGING_COLLISION"):
                    # A new file, absent from RUN.generation_files, collides
                    # with the packager's reserved root manifest. All review
                    # gates pass; package_files must fail after receipt staging.
                    write_json(folder / "MANIFEST.json", {"fixture": "Reserved-name collision, added after generation."})
                    if state == "PACKAGING_COLLISION_NO_RECEIPT":
                        (folder / "ENTREGA.json").unlink()
                self.assert_blocked_without_writes(folder, expected_error="MANIFEST.json está reservado" if state.startswith("PACKAGING_COLLISION") else None)

    def test_modified_sources_html_image_font_and_deleted_assets_are_blocked(self):
        for relative in ("ensayo_ORIGINAL.md", "ensayo_EDITORIAL_LIMPIO.md", "ensayo_EDITORIAL.html",
                         "assets/figura.svg", "assets/fonts/fixture-font.cff", "DELETE_FONT"):
            with self.subTest(relative=relative):
                folder = self.fresh(relative.replace("/", "_"))
                self.record(folder)
                if relative == "DELETE_FONT":
                    (folder / "assets/fonts/fixture-font.cff").unlink()
                else:
                    path = folder / relative
                    path.write_bytes(path.read_bytes() + b"\nchanged after generation")
                self.assertEqual(validate_visual_review(folder / "REVISION_VISUAL.json")["status"], "VALID")
                self.seed_previous_delivery(folder)
                self.assert_blocked_without_writes(folder)

    def test_changed_pdf_audit_preview_image_or_run_invalidates_closure(self):
        for relative in ("ensayo_EDITORIAL.pdf", "AUDITORIA.json", "verificacion_visual/PREVIEW.json",
                         "verificacion_visual/page-001.png", "RUN.json"):
            with self.subTest(relative=relative):
                folder = self.fresh(relative.replace("/", "_"))
                self.record(folder)
                path = folder / relative
                if path.suffix == ".json":
                    data = read_json(path)
                    data["post_review_edit"] = True
                    write_json(path, data)
                else:
                    path.write_bytes(path.read_bytes() + b"\npost-review mutation")
                self.seed_previous_delivery(folder)
                self.assert_blocked_without_writes(folder)

    def test_valid_receipt_for_another_pdf_cannot_approve_this_delivery(self):
        first = self.fresh("first_document")
        second = build_fixture(self.folder / "second_document", variant="Segundo y diferente")
        self.record(first, output_path=second / "REVISION_VISUAL.json")
        # This receipt is valid for the first document and has portable ../
        # references. Closure must force evidence paths for the second folder.
        self.assertTrue(validate_visual_review(second / "REVISION_VISUAL.json")["eligible_for_final_delivery"])
        self.seed_previous_delivery(second)
        self.assert_blocked_without_writes(second)

    def test_relocated_bundle_keeps_review_portable_and_cli_closes_it(self):
        folder = self.fresh("before_move")
        self.record(folder)
        moved = self.folder / "different_parent" / "renamed_bundle"
        moved.parent.mkdir()
        shutil.move(str(folder), moved)
        self.assertTrue(validate_visual_review(moved / "REVISION_VISUAL.json")["eligible_for_final_delivery"])
        result = subprocess.run([sys.executable, "-B", str(SCRIPTS / "10_cerrar_entrega.py"), str(moved)],
                                capture_output=True, text=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual(json.loads(result.stdout)["status"], "FINAL_REVIEWED")
        self.assertTrue((moved / "ensayo_ENTREGA.zip").is_file())


if __name__ == "__main__":
    unittest.main()
