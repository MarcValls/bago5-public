"""Visual contract tests. External CLIs are mocked unless explicitly marked real.

Matplotlib, Pillow and workbook tests generate real local assets. A mocked
Mermaid/Graphviz test demonstrates error handling, not native rendering support.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

import pytest

SCRIPTS = Path(__file__).resolve().parents[1] / "02_SCRIPTS"
sys.path.insert(0, str(SCRIPTS))
from ialp import visuals

SVG = '<svg xmlns="http://www.w3.org/2000/svg" width="100" height="40"><text x="2" y="20">Probado</text></svg>'


def _mock_svg_backend(monkeypatch, calls=None):
    """Controlled substitute; this is not evidence of native CLI execution."""
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))
    def run(command, **kwargs):
        if calls is not None:
            calls.append((command, kwargs))
        Path(command[command.index("-o") + 1]).write_text(SVG, encoding="utf-8")
        return subprocess.CompletedProcess(command, 0, "", "")
    monkeypatch.setattr(visuals.subprocess, "run", run)


def test_example_fences_are_not_executed(monkeypatch, tmp_path):
    def unexpected(*args, **kwargs):
        pytest.fail("A quoted example must not launch a renderer")
    monkeypatch.setattr(visuals.shutil, "which", unexpected)
    source = '# Manual\n\n````markdown\n```mermaid\ngraph TD\nA-->B\n```\n````\n\n~~~~text\n```dot\ndigraph {a->b}\n```\n~~~~\n'
    output, report = visuals.render_visuals(source, tmp_path)
    assert output == source
    assert report["counts"] == {"total": 0, "RENDERED": 0, "SKIPPED": 0, "FAILED": 0}
    assert report["status"] == "NO_VISUALS"


def test_tilde_fence_mock_backend_records_real_counts_and_hashes(monkeypatch, tmp_path):
    calls = []
    _mock_svg_backend(monkeypatch, calls)
    source = 'Antes\n\n~~~mermaid\ngraph TD\nA-->B\n~~~\n\nDespués\n'
    output, report = visuals.render_visuals(source, tmp_path)
    item = report["items"][0]
    assert report["counts"]["RENDERED"] == 1
    assert item["output_path"].endswith(".svg")
    assert item["output_path"] in output
    assert "Antes" in output and "Después" in output
    assert hashlib.sha256((tmp_path / item["source_path"]).read_bytes()).hexdigest() == item["source_sha256"]
    assert hashlib.sha256((tmp_path / item["output_path"]).read_bytes()).hexdigest() == item["output_sha256"]
    command, kwargs = calls[0]
    assert isinstance(command, list) and kwargs.get("shell", False) is False
    assert kwargs["timeout"] == 90
    assert json.loads((tmp_path / item["config_path"]).read_text())["htmlLabels"] is False


def test_missing_mermaid_is_a_failure_unless_explicitly_skipped(monkeypatch, tmp_path):
    monkeypatch.setattr(visuals.shutil, "which", lambda name: None)
    source = '```mermaid\ngraph TD\nA-->B\n```\n'
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals(source, tmp_path / "required")
    assert caught.value.report["counts"]["FAILED"] == 1
    assert caught.value.report["counts"]["RENDERED"] == 0
    assert caught.value.transformed_markdown == source
    output, report = visuals.render_visuals(source, tmp_path / "skip", mermaid_mode="skip")
    assert output == source
    assert report["status"] == "SKIPPED"
    assert report["counts"]["SKIPPED"] == 1
    assert report["counts"]["RENDERED"] == 0


def test_mock_mermaid_error_never_claims_render_success(monkeypatch, tmp_path):
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))
    monkeypatch.setattr(visuals.subprocess, "run", lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 7, "", "syntax error"))
    source = '```mermaid\ninvalid source\n```\n'
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals(source, tmp_path)
    report = caught.value.report
    assert report["counts"] == {"total": 1, "RENDERED": 0, "SKIPPED": 0, "FAILED": 1}
    assert report["items"][0]["returncode"] == 7
    assert "syntax error" in report["items"][0]["error"]
    assert report["items"][0]["output_path"] is None
    assert caught.value.transformed_markdown == source
    assert not list((tmp_path / "assets_visuals").glob("*.png"))


def test_mock_success_without_output_is_failed(monkeypatch, tmp_path):
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))
    monkeypatch.setattr(visuals.subprocess, "run", lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, "", ""))
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals('```dot\ndigraph {a->b}\n```\n', tmp_path)
    assert "no produjo" in caught.value.report["items"][0]["error"]


def test_mock_timeout_is_reported(monkeypatch, tmp_path):
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))
    def timeout(command, **kwargs):
        raise subprocess.TimeoutExpired(command, kwargs["timeout"])
    monkeypatch.setattr(visuals.subprocess, "run", timeout)
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals('```mermaid\ngraph TD\nA-->B\n```\n', tmp_path, timeout=0.1)
    assert "límite" in caught.value.report["items"][0]["error"]


def test_mock_graphviz_has_svg_output_and_does_not_use_shell(monkeypatch, tmp_path):
    calls = []
    _mock_svg_backend(monkeypatch, calls)
    output, report = visuals.render_visuals('```graphviz\ndigraph {a->b}\n```\n', tmp_path)
    assert report["items"][0]["kind"] == "dot"
    assert "-Tsvg" in calls[0][0]
    assert report["items"][0]["output_path"] in output


def test_png_requires_explicit_request_mock_external_real_png(monkeypatch, tmp_path):
    Image = pytest.importorskip("PIL.Image")
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))
    def png(command, **kwargs):
        Image.new("RGB", (40, 20), "white").save(command[command.index("-o") + 1], format="PNG")
        return subprocess.CompletedProcess(command, 0, "", "")
    monkeypatch.setattr(visuals.subprocess, "run", png)
    _, report = visuals.render_visuals('```mermaid\ngraph TD\nA-->B\n```\n', tmp_path, mermaid_format="png")
    assert report["items"][0]["format"] == "png"
    assert report["items"][0]["output_path"].endswith(".png")


def test_mock_mermaid_svg_intrinsic_dimensions_preserve_vector_body(monkeypatch, tmp_path):
    """Realistic Mermaid 12 markup; the external renderer is a controlled mock."""
    original = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<!-- Example text <svg width="999" height="999"> is not the root. -->\n'
        '<svg id="my-svg" width="100%" xmlns="http://www.w3.org/2000/svg" '
        'xmlns:xlink="http://www.w3.org/1999/xlink" class="flowchart" '
        'style="max-width: 307.133px; background-color: transparent;" '
        'viewBox="4 4 307.13336181640625 882.2000122070312" role="graphics-document document">'
        '<defs><style>@font-face{font-family:"Embedded";src:url("data:font/woff2;base64,d09GMg==")}</style></defs>'
        '<g class="node"><rect width="120" height="30"/><text x="12" y="20">Fuente ágil</text></g></svg>'
    ).encode("utf-8")
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))

    def run(command, **kwargs):
        Path(command[command.index("-o") + 1]).write_bytes(original)
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(visuals.subprocess, "run", run)
    _, report = visuals.render_visuals('```mermaid\ngraph TD\nA-->B\n```\n', tmp_path)
    item = report["items"][0]
    normalized = (tmp_path / item["output_path"]).read_bytes()
    root = ET.fromstring(normalized)
    assert float(root.attrib["width"]) == pytest.approx(307.13336181640625)
    assert float(root.attrib["height"]) == pytest.approx(882.2000122070312)
    assert float(root.attrib["width"]) / float(root.attrib["height"]) == pytest.approx(307.13336181640625 / 882.2000122070312)
    assert normalized[normalized.index(b"<defs>"):] == original[original.index(b"<defs>"):]
    assert b'<svg width="999" height="999">' in normalized
    assert root.attrib["style"] == "max-width: 307.133px; background-color: transparent;"
    change = item["postprocessing"][0]
    assert change["status"] == "APPLIED"
    assert change["before"] == {"width": "100%", "height": None}
    assert change["input_sha256"] == hashlib.sha256(original).hexdigest()
    assert change["output_sha256"] == item["output_sha256"] == hashlib.sha256(normalized).hexdigest()


@pytest.mark.parametrize("succeeds", [True, False])
def test_mock_backend_staging_cleanup_never_removes_unrelated_files(monkeypatch, tmp_path, succeeds):
    asset_dir = tmp_path / "assets_visuals"
    asset_dir.mkdir()
    foreign = asset_dir / ".ialp-render-foreign.svg"
    foreign.write_text("Not owned by this render", encoding="utf-8")
    foreign_dir = asset_dir / ".ialp-render-foreign"
    foreign_dir.mkdir()
    (foreign_dir / "keep.txt").write_text("Keep", encoding="utf-8")
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))
    owned = []

    def run(command, **kwargs):
        output = Path(command[command.index("-o") + 1])
        owned.append(output.parent)
        assert not output.exists(), "Do not precreate the backend's output image"
        output.write_text(SVG if succeeds else "partial", encoding="utf-8")
        (output.parent / "backend-sidecar.tmp").write_text("Temporary", encoding="utf-8")
        return subprocess.CompletedProcess(command, 0 if succeeds else 1, "", "" if succeeds else "backend error")

    monkeypatch.setattr(visuals.subprocess, "run", run)
    source = '```mermaid\ngraph TD\nA-->B\n```\n'
    if succeeds:
        _, report = visuals.render_visuals(source, tmp_path)
        assert report["counts"]["RENDERED"] == 1
    else:
        with pytest.raises(visuals.VisualRenderError):
            visuals.render_visuals(source, tmp_path)
    assert owned and all(not path.exists() for path in owned)
    assert foreign.read_text(encoding="utf-8") == "Not owned by this render"
    assert (foreign_dir / "keep.txt").read_text(encoding="utf-8") == "Keep"


@pytest.mark.parametrize("viewbox", ["0 0 -10 20", "0 0 10 NaN", "0 0 0 0"])
def test_invalid_mermaid_viewbox_cannot_claim_rendered(monkeypatch, tmp_path, viewbox):
    monkeypatch.setattr(visuals.shutil, "which", lambda name: str(name))

    def run(command, **kwargs):
        Path(command[command.index("-o") + 1]).write_text(
            '<svg xmlns="http://www.w3.org/2000/svg" width="100%" viewBox="' + viewbox + '"></svg>', encoding="utf-8")
        return subprocess.CompletedProcess(command, 0, "", "")

    monkeypatch.setattr(visuals.subprocess, "run", run)
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals('```mermaid\ngraph TD\nA-->B\n```\n', tmp_path)
    assert caught.value.report["counts"]["FAILED"] == 1
    assert caught.value.report["counts"]["RENDERED"] == 0
    assert "viewBox" in caught.value.report["items"][0]["error"]


@pytest.mark.parametrize("spec", [
    {"type": "bar", "labels": ["A", "B"], "values": [2, 5], "title": "Barras"},
    {"type": "line", "x": [1, 3, 7], "y": [2, 8, 4], "title": "Evolución"},
    {"type": "heatmap", "values": [[1, 2], [3, 4]], "xlabels": ["A", "B"], "ylabels": ["X", "Y"]},
])
def test_chart_real_matplotlib_svg(tmp_path, spec):
    pytest.importorskip("matplotlib")
    source = '```chart\n' + json.dumps(spec, ensure_ascii=False) + '\n```\n'
    output, report = visuals.render_visuals(source, tmp_path)
    item = report["items"][0]
    svg = tmp_path / item["output_path"]
    assert ET.parse(svg).getroot().tag.endswith("svg")
    assert item["backend"] == "matplotlib"
    assert report["counts"]["RENDERED"] == 1
    assert item["output_path"] in output
    if spec.get("title"):
        assert spec["title"] in svg.read_text(encoding="utf-8")


@pytest.mark.parametrize("body", [
    '{"type":"bar","labels":["A"],"values":[1,2]}',
    '{"type":"line","values":[NaN]}',
    'import os; os.system("echo forbidden")',
])
def test_invalid_chart_is_reported_without_python_execution(tmp_path, body):
    pytest.importorskip("matplotlib")
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals('```chart\n' + body + '\n```\n', tmp_path)
    assert caught.value.report["counts"]["FAILED"] == 1
    assert caught.value.report["counts"]["RENDERED"] == 0


def test_real_spreadsheet_extracts_values_and_preserves_input(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    path = source_dir / "datos.xlsx"
    wb = openpyxl.Workbook()
    wb.active.title = "Resumen"
    wb.active.append(["Capacidad", "Casos"])
    wb.active.append(["A | B", 7])
    wb.save(path)
    original = path.read_bytes()
    spec = {"path": "datos.xlsx", "sheet": "Resumen", "range": "A1:B2"}
    output, report = visuals.render_visuals('```spreadsheet\n' + json.dumps(spec) + '\n```\n', tmp_path / "out", source_dir=source_dir)
    item = report["items"][0]
    assert '| Capacidad | Casos |' in output
    assert '| A \\| B | 7 |' in output
    assert path.read_bytes() == original
    assert (tmp_path / "out" / item["input_copy_path"]).read_bytes() == original
    assert item["input_sha256"] == hashlib.sha256(original).hexdigest()


def test_real_spreadsheet_formula_without_cache_fails(tmp_path):
    openpyxl = pytest.importorskip("openpyxl")
    wb = openpyxl.Workbook()
    wb.active.append(["Valor"])
    wb.active.append(["=1+2"])
    wb.save(tmp_path / "formula.xlsx")
    source = '```spreadsheet\n{"path":"formula.xlsx","range":"A1:A2"}\n```\n'
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals(source, tmp_path / "out", source_dir=tmp_path)
    assert "caché" in caught.value.report["items"][0]["error"]
    assert "A2" in caught.value.report["items"][0]["error"]
    assert caught.value.transformed_markdown == source


def test_real_spreadsheet_cached_formula_uses_saved_result(tmp_path):
    pytest.importorskip("openpyxl")
    xlsxwriter = pytest.importorskip("xlsxwriter")
    with xlsxwriter.Workbook(tmp_path / "cached.xlsx") as wb:
        sheet = wb.add_worksheet("Datos")
        sheet.write("A1", "Resultado")
        sheet.write_formula("A2", "=1+2", None, 3)
    source = '```spreadsheet\n{"path":"cached.xlsx","sheet":"Datos","range":"A1:A2"}\n```\n'
    output, report = visuals.render_visuals(source, tmp_path / "out", source_dir=tmp_path)
    assert '| 3 |' in output
    assert report["items"][0]["formulas_with_cached_values"] == 1


def test_spreadsheet_path_cannot_escape_source_folder(tmp_path):
    pytest.importorskip("openpyxl")
    with pytest.raises(visuals.VisualRenderError) as caught:
        visuals.render_visuals('```spreadsheet\n{"path":"../outside.xlsx"}\n```\n', tmp_path / "out", source_dir=tmp_path)
    assert "dentro" in caught.value.report["items"][0]["error"]


def test_cli_missing_renderer_writes_failed_report_and_no_output(tmp_path):
    source, output, report = tmp_path / "input.md", tmp_path / "output.md", tmp_path / "report.json"
    source.write_text('```mermaid\ngraph TD\nA-->B\n```\n', encoding="utf-8")
    result = subprocess.run([sys.executable, str(SCRIPTS / "02_render_mermaid_opcional.py"), str(source), str(output), "--report", str(report), "--mmdc", str(tmp_path / "missing-mmdc")], capture_output=True, text=True)
    assert result.returncode == 2
    assert "FAILED" in result.stderr
    assert not output.exists()
    assert json.loads(report.read_text(encoding="utf-8"))["counts"]["FAILED"] == 1
