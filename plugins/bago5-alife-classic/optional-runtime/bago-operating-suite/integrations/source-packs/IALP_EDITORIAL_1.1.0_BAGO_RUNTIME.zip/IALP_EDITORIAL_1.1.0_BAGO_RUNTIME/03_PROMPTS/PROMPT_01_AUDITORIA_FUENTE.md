# PROMPT — AUDITORÍA DE FUENTE ANTES DE MAQUETAR

Audita el manuscrito como editor independiente antes de maquetar. Conserva la fuente y devuelve el inventario de hallazgos antes de aplicar cambios. Si la tarea ya autoriza corregir problemas identificados, continúa dentro de ese alcance; no conviertas cada advertencia en una solicitud nueva de permiso.

## Qué inspeccionar

- Contenido de chat, continuidad operativa, dictámenes y estados internos que no pertenezcan al contenido publicable.
- “Siguiente acción”, notas finales de conversación y referencias que no puedan entenderse fuera de su contexto de origen.
- Nombres de archivos, versiones y marcadores de producción, distinguiendo el expediente de los ejemplos técnicos legítimos.
- Duplicación de títulos, módulos o preliminares y secciones vacías que solo marquen una tarea pendiente.
- Frontmatter YAML mal formado, encabezados reales y bloques de código sin cerrar; no cuentes como títulos los comentarios o ejemplos dentro de código.
- Imágenes y otros recursos locales: ruta respecto del manuscrito, existencia, formato y necesidad de conservarlos con la salida.
- Mermaid, DOT, `chart` y `spreadsheet`: sintaxis, dependencias, datos internos, rangos y presencia de valores en caché para fórmulas XLSX.
- Residuos visibles de Markdown/HTML, errores ortográficos, caracteres dañados y fórmulas o tablas incompletas.

## Clasificación

Para cada hallazgo, aporta ubicación, fragmento, motivo y acción propuesta:

- RETIRAR DEL LIBRO: material de producción inequívoco, con eliminación trazable.
- CONSERVAR EN EXPEDIENTE: evidencia o instrucción útil fuera del contenido publicado.
- CONSERVAR EN LIBRO: contenido conceptual o ejemplo técnico legítimo.
- REESCRIBIR COMO EJEMPLO AUTOCONTENIDO: mantiene el concepto, elimina una dependencia conversacional; exige una decisión editorial explícita.
- DUDA EDITORIAL: falta contexto suficiente para decidir sin alterar significado.

En un manual del kit, comandos, archivos, estados y procedimientos de revisión son parte del tema. No retires esas explicaciones por una coincidencia de palabras. No rebajes la auditoría suprimiendo patrones para ocultar un problema: justifica cualquier perfil de patrones específico del documento.

## Resultado

Entrega el inventario y un veredicto GO/NO GO para iniciar maquetación, con las dependencias pendientes. Ese veredicto de fuente no aprueba el PDF final. Explica qué resuelve el preflight automático y qué hallazgos requieren criterio editorial; una advertencia `REVIEW` no es una eliminación automática.
