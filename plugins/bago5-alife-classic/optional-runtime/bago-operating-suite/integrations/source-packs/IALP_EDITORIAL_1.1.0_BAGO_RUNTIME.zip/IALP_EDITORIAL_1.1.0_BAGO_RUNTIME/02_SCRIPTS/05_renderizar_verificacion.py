#!/usr/bin/env python3
"""Genera vistas para inspección; no declara una aceptación visual."""
from __future__ import annotations
import argparse
import json
import sys
from ialp.quality import make_preview, parse_pages


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf")
    parser.add_argument("outdir")
    parser.add_argument("--pages", default="all", help="all, sample o lista: 1,2,-1")
    parser.add_argument("--dpi", type=int, default=120)
    args = parser.parse_args()
    try:
        result = make_preview(args.pdf, args.outdir, args.pages, args.dpi)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(f"ERROR: vistas no generadas: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
