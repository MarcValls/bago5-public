#!/usr/bin/env python3
"""Registra una inspección visual explícita; generar PNG no constituye una revisión."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from ialp.review import CHECKLIST_ITEMS, record_visual_review, validate_visual_review


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", nargs="?", help="PDF ya renderizado y auditado")
    parser.add_argument("--reviewer", help="Identidad del revisor que inspeccionó las páginas")
    parser.add_argument("--pages", help="Declaración explícita: all o lista como 1,3-5")
    parser.add_argument("--verdict", choices=["PASS", "FAIL"], help="Veredicto declarado por el revisor")
    parser.add_argument("--checklist", help="JSON con los siete ítems y su status/notes; obligatorio al registrar")
    parser.add_argument("--note", action="append", default=[], help="Nota de revisión; se puede repetir")
    parser.add_argument("--findings", help="JSON opcional: lista de hallazgos description, severity, page e item")
    parser.add_argument("--reviewed-at", help="Fecha ISO 8601 con zona; por defecto fecha UTC actual")
    parser.add_argument("--preview", help="PREVIEW.json; por defecto verificacion_visual/PREVIEW.json")
    parser.add_argument("--audit", help="AUDITORIA.json; por defecto junto al PDF")
    parser.add_argument("--run", help="RUN.json; por defecto se vincula si existe junto al PDF")
    parser.add_argument("--out", help="Destino del recibo; por defecto REVISION_VISUAL.json junto al PDF")
    parser.add_argument("--validate", metavar="RECIBO", help="Comprueba un recibo existente y sus evidencias sin modificarlo")
    parser.add_argument("--checklist-template", action="store_true", help="Muestra el checklist pendiente en JSON; no registra una revisión")
    args = parser.parse_args()
    if args.checklist_template:
        if args.validate or args.pdf:
            parser.error("--checklist-template se utiliza sin PDF ni --validate")
        print(json.dumps({key: {"status": "NOT_RUN", "notes": label} for key, label in CHECKLIST_ITEMS.items()}, ensure_ascii=False, indent=2))
        return 0
    try:
        if args.validate:
            if args.reviewer or args.pages or args.verdict or args.checklist or args.findings or args.note or args.reviewed_at or args.out:
                parser.error("--validate no admite declaraciones nuevas ni --out")
            result = validate_visual_review(args.validate, pdf_path=args.pdf, preview_path=args.preview,
                                            audit_path=args.audit, run_path=args.run)
        else:
            if not all((args.pdf, args.reviewer, args.pages, args.verdict, args.checklist)):
                parser.error("Para registrar son obligatorios PDF, --reviewer, --pages, --verdict y --checklist")
            checklist = json.loads(Path(args.checklist).read_text(encoding="utf-8"))
            findings = json.loads(Path(args.findings).read_text(encoding="utf-8")) if args.findings else None
            result = record_visual_review(args.pdf, reviewer=args.reviewer, inspected_pages=args.pages,
                result=args.verdict, checklist=checklist, notes="\n".join(args.note), findings=findings,
                preview_path=args.preview, audit_path=args.audit, run_path=args.run,
                reviewed_at=args.reviewed_at, output_path=args.out)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["eligible_for_final_delivery"] else 2
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
