#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Preflight sin mutaciones: 0 PASS básico, 2 REVIEW editorial, 1 ERROR.

Valida el frontmatter inicial con YAML real y excluye código de las reglas de
encabezados/patrones. PASS no acredita conservación ni calidad del PDF.
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path
from ialp.source import preflight_source, sha256_text


class PreflightParser(argparse.ArgumentParser):
    def error(self, message):
        self.print_usage(sys.stderr)
        self.exit(1, f"ERROR: {message}\n")


def load_patterns(path: Path) -> list[re.Pattern]:
    return [re.compile(line.strip(), re.I) for line in path.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")]


def main() -> int:
    parser = PreflightParser(description=__doc__)
    parser.add_argument("source")
    parser.add_argument("--patterns")
    parser.add_argument("--report", help="Informe JSON opcional.")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    try:
        root = Path(__file__).resolve().parents[1]
        patterns = load_patterns(Path(args.patterns) if args.patterns else root / "05_CONFIG" / "patrones_no_editoriales.txt")
        text = source.read_bytes().decode("utf-8")
        report = preflight_source(text, patterns)
        report.update(source_path=str(source), input_sha256=sha256_text(text))
        if args.report:
            report_path = Path(args.report).resolve()
            if report_path == source:
                raise ValueError("El informe no puede sustituir la fuente.")
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    except (OSError, UnicodeError, ValueError, re.error) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    print(f"Archivo: {source}")
    print(f"Caracteres: {len(text):,} | H1: {report['headings']['h1']} | H2: {report['headings']['h2']}")
    for issue in report["errors"]:
        print(f"[ERROR] {issue}")
    for warning in report["warnings"]:
        print(f"[AVISO] {warning}")
    for hit in report["pattern_hits"][:80]:
        print(f"[AVISO] L{hit['line']}: {hit['text']}")
    print(f"RESULTADO: {report['status']}")
    return report["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
