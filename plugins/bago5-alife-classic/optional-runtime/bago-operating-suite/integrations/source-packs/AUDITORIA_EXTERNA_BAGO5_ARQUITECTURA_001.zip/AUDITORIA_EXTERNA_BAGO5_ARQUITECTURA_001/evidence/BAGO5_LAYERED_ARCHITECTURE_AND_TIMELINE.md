# BAGO5 layered architecture and timeline

**Context date:** 2026-10-11  
**Canonical project entrypoint requested:** E:\proyectos curriculum\BAGO_5.0  
**Current working repository:** E:\proyectos curriculum\BAGO_5.0\BAGO5_LAYERS

This document describes versioning BAGO5 with BAGO Layer / LAE principles. It does not create a separate BAGO Layer product.

## Architecture scheme

~~~mermaid
flowchart LR
    S["Sketch / proposal<br/>PROPOSED"] --> R["Review and adapt<br/>evidence + exact delta"]
    R --> L["Immutable layer<br/>parent-bound, content-addressed"]
    B["BPBR v0.1 complete motor<br/>original canonical root"] --> C["Parent reference + selected block layer chain"]
    L --> C
    C --> M["Deterministic resolver / materializer<br/>NOT IMPLEMENTED"]
    M --> X["Effective snapshot<br/>tree digest + provenance"]
    X --> E["Verification evidence<br/>linked to exact parent, layers, tool"]
    E --> K{"Implementation block accepted?"}
    K -->|yes| N["Immutable reference snapshot<br/>starting point for next block"]
    N --> C
    I["JSON master index"] --> B
    I --> L
    I --> X
    I --> E
~~~

### Identity and storage rules

| Entity | What it points to | Identity / evidence |
|---|---|---|
| Canonical root | The existing complete BPBR v0.1 reference tree | File inventory plus LAE canonical root digest |
| Candidate | The preserved kernel sketch source tree | Source inventory and candidate tree digest; state PROPOSED |
| Layer | A minimal delta against one exact parent, with a digest-bound intentionality report | Immutable layer-core digest; added bytes by content-addressed object |
| Snapshot selection | Parent reference ID, primary layer ID and ordered layer IDs for one implementation block | Selection digest and exact-parent chain |
| Materialized snapshot | Resolver output for one selection | Effective tree digest, materializer identity and receipt |
| Reference snapshot | Accepted block result and starting point for the next block; layer count is dynamic | Immutable parent/lineage, selected layers, effective tree digest and acceptance receipt |
| Evidence | Checks and claims about exact records | Content digest, record paths and raw byte checksums |
| Master index | Navigable links among all records | Relative record references, raw SHA-256 and entity digest |

The original root is never copied into a layer. Unchanged files are inherited from the parent reference. A snapshot is a selection manifest; only a resolver can turn it into an executed materialized tree. At accepted implementation-block closure, create a new immutable reference snapshot for the next block. The number of layers is determined by the block, not by a fixed interval. Historical layers, references and evidence remain addressable; none are deleted when a new reference is created.

This block/reference lifecycle is a fixed design decision; the current seeded schemas and verifier do not yet implement reference snapshots or intentionality reports.

## Current seeded state

| Item | State | Bound identity |
|---|---|---|
| BPBR v0.1 root | VERIFIED by current inventory check | 57a5f06b854268ad279fa474bac4455e552487283bc650ac53c5aa8c87cf7f4b |
| Kernel sketch | PROPOSED, not in a snapshot | 17f034c893681593574adb0cce85dd54d49da07c445c3d0d3132fb8aabef313e |
| Layer catalog | Empty; no layer sealed | BAGO5_LAYER_CATALOG |
| BPBR root-only selection | PREPARED; no materializer run | 1795f9b87b7b30619c79bd418a8c2be4c15a7764265f5313d91d3852f8782f49 |
| Seed verification receipt | VERIFIED for the recorded check | sha256:21c8f313a17df16f6efab8b082fb0d2ca8757eecc1d6710071ca5bc25e648043 |

The identities and links are navigable from [versioning/INDEX.json](BAGO5_VSCODE_PROJECT_v0.1/versioning/INDEX.json). The materializer and a full LAE commit runtime have not been implemented in this repository.

## Retrospective timeline

Dates below are taken from the artifacts. Test outcomes are historical evidence from those runs, not reruns performed while writing this timeline.

| Date | Milestone | Recorded result | Evidence / boundary |
|---|---|---|---|
| 2026-10-11 | BPBR v0.1 reference package frozen as first complete motor | Source audit reports 20/20 tests and demo PASS on Linux / Python 3.13.5 | [Freeze record](BAGO5_VSCODE_PROJECT_v0.1/references/frozen/BPBR_v0.1_FREEZE.md), [source audit](BAGO5_VSCODE_PROJECT_v0.1/engines/BPBR_v0.1_REFERENCE/CRIT-BPBR-001.md). Host integration, Windows and independent review were NOT_RUN. |
| 2026-10-11 | BAGO5 VS Code workspace assembled around BPBR and the later sketch | Workspace smoke evidence records BPBR checks and demo plus 8/8 sketch tests on its recorded Linux/Python environment | [Workspace smoke evidence](BAGO5_VSCODE_PROJECT_v0.1/evidence/vscode_workspace_20261011/WORKSPACE_SMOKE_REPORT.json). This environment is distinct from the original frozen audit. |
| 2026-10-11 | Layered versioning records seeded | Root and candidate inventories, root-only snapshot selection, JSON index and content-addressed verification receipt created; verifier returned PASS | [Root](BAGO5_VSCODE_PROJECT_v0.1/versioning/roots/BPBR_V0.1.json), [candidate](BAGO5_VSCODE_PROJECT_v0.1/versioning/candidates/KERNEL_SKETCH_V0.1.json), [snapshot](BAGO5_VSCODE_PROJECT_v0.1/versioning/snapshots/BPBR_V0.1.json), [verification receipt](BAGO5_VSCODE_PROJECT_v0.1/versioning/evidence/21c8f313a17df16f6efab8b082fb0d2ca8757eecc1d6710071ca5bc25e648043.json). No layer resolution occurred. |

## Goals and forward timeline

The dates are the conditional target windows already in the kernel roadmap. Layer-specific work below is a proposed addition to those milestones; schedule fit and acceptance gates must be reviewed before treating it as committed.

| Window | Existing milestone | Layer-versioning goal | Exit evidence |
|---|---|---|---|
| 2026-10-12–16 | v0.1 first-motor baseline | Reproduce baseline and preserve the exact root identity | Tests/demo and reviewer findings bound to the frozen BPBR tree |
| 2026-10-19–30 | v0.2 shared semantics | Specify root/layer/snapshot schemas, parent rules, operation semantics, branches, tombstones and evidence links | Conformance vectors; stale-parent and invalid-payload cases fail closed |
| 2026-11-02–13 | v0.3 registry/composer | Build deterministic delta resolution and content-addressed object reuse | Same root + same layer chain yields byte-identical tree digest; conflicts and missing objects are rejected |
| 2026-11-16–27 | v0.4 authorization/execution boundary | Govern any materializing or committing operation with exact authorization and replay protection | Missing, expired, altered-parent and replay attempts denied before authoritative state changes |
| 2026-11-30–12-11 | v0.5 test station/evidence | Bind snapshot checks and receipts to exact root, layer chain, resolver and fixtures | Stale or mismatched evidence cannot verify a snapshot |
| 2026-12-14–23 | v0.6 persistent store | Persist layer catalog, snapshot selections and evidence references with recovery behavior | Restart/recovery preserves identities; duplicate commits do not fork or corrupt the graph |
| 2027-01-04–15 | v0.7 adaptive growth | Produce and verify multiple useful snapshots from shared root and different layer chains | At least two distinct valid compositions; demonstrate shared unchanged content and correct stale rejection |
| 2027-01-18–29 | v0.8 reference runtime | Add inspect/resolve commands for layer graph and snapshot manifests | Clean local setup reproduces selected snapshots and their receipts |
| 2027-02-01–26 | v0.9 / v0.9.1 | Freeze candidate graph, review threats and correct only evidenced findings | Independent review passes on exact final graph and resolver fingerprint |
| 2027-03-01–05 | v1.0 promotion target | Promote a reproducible snapshot and publish its graph, resolver and evidence index | Root/layers/materialized tree/package all bind to one identity; explicit promotion gate passes |

### Completion criteria for the layered model

1. No version directory contains a full copy of BPBR merely to identify that version.
2. Every sealed layer has a digest-bound intentionality report and names one exact parent digest.
3. Every block declares a primary layer and its reference names the parent reference and ordered layer chain; unknown, stale or reordered parents fail verification.
4. Block layer count is dynamic; only accepted block closure creates the next immutable reference snapshot.
5. Every reference preserves lineage to the original root, and creating one never deletes earlier layers, references or evidence.
6. Repeated resolution of the same parent, layer selection and materializer produces the same effective tree digest.
7. Evidence links to the exact graph and tool fingerprint it verifies.
8. The kernel sketch contributes only reviewed deltas; it remains outside snapshots until those deltas pass their gates.

## Navigation

- [BAGO 5.0 workspace entrypoint](../README.md)
- [Layering contract and verification command](BAGO5_VSCODE_PROJECT_v0.1/versioning/README.md)
- [Current version graph index](BAGO5_VSCODE_PROJECT_v0.1/versioning/INDEX.json)
- [Full kernel delivery timeline](BAGO5_VSCODE_PROJECT_v0.1/roadmap/BAGO5_TIMELINE_TO_1.0_20261011.md)
