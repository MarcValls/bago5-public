# Paquete para auditoría externa — arquitectura BAGO5

**ID:** `BAGO5-EXTERNAL-ARCH-AUDIT-PACK-001`  
**Estado:** PREPARED. Paquete construido e integridad local comprobada; auditoría externa NOT_RUN.

## Objetivo

Determinar, con evidencia reproducible, cuánto se ajusta el estado actual de BAGO5 a la propuesta arquitectónica recibida: núcleo operativo gobernado, capacidades extensibles, interfaces desacopladas, modelos como adaptadores opcionales y ejecución/evidencia bajo control del kernel.

La propuesta adjunta es material de entrada del usuario. **No se presenta como canon aprobado del repositorio.** El auditor debe evaluar también si existe autoridad para adoptarla y qué decisiones siguen pendientes.

## Qué contiene

- `proposal/ARCHITECTURE_PROPOSAL_AS_RECEIVED.txt`: texto adjunto original, preservado como bytes.
- `CANDIDATE_SOURCE_6e823ba.zip`: archivo Git del árbol completo y rastreado de BAGO5 en el commit candidato exacto `6e823ba8c578ec14d15e2540ed6f773ee31a4bac`.
- `evidence/`: registro de brechas, lock de fuentes, revisión de fuentes, ejecuciones fijadas, verificación integrada, documento arquitectónico de layers, relación de commits y metadatos de identidad.
- `SHA256SUMS.txt`: hashes SHA-256 de todos los archivos del paquete salvo este propio fichero.

## Identidades y límites temporales

- **Árbol de código evaluable:** commit `6e823ba8c578ec14d15e2540ed6f773ee31a4bac`, árbol `83302fc68ebb85c63a5e46c9a14910f05fdb2576`.
- **HEAD de evidencia/documentación:** `1fb6197b2160db522c043f343a14828bfe27d303`. El registro de readiness se copió desde este estado y nombra explícitamente el commit candidato. No atribuir sus cambios documentales al árbol candidato.
- **Fuentes usadas por el auditor L0–L4:** commits fijados en `source-lock.json`: BAGO `f3804a7e9333607561d28fd5075569e725aa0bb0`; bago-framework `fc701c8b31ec74427a0cd74c916bacc79bfeb50a`; BAGO_AGENTIC_DATA_LAB `aad3b1ebadcef15122aae9e74b96ca6c944fdd0a`.
- El lock declara hashes Git blob para archivos seleccionados; **no contiene copias completas** de los dos primeros repositorios. La fuente ADL tiene un subconjunto documentado en el lock. La auditoría sobre el auditor debe respetar este límite.
- Se excluyeron los recibos locales no versionados de selección de workflow. El ZIP de código contiene solo el árbol Git rastreado del candidato.

## Preguntas para el auditor independiente

1. Construya una matriz requisito → evidencia exacta (ruta y sección/símbolo) → estado `IMPLEMENTADO`, `PARCIAL`, `PROPUESTO`, `AUSENTE` o `NO_VERIFICABLE`.
2. Separe el producto BAGO5 y el prototipo de kernel del scaffold `bago_repo_audit` L0–L4. ¿Qué artefactos prueban cada afirmación?
3. Evalúe, al menos: identidad/sesiones y contexto; registro/contratos de capacidades; selección y persistencia procedural; autorización ligada a objetivo/efectos; frontera de ejecución; verificación y evidencia; interfaz chat/API/CLI; adaptadores de modelos/OS/APIs; ciclo de vida y compatibilidad.
4. Determine si los invariantes de la propuesta están enforced por código y pruebas, son solo documentación o no aparecen. Busque bypasses relevantes en el alcance entregado y declare el método/límites.
5. Compruebe que las pruebas y recibos se vinculan a los commits correctos. Diferencie resultados históricos, checks de scaffold y cobertura de producto/kernel. No infiera cierre arquitectónico de `READY_FOR_MAIN_REVIEW`.
6. Enumere contradicciones, riesgos, decisiones que requieren aprobación de producto y la secuencia mínima de brechas que permitiría una conclusión mejor.
7. Entregue conclusión ejecutiva: alineación general, capacidades realmente demostradas, confianza acotada, bloqueos y condiciones verificables para afirmar conformidad.

No se solicita cambiar código, ejecutar efectos sobre los orígenes ni promover commits. Cualquier comprobación ejecutable debe ser aislada, de solo lectura sobre el paquete y reportar comandos, entorno, resultado y hash del candidato.

## Estado registrado — no prejuzga la auditoría

En `gap-register.json`, RA-01…RA-13 están `PARTIAL`; INT-01 e INT-02 `VERIFIED` para el candidato fijado. `READY_FOR_MAIN_REVIEW` se limita a integración segura del scaffold read-only L0–L4 como primera versión, no a completitud funcional ni a conformidad con la propuesta adjunta. La revisión de fuentes indica que las adaptaciones permanecen parciales y no `VALIDATED`.

## Verificación de integridad

Desde la carpeta extraída, verificar cada línea de `SHA256SUMS.txt` con `Get-FileHash -Algorithm SHA256` (PowerShell) o `sha256sum -c SHA256SUMS.txt` (Linux/macOS). `IDENTITY.json` contiene además el hash SHA-256 de la propuesta original.
