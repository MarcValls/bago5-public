"""Independent fixture oracle for the bounded evidence-integrity behavior."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import tempfile
import platform
import sys
from typing import Any

from .core import BPBRError, Behavior, FunctionRegistry, digest, run

PROFILE = "BPBR-AUDIT-v1"
ALLOWED = frozenset({"PURE", "READ_LOCAL"})


def _manifest(folder: Path, entries: list[dict[str, str]]) -> dict[str, str]:
    (folder / "manifest.json").write_text(json.dumps({"entries": entries}, sort_keys=True), encoding="utf-8")
    return {"manifest": "manifest.json"}


def _sha(raw: bytes) -> str:
    # Independent expectations: not delegated to runtime compare_hashes.
    return hashlib.sha256(raw).hexdigest()


def conformance(behavior: Behavior, registry: FunctionRegistry) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="bpbr-station-") as tmp:
        root = Path(tmp)
        # Three positive conformance cases with independent expected outcomes.
        for label, variant, expected in [
            ("MATCH_TWO", "match", {"MATCH": 2, "STALE": 0, "MISSING": 0}),
            ("DETECT_STALE", "stale", {"MATCH": 1, "STALE": 1, "MISSING": 0}),
            ("DETECT_MISSING", "missing", {"MATCH": 1, "STALE": 0, "MISSING": 1}),
        ]:
            folder = root / label
            folder.mkdir()
            (folder / "one.txt").write_bytes(b"alpha\n")
            entries = [{"path": "one.txt", "sha256": _sha(b"alpha\n")},
                       {"path": "two.txt", "sha256": _sha(b"beta\n") if variant != "stale" else _sha(b"incorrect\n")}]
            if variant != "missing":
                (folder / "two.txt").write_bytes(b"beta\n")
            request = _manifest(folder, entries)
            try:
                result = run(behavior, registry, request, folder, ALLOWED)
                report = result["output"]
                actual = report["counts"]
                correct = actual == expected and len(report["entries"]) == 2 and len(result["steps"]) == 4
                checks.append({"case": label, "kind": "positive", "pass": correct,
                               "expected": expected, "actual": actual,
                               "request_digest": digest(request), "result_digest": digest(report)})
            except Exception as err:
                checks.append({"case": label, "kind": "positive", "pass": False,
                               "error": f"{type(err).__name__}: {err}"})

        # Negative traversal; must not read any file outside the workspace.
        bad = root / "NEGATIVE_TRAVERSAL"
        bad.mkdir()
        req = _manifest(bad, [{"path": "../one.txt", "sha256": _sha(b"alpha\n")}])
        _expect_block(checks, "DENY_TRAVERSAL", "PATH_DENIED", behavior, registry, req, bad)

        invalid = root / "NEGATIVE_SHA"
        invalid.mkdir()
        req = _manifest(invalid, [{"path": "one.txt", "sha256": "not-a-real-sha"}])
        _expect_block(checks, "DENY_INVALID_SHA", "MANIFEST_INVALID", behavior, registry, req, invalid)

        no_grant = root / "NEGATIVE_GRANT"
        no_grant.mkdir()
        req = _manifest(no_grant, [{"path": "one.txt", "sha256": _sha(b"alpha\n")}])
        _expect_block(checks, "DENY_MISSING_GRANT", "EFFECT_DENIED", behavior, registry, req,
                      no_grant, allowed=frozenset({"PURE"}))

        # Extra negative case; symlink may be unsupported on Windows without privileges.
        symlink_root = root / "NEGATIVE_SYMLINK"
        symlink_root.mkdir()
        link = symlink_root / "alias.txt"
        try:
            link.symlink_to(root / "MATCH_TWO" / "one.txt")
        except (OSError, NotImplementedError):
            checks.append({"case": "DENY_SYMLINK", "kind": "informational", "pass": None,
                           "status": "NOT_RUN_PLATFORM_SYMLINK_UNAVAILABLE"})
        else:
            req = _manifest(symlink_root, [{"path": "alias.txt", "sha256": _sha(b"alpha\n")}])
            _expect_block(checks, "DENY_SYMLINK", "SYMLINK_DENIED", behavior, registry, req, symlink_root)

    positive = sum(1 for check in checks if check["kind"] == "positive" and check["pass"] is True)
    negative = sum(1 for check in checks if check["kind"] == "negative" and check["pass"] is True)
    failures = sum(1 for check in checks if check["kind"] in ("positive", "negative") and check["pass"] is not True)
    return {"profile": PROFILE, "behavior_id": behavior.behavior_id,
            "behavior_definition_sha256": behavior.definition_sha256,
            "positive_pass": positive, "negative_pass": negative, "total_fail": failures,
            "verdict": "PASS" if positive >= 3 and negative >= 3 and failures == 0 else "FAIL",
            "checks": checks, "environment": {"python": sys.version.split()[0],
                                                 "platform": platform.platform(), "runtime": "CPU-only / stdlib"}}


def _expect_block(checks: list[dict[str, Any]], label: str, code: str, behavior: Behavior,
                  registry: FunctionRegistry, request: Any, root: Path,
                  allowed: frozenset[str] = ALLOWED) -> None:
    try:
        run(behavior, registry, request, root, allowed)
    except BPBRError as exc:
        checks.append({"case": label, "kind": "negative", "pass": exc.code == code,
                       "expected_block": code, "actual_block": exc.code})
    except Exception as exc:
        checks.append({"case": label, "kind": "negative", "pass": False,
                       "expected_block": code, "unexpected_error": type(exc).__name__})
    else:
        checks.append({"case": label, "kind": "negative", "pass": False,
                       "expected_block": code, "actual": "WRONGFULLY_ALLOWED"})
