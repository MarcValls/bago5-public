# BAGO Procedural Behavior Runtime — v0.1 REFERENCE

Author: OpenAI / GPT-6 · 2026-10-11

**Purpose:** Demonstrate a bounded, deterministic engine which composes known functions into a new behavior, evaluates it, stores it in SQLite, and later reuses it **after a new Python interpreter starts** without composing again. CPU only. No LLM, GPU, cloud keys or external Python dependencies.

**Scope:** executable standalone reference and conformance harness. **Not connected to live BAGO/ADL**, **not a production effect-authority implementation**, no GitHub changes.

## Run from the extracted package root

Windows (PowerShell, in the directory containing `bpbr/`):

    py -3 -m unittest discover -s tests -v
    py -3 -m bpbr.demo --output .\demo-first-run

If the `py` launcher is unavailable, use `python` instead. Python >=3.11. Run a second demonstration with **another output path**. The demo refuses to overwrite an existing behavior database, preserving previous evidence.

Linux or macOS:

    python -m unittest discover -s tests -v
    python -m bpbr.demo --output ./demo-first-run

Outputs: `acquire.json`, `reuse.json`, `DEMO_EVIDENCE.json`, `behaviors.sqlite3` and independent input workspaces. `DEMO_EVIDENCE.json` records subprocesses, no-composition-on-reuse assertion, suite and resulting behavior identity.

## Files

- `COGNITIVE_INVENTORY_FREEZE.md` — freeze scope and source snapshots.
- `INVENTORY_REUSE_MAP.md` — BAGO/SPBE, Skill Engine, memory and ADL evaluation code inventory.
- `BEHAVIOR_SPEC_v0.1.md` — schema, policies, invariants, evidences.
- `INTEGRATION_PLAN.md` — safe additive host integration path.
- `bpbr/` — bounded reference composer, registry, store, station, demo.
- `tests/` — 20 standalone tests including restart, fingerprints and negative cases.
- `evidence/` — generated test logs, demo receipts and SHA256SUMS.
- `CRIT-BPBR-001.md` — scoped audit verdict and production limitations.

## Operational constraints

- No custom installed packages; no heavyweight embeddings, neural provider, background daemon or graphical UI.
- Default max 5 steps, cost 5 and 32 expansions. One bounded domain fixture: integrity audit of SHA-256 manifests. Manifest max 64 items; individual files <=2 MiB.
- Only two primitive effect classes: `PURE` and `READ_LOCAL`, authorized in the isolated demo by caller flags. **These flags must never be substituted for BAGO's real permit**.
- No auto-generated Python functions. A composed sequence of previously available functions is the acquired behavior.
- `READ_LOCAL` filesystem guard is not certified race-free. Demo fixtures and evaluations are trusted local workspaces only.

## Package installation / change policy

**ADD ONLY.** Do not overwrite existing source. Keep the package independent first. Run the commands above, verify `PASS`, then proceed with the separate `INTEGRATION_PLAN.md` and BAGO preflight. No changes to existing BAGO, ADL, LAE, SPBE, PEC or 03A implementation are included.
