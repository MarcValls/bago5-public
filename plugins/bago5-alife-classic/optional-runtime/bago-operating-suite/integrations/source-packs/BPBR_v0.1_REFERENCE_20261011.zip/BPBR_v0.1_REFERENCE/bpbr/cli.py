"""Two subprocess boundaries: acquire then reuse after independent Python restart."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from .core import BehaviorStore, Goal, compose, run
from .functions import standard_registry
from .station import conformance, ALLOWED

GOAL_KEY = "evidence_integrity_audit"


def execute(phase: str, db_path: Path, workspace: Path, request: dict) -> dict:
    registry = standard_registry()
    if phase == "acquire":
        behavior = compose(Goal(GOAL_KEY, "manifest_request", "audit_report"), registry)
        with BehaviorStore(db_path) as store:
            created = store.register(behavior)
            if not created:
                raise RuntimeError("Demo requires a new database for acquisition proof")
            report = conformance(behavior, registry)
            evidence_id = store.save_evaluation(behavior, report)
            if report["verdict"] != "PASS":
                return {"verdict": "FAIL", "suite": report, "phase": phase}
            store.acquire(behavior.behavior_id, evidence_id, registry)
            actual = run(behavior, registry, request, workspace, ALLOWED)
            episode_id = store.record_episode(behavior, request, actual, reused=False)
            return {"verdict": "PASS", "phase": phase, "behavior_id": behavior.behavior_id,
                    "composed": True, "new_behavior_registered": created, "status": store.get(behavior.behavior_id)[1],
                    "evidence_id": evidence_id, "episode_id": episode_id, "suite": report,
                    "execution": actual, "db_counts": store.counts()}
    if phase == "reuse":
        with BehaviorStore(db_path) as store:
            # This mode never invokes compose(); it can only select an acquired behavior.
            behavior = store.select_acquired(GOAL_KEY, registry)
            actual = run(behavior, registry, request, workspace, ALLOWED)
            episode_id = store.record_episode(behavior, request, actual, reused=True)
            return {"verdict": "PASS", "phase": phase, "behavior_id": behavior.behavior_id,
                    "composed": False, "reused_acquired": True, "episode_id": episode_id,
                    "execution": actual, "db_counts": store.counts()}
    raise ValueError(phase)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--phase", required=True, choices=["acquire", "reuse"])
    p.add_argument("--db", required=True, type=Path)
    p.add_argument("--workspace", required=True, type=Path)
    p.add_argument("--request", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    args = p.parse_args()
    result = execute(args.phase, args.db, args.workspace, json.loads(args.request.read_text(encoding="utf-8")))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"phase": args.phase, "verdict": result["verdict"],
                      "behavior_id": result.get("behavior_id"), "output": str(args.output)}))
    if result["verdict"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
