# BEHAVIOR SPEC v0.1 — CONTRACT / SEMANTICS

- ID: `BPBR-BEHAVIOR-SPEC-v0.1`
- Author: OpenAI / GPT-6
- Status: `REFERENCE_IMPLEMENTED`, **NOT BAGO_CANON**, **NOT HOST_INTEGRATED**.

## Goal

`Goal(key, input_type, output_type, max_steps, max_cost, max_expansions, permitted_effects)`.

Goal is supplied by a trusted caller in v0.1. No arbitrary natural-language task is automatically interpreted here.

## FunctionSpec

`function_id`, `input_type`, `output_type`, `effect`, `cost`, `implementation_sha256`. Function code must be a locally inspectable registered function. `implementation_sha256` covers whole source module and implementation source. FunctionSpec fingerprint binds I/O/effect/identity/cost. Allowed effects: `PURE`, `READ_LOCAL`. The registry rejects unknown effects.

## Behavior

`behavior_id`, `goal_key`, `input_type`, `output_type`, `steps[]`, `step_fingerprints[]`, `cost`, `definition_sha256`.

SHA is over canonical JSON of all fields apart from `behavior_id` and `definition_sha256`; ID is a digest prefix. DB uses immutable candidate identity. A changed function source or contract makes a persisted plan stale. Every step requires the previous output type to match the next input type.

## Bounded composition

A deterministic breadth-first search explores candidate function chains, sorted by function ID. Hard bounds: step count, total declared cost, number of expansions; no function can appear twice in the same chain. It is a **bounded feasible-chain planner**, not a globally optimal cost optimizer. No candidate function is executed during search. It does not invent primitives or perform generalized type unification.

## Execution (demo only)

Verify behavior definition digest and **all** dependency fingerprints before dispatch. Verify budget and full-plan effect allowlist before the first operation. Then run four allowlisted pure/local-read functions. For each step, store the function fingerprint and input/output SHA. All file input must remain in the explicit workspace sandbox. No shell, networking, arbitrary Python code execution, or file mutation is present in the shipped primitive catalog.

Runtime security caveat: pure Python path checking is not a complete defense against hostile concurrent filesystem races, hardlink attacks, or compromised process privileges. Source is provided for local controlled tests, not adversarial production file access.

## States

`CANDIDATE -> ACQUIRED -> SUSPENDED`. Also reserved: `RETIRED` (not wired to public transition in v0.1). Internal test report does not introduce separate persisted `TESTED` state: evaluations live in a separate table, and the only promotion implemented is CANDIDATE -> ACQUIRED on a passing suite. Reverse transitions are not implicit. Corrections produce a new SHA and candidate identity.

## Evidence thresholds

`BPBR-AUDIT-v1`: at least three positive, three negative, zero failing mandatory cases, with exact profile tag. Four negative cases possible on Unix; symlink case is NOT_RUN if Windows lacks privilege. Suites are stored in SQLite with receipt IDs. Promotion re-executes the station and compares the complete deterministic report, refusing fabricated or non-reproducible PASS claims. **Do not treat this as signed attestation; DB and Python caller are inside the same trust domain.** An untrusted caller capable of editing the DB or calling arbitrary Python is outside this reference security model.

## Conformance

- Positive: exact match; stale hash; missing file.
- Negative: traversal rejected; invalid SHA rejected; missing effect grant rejected; symlink rejected when testable.
- Lifecycle: candidate cannot be selected, insufficient evidence cannot promote, suspension prevents selection.
- Binding: changed dependency, changed behavior definition, or invalid composed chain fail closed.
- Restart: subprocess A composes/acquires; subprocess B reopens SQLite, **does not compose**, and reuses on a distinct test case.

## Required proof to claim production integrated

Authenticated effect gate and proof of permit binding, hostile path access and TOCTOU hardening, independently authenticated test evidence, conflict/concurrency replay, environmental reproducibility on Windows, correct stale behavior handling without losing alternative candidates, real SPBE and ADL adapter contract tests.
