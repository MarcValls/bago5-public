# BAGO / ADL INVENTORY AND REUSE MAP

Author: OpenAI / GPT-6 — 2026-10-11

| Existing piece | Verified code surface | Intent / behavior represented | Integration decision |
|---|---|---|---|
| SPBE | `BAGO/backend/.bago/core/bago_spbe/{engine,pipeline,ports,eligibility}.py` | Ports for semantic interpretation/normalization/discovery/binding; deterministic eligibility, capability resolution, cycle checks; outputs proposal or terminal, no material authorization | **ADAPT via host adapter later.** BPBR v0.1 uses equivalent no-effect separation, but does not import SPBE. |
| Historic Skill Engine | `BAGO/backend/.bago/tools/skill_engine.py` | Twelve-phase procedure, per-skill episode and gradient JSON, `run_skill` writes skill state | **REFERENCE ONLY**. It models skill episodes, not typed function composition. No runtime coupling in this package. |
| LearningWriter | `BAGO/backend/.bago/core/learning_writer.py` | Append observations; pattern threshold 3; planner context | **REFERENCE ONLY**. Repeated success isn't independent conformance evidence; no direct import. |
| Context Governance | `BAGO/backend/.bago/core/context_governance.py` | Classifier, ContextPlanner, ContextRanker, ContradictionDetector, ClaimVerifier, CanonCache | **FUTURE ADAPTER** for natural-language goal to typed Goal; reference demo takes fixed typed Goal. |
| Context Envelope / receipts | `BAGO/backend/.bago/core/context_envelope.py` | immutable context fragments, authority/freshness metadata, receipts | **FUTURE ADAPTER** to host envelope and evidence ledger; BPBR uses local digest receipts only. |
| Governed Work Pipeline 04-FIX2 | `BAGO/backend/.bago/core/governed_work_pipeline.py` | Budgets, stable workflow/step fingerprints, checkpoints, idempotence; scope `EXECUTED/CONNECTED_SCOPED`, full promotion pending | **DO NOT SUBSTITUTE.** For actual BAGO effects the host must pass through 03A + ExecutionGateway. |
| ADL Agent Evaluation Lab | `BAGO_AGENTIC_DATA_LAB/src/evaluation/agent_lab.py` | versioned suite persistence, deterministic assertions on agent responses, bounded previews | **DESIGN REUSE**, no direct import; BPBR has independent file-hash oracle for procedure outcomes, not natural language answer grading. |
| ADL governed execution | `BAGO_AGENTIC_DATA_LAB/src/orchestration/{state_graph,governed_execution}.py` | proposal/authorization/execute/verify separation, LangGraph graph | **FUTURE HOST BINDING**; no live ADL execution in reference. |
| Governed RAG | `BAGO_AGENTIC_DATA_LAB/src/retrieval/governed_rag.py` | hybrid retrieval with metadata/authority gates | **FUTURE DISCOVERY** for behavior retrieval at scale; initially SQLite exact goal key is sufficient. |
| Genesis/LAE/BCEP efforts | historical contracts and discussions | immutable identity, provenance, test station evidence binding | **NOT CLAIMED CONNECTED**. Candidate digest and local receipts are only a small subset. |

Repo URLs:
- https://github.com/MarcValls/BAGO/tree/main/backend/.bago/core/bago_spbe
- https://github.com/MarcValls/BAGO/blob/main/backend/.bago/tools/skill_engine.py
- https://github.com/MarcValls/BAGO/blob/main/backend/.bago/core/learning_writer.py
- https://github.com/MarcValls/BAGO/blob/main/backend/.bago/core/governed_work_pipeline.py
- https://github.com/MarcValls/BAGO_AGENTIC_DATA_LAB/blob/main/src/evaluation/agent_lab.py

## Essential owner boundary

`Interpretation -> eligibility/composition -> test proposal -> authorization -> material effects -> outcome/evidence -> behavior lifecycle`.

BPBR does not issue a real BAGO Permit. The local `READ_LOCAL` permission is an **explicit sandbox flag**, not an AuthorizationBoundary substitute. A production adapter MUST NOT equate them.

## Minimal future adapter interface

1. `HostGoalAdapter`: `ReflexiveQuestionRecord`/`ContextEnvelope` → BPBR typed goal; keep intent-root and source fingerprints.
2. `HostCapabilityAdapter`: BAGO/SPBE `CapabilityCandidate` → typed FunctionSpec; discover only callable known adapters with exact effect ownership.
3. `HostPlanAdapter`: BPBR candidate steps → SPBE/PEC proposal, then host challenge/Permit/ExecutionGateway; do not execute the Python registry directly for material effects.
4. `HostEvidenceAdapter`: map evaluated cases and environment receipts to BCEP/Genesis when ready; verify freshness after any dependency change.
5. `HostLearningAdapter`: ingest results as *episodes*, promoting only via independent evidence policy, never via three successes alone.

No adapter above is implemented or verified in this bundle.
