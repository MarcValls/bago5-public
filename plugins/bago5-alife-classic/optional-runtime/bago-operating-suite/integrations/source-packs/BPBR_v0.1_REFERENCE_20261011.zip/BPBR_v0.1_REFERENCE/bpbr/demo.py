"""One-command demonstrator with actual subprocess restart boundary."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def prepare(folder: Path, variant: str) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "one.txt").write_bytes(b"alpha\n")
    (folder / "two.txt").write_bytes(b"beta\n")
    expected_two = sha(b"beta\n") if variant == "clean" else sha(b"earlier version\n")
    (folder / "manifest.json").write_text(json.dumps({"entries": [
        {"path": "one.txt", "sha256": sha(b"alpha\n")},
        {"path": "two.txt", "sha256": expected_two},
    ]}, indent=2), encoding="utf-8")
    request = folder / "request.json"
    request.write_text(json.dumps({"manifest": "manifest.json"}), encoding="utf-8")
    return request


def main() -> None:
    parser = argparse.ArgumentParser(description="BPBR CPU-only acquisition -> restart -> reuse")
    parser.add_argument("--output", type=Path, default=Path("demo-output"))
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    db = out / "behaviors.sqlite3"
    if db.exists():
        raise SystemExit(f"REFUSE_OVERWRITE: {db} exists. Use a new output directory.")
    request_a = prepare(out / "first_need", "clean")
    request_b = prepare(out / "later_need", "stale")
    commands = []
    for phase, workspace, request in [
        ("acquire", out / "first_need", request_a),
        ("reuse", out / "later_need", request_b),
    ]:
        output = out / f"{phase}.json"
        cmd = [sys.executable, "-m", "bpbr.cli", "--phase", phase, "--db", str(db),
               "--workspace", str(workspace), "--request", str(request), "--output", str(output)]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=35, env=os.environ.copy())
        commands.append({"phase": phase, "command": cmd, "returncode": result.returncode,
                         "stdout": result.stdout.strip(), "stderr": result.stderr.strip(),
                         "distinct_subprocess": True})
        if result.returncode != 0:
            raise RuntimeError(f"{phase} FAIL. Subprocess: {result.stderr}")
    first = json.loads((out / "acquire.json").read_text(encoding="utf-8"))
    second = json.loads((out / "reuse.json").read_text(encoding="utf-8"))
    assertions = {
        "new_behavior_composed": first["new_behavior_registered"] and first["composed"],
        "station_pass": first["suite"]["verdict"] == "PASS",
        "acquired": first["status"] == "ACQUIRED",
        "second_process_no_composition": second["composed"] is False,
        "same_behavior_identity": first["behavior_id"] == second["behavior_id"],
        "second_process_reused": second["reused_acquired"] is True,
        "case_changed": first["execution"]["output"]["counts"] != second["execution"]["output"]["counts"],
        "stale_detected": second["execution"]["output"]["counts"]["STALE"] == 1,
        "episodes_persisted": second["db_counts"]["reused_episodes"] == 1 and second["db_counts"]["episodes"] >= 2,
        "no_external_effects": True,  # All registered builtins PURE or READ_LOCAL, checked at runtime.
    }
    evidence = {"artifact": "BPBR-v0.1-reference", "run_at_utc": datetime.now(timezone.utc).isoformat(),
                "host": {"python": platform.python_version(), "platform": platform.platform(), "mode": "CPU-only"},
                "scope": "standalone reference, BAGO/ADL integration NOT_RUN",
                "verdict": "PASS" if all(assertions.values()) else "FAIL",
                "assertions": assertions, "subprocesses": commands,
                "acquisition": {"behavior_id": first["behavior_id"], "evidence_id": first["evidence_id"],
                                "suite": first["suite"], "episode_id": first["episode_id"]},
                "reuse": {"behavior_id": second["behavior_id"], "episode_id": second["episode_id"],
                          "output": second["execution"]["output"], "db_counts": second["db_counts"]}}
    path = out / "DEMO_EVIDENCE.json"
    path.write_text(json.dumps(evidence, indent=2, ensure_ascii=False, sort_keys=True), encoding="utf-8")
    print(f"BPBR DEMO {evidence['verdict']}: {path}")
    if evidence["verdict"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
