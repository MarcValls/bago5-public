@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
%PY% -m unittest discover -s tests -v
if errorlevel 1 exit /b 1
if "%~1"=="" (
  echo Provide a NEW output directory, e.g. RUN_WINDOWS.cmd demo-run-001
  exit /b 2
)
%PY% -m bpbr.demo --output "%~1"
exit /b %errorlevel%
