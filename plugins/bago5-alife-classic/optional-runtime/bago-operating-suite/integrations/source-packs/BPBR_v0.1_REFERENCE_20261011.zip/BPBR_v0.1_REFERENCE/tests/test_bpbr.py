"""No third party dependencies, no external provider calls."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from bpbr.core import BPBRError, Behavior, BehaviorStore, FunctionRegistry, Goal, compose, digest, run, verify_binding
from bpbr.functions import standard_registry
from bpbr.station import ALLOWED, conformance


def h(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fixture(root: Path, stale: bool = False) -> dict:
    (root / "file.txt").write_bytes(b"contents\n")
    (root / "manifest.json").write_text(json.dumps({"entries": [{
        "path": "file.txt", "sha256": h(b"WRONG" if stale else b"contents\n")
    }]}), encoding="utf-8")
    return {"manifest": "manifest.json"}


class BPBRTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="bpbr-unit-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.registry = standard_registry()
        self.goal = Goal("evidence_integrity_audit", "manifest_request", "audit_report")
        self.behavior = compose(self.goal, self.registry)

    def test_composer_uses_exact_compatible_chain(self):
        self.assertEqual(self.behavior.steps, ("parse_manifest", "hash_files", "compare_hashes", "render_report"))
        self.assertEqual(self.behavior.cost, 4)
        self.assertEqual(self.behavior.behavior_id, compose(self.goal, standard_registry()).behavior_id)

    def test_different_semantics_fail_closed(self):
        with self.assertRaises(BPBRError) as caught:
            compose(Goal("unknown", "text", "audit_report"), self.registry)
        self.assertEqual(caught.exception.code, "NO_ELIGIBLE_COMPOSITION")

    def test_planning_budget(self):
        with self.assertRaises(BPBRError) as caught:
            compose(Goal("short", "manifest_request", "audit_report", max_steps=3), self.registry)
        self.assertEqual(caught.exception.code, "NO_ELIGIBLE_COMPOSITION")
        with self.assertRaises(BPBRError) as caught:
            compose(Goal("short", "manifest_request", "audit_report", max_cost=2), self.registry)
        self.assertEqual(caught.exception.code, "NO_ELIGIBLE_COMPOSITION")

    def test_search_budget(self):
        with self.assertRaises(BPBRError) as caught:
            compose(Goal("budget", "manifest_request", "audit_report", max_expansions=2), self.registry)
        self.assertEqual(caught.exception.code, "SEARCH_BUDGET_EXHAUSTED")

    def test_run_exact_result_and_four_receipts(self):
        req = fixture(self.root, stale=True)
        result = run(self.behavior, self.registry, req, self.root, ALLOWED)
        self.assertEqual(result["output"]["counts"], {"MATCH": 0, "STALE": 1, "MISSING": 0})
        self.assertEqual(len(result["steps"]), 4)
        self.assertTrue(all(len(x["input_sha256"]) == 64 for x in result["steps"]))

    def test_missing_grant_denied_pre_dispatch(self):
        req = fixture(self.root)
        with self.assertRaises(BPBRError) as caught:
            run(self.behavior, self.registry, req, self.root, frozenset({"PURE"}))
        self.assertEqual(caught.exception.code, "EFFECT_DENIED")

    def test_run_budget(self):
        req = fixture(self.root)
        with self.assertRaises(BPBRError) as caught:
            run(self.behavior, self.registry, req, self.root, ALLOWED, max_steps=2)
        self.assertEqual(caught.exception.code, "RUN_BUDGET_EXHAUSTED")

    def test_definition_tamper_denied(self):
        from dataclasses import replace
        bad = replace(self.behavior, output_type="arbitrary")
        with self.assertRaises(BPBRError) as caught:
            verify_binding(bad, self.registry)
        self.assertEqual(caught.exception.code, "BEHAVIOR_TAMPERED")

    def test_changed_implementation_cannot_reuse_old_behavior(self):
        def fake_hash_files(payload, workspace):
            return {"entries": []}
        broken = standard_registry()
        broken.entries.pop("hash_files")
        broken.register("hash_files", "manifest_entries", "hashed_entries", "READ_LOCAL", fake_hash_files)
        with self.assertRaises(BPBRError) as caught:
            verify_binding(self.behavior, broken)
        self.assertEqual(caught.exception.code, "DEPENDENCY_STALE")

    def test_runtime_disallows_arbitrary_effect_registration(self):
        with self.assertRaises(BPBRError) as caught:
            self.registry.register("evil", "x", "y", "SHELL", lambda x, y: x)
        self.assertEqual(caught.exception.code, "EFFECT_UNSUPPORTED")

    def test_negative_cases_and_independent_oracle(self):
        report = conformance(self.behavior, self.registry)
        self.assertEqual(report["verdict"], "PASS")
        self.assertEqual(report["positive_pass"], 3)
        self.assertGreaterEqual(report["negative_pass"], 3)
        self.assertEqual(report["total_fail"], 0)

    def test_unproven_candidate_cannot_acquire(self):
        with BehaviorStore(self.root / "data.sqlite") as db:
            db.register(self.behavior)
            with self.assertRaises(BPBRError) as caught:
                db.acquire(self.behavior.behavior_id, "EVID-false", self.registry)
            self.assertEqual(caught.exception.code, "EVIDENCE_MISSING")
            with self.assertRaises(BPBRError) as caught:
                db.select_acquired(self.goal.key, self.registry)
            self.assertEqual(caught.exception.code, "NO_ACQUIRED_BEHAVIOR")

    def test_failed_suite_cannot_promote(self):
        with BehaviorStore(self.root / "data.sqlite") as db:
            db.register(self.behavior)
            eid = db.save_evaluation(self.behavior, {
                "profile": "BPBR-AUDIT-v1", "verdict": "FAIL", "positive_pass": 3,
                "negative_pass": 2, "total_fail": 1, "behavior_id": self.behavior.behavior_id,
                "behavior_definition_sha256": self.behavior.definition_sha256})
            with self.assertRaises(BPBRError) as caught:
                db.acquire(self.behavior.behavior_id, eid, self.registry)
            self.assertEqual(caught.exception.code, "EVIDENCE_INSUFFICIENT")

    def test_forged_pass_report_rejected_on_replay(self):
        with BehaviorStore(self.root / "data.sqlite") as db:
            db.register(self.behavior)
            forged = {"profile": "BPBR-AUDIT-v1", "verdict": "PASS", "positive_pass": 3,
                      "negative_pass": 3, "total_fail": 0, "behavior_id": self.behavior.behavior_id,
                      "behavior_definition_sha256": self.behavior.definition_sha256, "checks": []}
            eid = db.save_evaluation(self.behavior, forged)
            with self.assertRaises(BPBRError) as caught:
                db.acquire(self.behavior.behavior_id, eid, self.registry)
            self.assertEqual(caught.exception.code, "EVIDENCE_REPLAY_MISMATCH")
            self.assertEqual(db.get(self.behavior.behavior_id)[1], "CANDIDATE")

    def test_wrong_behavior_binding_report_denied(self):
        with BehaviorStore(self.root / "data.sqlite") as db:
            db.register(self.behavior)
            report = conformance(self.behavior, self.registry)
            report["behavior_id"] = "BPBR-fraud"
            with self.assertRaises(BPBRError) as caught:
                db.save_evaluation(self.behavior, report)
            self.assertEqual(caught.exception.code, "EVIDENCE_BINDING_INVALID")

    def test_positive_suite_promotes_and_suspension_denies_reuse(self):
        path = self.root / "data.sqlite"
        with BehaviorStore(path) as db:
            db.register(self.behavior)
            eid = db.save_evaluation(self.behavior, conformance(self.behavior, self.registry))
            db.acquire(self.behavior.behavior_id, eid, self.registry)
            self.assertEqual(db.select_acquired(self.goal.key, self.registry).behavior_id, self.behavior.behavior_id)
        with BehaviorStore(path) as db:
            self.assertEqual(db.select_acquired(self.goal.key, self.registry).behavior_id, self.behavior.behavior_id)
            db.suspend(self.behavior.behavior_id)
            with self.assertRaises(BPBRError) as caught:
                db.select_acquired(self.goal.key, self.registry)
            self.assertEqual(caught.exception.code, "NO_ACQUIRED_BEHAVIOR")

    def test_collision_does_not_overwrite(self):
        from dataclasses import replace
        with BehaviorStore(self.root / "data.sqlite") as db:
            db.register(self.behavior)
            with self.assertRaises(BPBRError) as caught:
                db.register(replace(self.behavior, output_type="different"))
            self.assertEqual(caught.exception.code, "IDENTITY_COLLISION")

    def test_symlink_and_traversal_guards(self):
        from bpbr.functions import safe_file
        with self.assertRaises(BPBRError) as caught:
            safe_file(self.root, "../outside.txt")
        self.assertEqual(caught.exception.code, "PATH_DENIED")
        (self.root / "outside.txt").write_bytes(b"known")
        try:
            (self.root / "link.txt").symlink_to(self.root / "outside.txt")
        except (OSError, NotImplementedError):
            self.skipTest("Symlink creation is prohibited on this platform")
        with self.assertRaises(BPBRError) as caught:
            safe_file(self.root, "link.txt")
        self.assertEqual(caught.exception.code, "SYMLINK_DENIED")

    def test_repeated_identical_run_is_two_distinct_episodes(self):
        req = fixture(self.root)
        result = run(self.behavior, self.registry, req, self.root, ALLOWED)
        with BehaviorStore(self.root / "episodes.sqlite") as db:
            db.register(self.behavior)
            a = db.record_episode(self.behavior, req, result, reused=False)
            b = db.record_episode(self.behavior, req, result, reused=False)
            self.assertNotEqual(a, b)
            self.assertEqual(db.counts()["episodes"], 2)

    def test_subprocess_reuse_after_restart(self):
        output = self.root / "out"
        cmd = [sys.executable, "-m", "bpbr.demo", "--output", str(output)]
        complete = subprocess.run(cmd, text=True, capture_output=True, timeout=40)
        self.assertEqual(complete.returncode, 0, complete.stderr)
        report = json.loads((output / "DEMO_EVIDENCE.json").read_text(encoding="utf-8"))
        self.assertEqual(report["verdict"], "PASS")
        self.assertEqual(report["reuse"]["db_counts"]["reused_episodes"], 1)
        self.assertEqual(len(report["subprocesses"]), 2)
        self.assertTrue(all(item["returncode"] == 0 for item in report["subprocesses"]))
        with self.assertRaises(BPBRError) as caught:
            with BehaviorStore(output / "behaviors.sqlite3") as db:
                db.acquire(report["acquisition"]["behavior_id"], report["acquisition"]["evidence_id"], self.registry)
        self.assertEqual(caught.exception.code, "PROMOTION_FORBIDDEN")


if __name__ == "__main__":
    unittest.main()
