# BAGO HOST INTEGRATION — ADDITIVE PLAN / NO-GO UNTIL VERIFIED

Source: read-only BAGO/ADL inventories. No tracked files were changed on GitHub.

## Proposed installation, after local repo preflight

**ADD**, without overwriting existing BAGO runtime:

- `backend/bago_core/behavior_runtime/{catalog.py,matcher.py,composer.py,conformance.py,host_adapter.py}` (derive from this reference; not a blind copy).
- `backend/tests/test_behavior_runtime_*.py` (translate sandbox tests into host-bound tests).
- `.bago/docs/contracts/BPBR_BEHAVIOR_SPEC_v0.1.md` as review proposal only, not CANON.

**DO NOT REPLACE**: `bago_spbe`, `execution_gateway`, `authorization_boundary`, `governed_work_pipeline`, `learning_writer` or ADL evaluation module.

## Incremental gates

1. **FREEZE** exact BAGO HEAD, selected branch, version, state_root and workspace_root; reject dirty/unverified authority if material effects are involved.
2. **SPBE bridge**: map semantic task and candidate capability refs to typed BPBR composition without widening eligibility; explicitly reject UNKNOWN, TERMINAL or unsupported capabilities.
3. **BAGO execution gate**: do not use BPBR's local sandbox effect list as authority. For every material step use the existing 03A/ExecutionGateway with exact operation/target, binding, permit and receipt. Keep BPBR composer effect-free.
4. **Memory**: bind acquired behavior identity to evidence, source module/contract digest and runtime environment; retain episodes as observations, not immediately trusted rules.
5. **ADL test station**: register/execute repeatable test profiles with model/source/fixture/environment provenance and independent verification receipts.
6. **Regression**: paths/symlinks, stale dependency, changed model/provider, replay, idempotence, concurrency and denied grants. Windows PowerShell 7/NTFS mandatory.
7. **CRIT independent**: P0=0/P1=0 before declaring host integration GO. No merges/releases until user approval and separate verification.

## Why no silent integration

GitHub repo is only accessible through the connector here; source is read-only inspected. Container cannot clone it (no GitHub DNS). This package can be executed and verified independently, but the real BAGO/ADL API/runtime was **NOT_RUN**. Evidence limited to this package must not be represented as evidence of the upstream program.
