"""BPBR v0.1: bounded, CPU-only, read-only procedural acquisition reference.

Standalone conformance harness: NOT a connected BAGO authority provider.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import hashlib
import inspect
import json
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
from uuid import uuid4
from typing import Any, Callable


class BPBRError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def canonical(data: Any) -> str:
    return json.dumps(data, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def digest(data: Any) -> str:
    return hashlib.sha256(canonical(data).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class FunctionSpec:
    function_id: str
    input_type: str
    output_type: str
    effect: str
    implementation_sha256: str
    cost: int = 1

    def payload(self) -> dict[str, Any]:
        return vars(self).copy()

    @property
    def fingerprint(self) -> str:
        return digest(self.payload())


class FunctionRegistry:
    def __init__(self) -> None:
        self.entries: dict[str, tuple[FunctionSpec, Callable[[Any, Path], Any]]] = {}

    def register(self, function_id: str, input_type: str, output_type: str,
                 effect: str, implementation: Callable[[Any, Path], Any], cost: int = 1) -> None:
        if function_id in self.entries or not callable(implementation) or cost < 1:
            raise BPBRError("REGISTRY_INVALID", "Duplicate, non-callable or invalid-cost function")
        if effect not in {"PURE", "READ_LOCAL"}:
            raise BPBRError("EFFECT_UNSUPPORTED", "Only PURE and READ_LOCAL functions are available")
        try:
            source = inspect.getsource(implementation)
        except (OSError, TypeError) as exc:
            raise BPBRError("IMPLEMENTATION_UNVERIFIABLE", str(exc)) from exc
        source_file = inspect.getsourcefile(implementation)
        if not source_file or not Path(source_file).is_file():
            raise BPBRError("IMPLEMENTATION_UNVERIFIABLE", "Implementation must be backed by a local source file")
        # Bind the implementation and its module-local helpers/constants, not just
        # the function body. Changing path guards must stale dependent behavior.
        implementation_digest = hashlib.sha256(
            Path(source_file).read_bytes() + b"\x00" + source.encode("utf-8")
        ).hexdigest()
        spec = FunctionSpec(function_id, input_type, output_type, effect,
                            implementation_digest, cost)
        self.entries[function_id] = spec, implementation

    def spec(self, function_id: str) -> FunctionSpec:
        if function_id not in self.entries:
            raise BPBRError("FUNCTION_UNAVAILABLE", function_id)
        return self.entries[function_id][0]

    def execute(self, function_id: str, data: Any, workspace_root: Path,
                allowed_effects: frozenset[str]) -> Any:
        spec, func = self.entries[function_id]
        if spec.effect not in allowed_effects:
            raise BPBRError("EFFECT_DENIED", f"Missing grant for {spec.effect}")
        return func(data, workspace_root)


@dataclass(frozen=True)
class Goal:
    key: str
    input_type: str
    output_type: str
    max_steps: int = 5
    max_cost: int = 5
    max_expansions: int = 32
    permitted_effects: frozenset[str] = frozenset({"PURE", "READ_LOCAL"})


@dataclass(frozen=True)
class Behavior:
    behavior_id: str
    goal_key: str
    input_type: str
    output_type: str
    steps: tuple[str, ...]
    step_fingerprints: tuple[str, ...]
    cost: int
    definition_sha256: str

    def payload(self) -> dict[str, Any]:
        return {
            "behavior_id": self.behavior_id, "goal_key": self.goal_key,
            "input_type": self.input_type, "output_type": self.output_type,
            "steps": list(self.steps), "step_fingerprints": list(self.step_fingerprints),
            "cost": self.cost, "definition_sha256": self.definition_sha256,
        }

    @classmethod
    def from_payload(cls, raw: dict[str, Any]) -> "Behavior":
        return cls(raw["behavior_id"], raw["goal_key"], raw["input_type"], raw["output_type"],
                   tuple(raw["steps"]), tuple(raw["step_fingerprints"]), raw["cost"], raw["definition_sha256"])


def compose(goal: Goal, registry: FunctionRegistry) -> Behavior:
    """Deterministic bounded breadth-first search; never executes candidates."""
    if goal.max_steps < 1 or goal.max_cost < 1 or goal.max_expansions < 1:
        raise BPBRError("BUDGET_INVALID", "Budgets must be positive")
    if goal.input_type == goal.output_type:
        raise BPBRError("IDENTITY_GOAL_UNSUPPORTED", "Explicit functions are required")
    queue = deque([(goal.input_type, (), 0)])
    expansions = 0
    while queue:
        current, selected, total_cost = queue.popleft()
        if len(selected) >= goal.max_steps:
            continue
        for name in sorted(registry.entries):
            spec = registry.spec(name)
            if spec.input_type != current or spec.effect not in goal.permitted_effects or name in selected:
                continue
            next_cost = total_cost + spec.cost
            if next_cost > goal.max_cost:
                continue
            expansions += 1
            if expansions > goal.max_expansions:
                raise BPBRError("SEARCH_BUDGET_EXHAUSTED", "Exceeded expansion budget")
            steps = (*selected, name)
            if spec.output_type == goal.output_type:
                bindings = tuple(registry.spec(step).fingerprint for step in steps)
                definition = {
                    "goal_key": goal.key, "input_type": goal.input_type,
                    "output_type": goal.output_type, "steps": steps,
                    "step_fingerprints": bindings, "cost": next_cost,
                }
                sha = digest(definition)
                return Behavior(f"BPBR-{sha[:20]}", goal.key, goal.input_type,
                                goal.output_type, steps, bindings, next_cost, sha)
            queue.append((spec.output_type, steps, next_cost))
    raise BPBRError("NO_ELIGIBLE_COMPOSITION", "No compatible bounded chain")


def verify_binding(behavior: Behavior, registry: FunctionRegistry) -> None:
    definition = {
        "goal_key": behavior.goal_key, "input_type": behavior.input_type,
        "output_type": behavior.output_type, "steps": behavior.steps,
        "step_fingerprints": behavior.step_fingerprints, "cost": behavior.cost,
    }
    if digest(definition) != behavior.definition_sha256 or behavior.behavior_id != "BPBR-" + behavior.definition_sha256[:20]:
        raise BPBRError("BEHAVIOR_TAMPERED", "Behavior definition digest differs")
    current = behavior.input_type
    cost = 0
    if not behavior.steps or len(behavior.steps) != len(behavior.step_fingerprints):
        raise BPBRError("BEHAVIOR_INVALID", "Missing or mismatched steps")
    for name, expected_sha in zip(behavior.steps, behavior.step_fingerprints):
        spec = registry.spec(name)
        if spec.fingerprint != expected_sha:
            raise BPBRError("DEPENDENCY_STALE", f"Function changed: {name}")
        if spec.input_type != current:
            raise BPBRError("CHAIN_INVALID", f"Incompatible step: {name}")
        current = spec.output_type
        cost += spec.cost
    if current != behavior.output_type or cost != behavior.cost:
        raise BPBRError("CHAIN_INVALID", "Output or cost mismatch")


def run(behavior: Behavior, registry: FunctionRegistry, request: Any, workspace_root: Path,
        allowed_effects: frozenset[str], *, max_steps: int = 5, max_cost: int = 5) -> dict[str, Any]:
    verify_binding(behavior, registry)
    if len(behavior.steps) > max_steps or behavior.cost > max_cost:
        raise BPBRError("RUN_BUDGET_EXHAUSTED", "Behavior exceeds execution budget")
    # Whole-plan policy preflight before invoking even a PURE step.
    denied = [name for name in behavior.steps if registry.spec(name).effect not in allowed_effects]
    if denied:
        raise BPBRError("EFFECT_DENIED", "Plan contains an unauthorized effect")
    current = request
    receipts: list[dict[str, Any]] = []
    for name in behavior.steps:
        before = digest(current)
        current = registry.execute(name, current, Path(workspace_root), allowed_effects)
        receipts.append({"function_id": name, "input_sha256": before,
                         "output_sha256": digest(current),
                         "function_fingerprint": registry.spec(name).fingerprint})
    return {"output": current, "steps": receipts, "behavior_id": behavior.behavior_id}


class BehaviorStore:
    """SQLite persistence with explicit CANDIDATE -> ACQUIRED transition."""
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.path))
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA busy_timeout=3000")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS behavior (
          behavior_id TEXT PRIMARY KEY, goal_key TEXT NOT NULL,
          payload TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('CANDIDATE','ACQUIRED','SUSPENDED','RETIRED')),
          evidence_id TEXT
        );
        CREATE TABLE IF NOT EXISTS evaluations (
          evidence_id TEXT PRIMARY KEY, behavior_id TEXT NOT NULL,
          profile TEXT NOT NULL, result TEXT NOT NULL, payload TEXT NOT NULL,
          FOREIGN KEY(behavior_id) REFERENCES behavior(behavior_id)
        );
        CREATE TABLE IF NOT EXISTS episodes (
          episode_id TEXT PRIMARY KEY, behavior_id TEXT NOT NULL,
          recorded_at TEXT NOT NULL, request_sha256 TEXT NOT NULL, output_sha256 TEXT NOT NULL,
          reused INTEGER NOT NULL CHECK(reused IN (0,1)), receipts TEXT NOT NULL
        );
        """)
        self.db.commit()

    def close(self) -> None:
        self.db.close()

    def __enter__(self) -> "BehaviorStore":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def register(self, behavior: Behavior) -> bool:
        raw = canonical(behavior.payload())
        old = self.db.execute("SELECT payload FROM behavior WHERE behavior_id=?", (behavior.behavior_id,)).fetchone()
        if old:
            if old["payload"] != raw:
                raise BPBRError("IDENTITY_COLLISION", "ID cannot be silently redefined")
            return False
        with self.db:
            self.db.execute("INSERT INTO behavior VALUES(?,?,?,?,?)",
                            (behavior.behavior_id, behavior.goal_key, raw, "CANDIDATE", None))
        return True

    def get(self, behavior_id: str) -> tuple[Behavior, str]:
        row = self.db.execute("SELECT payload,status FROM behavior WHERE behavior_id=?", (behavior_id,)).fetchone()
        if not row:
            raise BPBRError("BEHAVIOR_NOT_FOUND", behavior_id)
        return Behavior.from_payload(json.loads(row["payload"])), row["status"]

    def save_evaluation(self, behavior: Behavior, report: dict[str, Any]) -> str:
        self.get(behavior.behavior_id)
        if report.get("behavior_id") != behavior.behavior_id or report.get("behavior_definition_sha256") != behavior.definition_sha256:
            raise BPBRError("EVIDENCE_BINDING_INVALID", "Report does not bind the exact behavior")
        evidence_id = "EVID-" + digest(report)[:24]
        with self.db:
            self.db.execute("INSERT OR IGNORE INTO evaluations VALUES (?,?,?,?,?)",
                            (evidence_id, behavior.behavior_id, report["profile"], report["verdict"], canonical(report)))
        return evidence_id

    def acquire(self, behavior_id: str, evidence_id: str, registry: FunctionRegistry) -> None:
        behavior, current_status = self.get(behavior_id)
        verify_binding(behavior, registry)
        if current_status != "CANDIDATE":
            raise BPBRError("PROMOTION_FORBIDDEN", "Only CANDIDATE can be acquired")
        row = self.db.execute("SELECT result,payload,behavior_id,profile FROM evaluations WHERE evidence_id=?", (evidence_id,)).fetchone()
        if not row:
            raise BPBRError("EVIDENCE_MISSING", evidence_id)
        report = json.loads(row["payload"])
        if (row["result"] != "PASS" or row["behavior_id"] != behavior_id
            or row["profile"] != "BPBR-AUDIT-v1"
            or report.get("positive_pass", 0) < 3 or report.get("negative_pass", 0) < 3
            or report.get("total_fail", 1) != 0):
            raise BPBRError("EVIDENCE_INSUFFICIENT", "Independent positive/negative conformance required")
        # Do not let a caller promote an arbitrary self-asserted PASS receipt.
        # Rerun the trusted local station and require exact deterministic results.
        from .station import conformance
        refreshed = conformance(behavior, registry)
        if refreshed["verdict"] != "PASS" or digest(refreshed) != digest(report):
            raise BPBRError("EVIDENCE_REPLAY_MISMATCH", "Stored suite did not reproduce")
        with self.db:
            self.db.execute("UPDATE behavior SET status='ACQUIRED', evidence_id=? WHERE behavior_id=? AND status='CANDIDATE'",
                            (evidence_id, behavior_id))

    def select_acquired(self, goal_key: str, registry: FunctionRegistry) -> Behavior:
        rows = self.db.execute("SELECT payload FROM behavior WHERE goal_key=? AND status='ACQUIRED' ORDER BY behavior_id", (goal_key,)).fetchall()
        for row in rows:
            b = Behavior.from_payload(json.loads(row["payload"]))
            verify_binding(b, registry)
            return b
        raise BPBRError("NO_ACQUIRED_BEHAVIOR", goal_key)

    def suspend(self, behavior_id: str) -> None:
        _, status = self.get(behavior_id)
        if status != "ACQUIRED":
            raise BPBRError("TRANSITION_FORBIDDEN", "Suspension requires ACQUIRED")
        with self.db:
            self.db.execute("UPDATE behavior SET status='SUSPENDED' WHERE behavior_id=?", (behavior_id,))

    def record_episode(self, behavior: Behavior, request: Any, result: dict[str, Any], *, reused: bool) -> str:
        episode = {"behavior_id": behavior.behavior_id, "request_sha256": digest(request),
                   "output_sha256": digest(result["output"]), "reused": bool(reused), "steps": result["steps"]}
        # Event identity is distinct from content identity: repeated identical
        # invocations are separate experiences unless a host idempotency key says otherwise.
        episode_id = "EP-" + uuid4().hex
        recorded_at = datetime.now(timezone.utc).isoformat()
        with self.db:
            self.db.execute("INSERT INTO episodes VALUES (?,?,?,?,?,?,?)",
                            (episode_id, behavior.behavior_id, recorded_at, episode["request_sha256"],
                             episode["output_sha256"], int(reused), canonical(result["steps"])))
        return episode_id

    def counts(self) -> dict[str, int]:
        return {"behaviors": self.db.execute("SELECT COUNT(*) FROM behavior").fetchone()[0],
                "evaluations": self.db.execute("SELECT COUNT(*) FROM evaluations").fetchone()[0],
                "episodes": self.db.execute("SELECT COUNT(*) FROM episodes").fetchone()[0],
                "reused_episodes": self.db.execute("SELECT COUNT(*) FROM episodes WHERE reused=1").fetchone()[0]}
