# COGNITIVE INVENTORY — READ-ONLY FREEZE

- Inventory ID: `BPBR-FREEZE-20261011-001`
- Author: OpenAI / GPT-6 (analyst and implementer; **not** independent reviewer)
- Date: 2026-10-11 (Europe/Madrid)
- Scope: project source inventory and agreed functional design. **No GitHub repository was frozen, tagged, modified or pushed.**
- Evidence provenance: read-only GitHub connector file inspections performed 2026-10-11; this package is a standalone implementation in an isolated working directory.

## Pinned repo snapshots used as source references

- `MarcValls/BAGO`, observed main tree SHA `f3804a7e9333607561d28fd5075569e725aa0bb0`.
- `MarcValls/BAGO_AGENTIC_DATA_LAB`, observed main tree SHA `9428b272735e365c5a1b83197008c31eaa281ee5`.
- `MarcValls/bago-framework`, observed search source SHA `fc701c8b31ec74427a0cd74c916bacc79bfeb50a`.
- Historic documents and contract copies in ChatGPT Library, including Cognitive Graph, Dynamic Connections and SPBE v0.5-FIX5, were reviewed at document level in preceding discovery. Library copies do **not** certify source/runtime integration.

## Frozen functional target

- Need detection (typed goal, not necessarily LLM).
- Discovery of existing functions with explicit typed I/O and effects.
- Bounded composition from a finite, trusted allowlist.
- Execution only inside explicitly granted sandbox effects.
- Positive **and negative** independent fixture evaluation.
- Acquisition into a versioned durable registry only after positive evaluation.
- Retrieval of acquired behavior after a **different interpreter process** reopens the database.
- Invalidation upon function identity changes and suspension on known regression.
- No autonomous privilege promotion; relevance and repeated success are not authorization.

## Non-goals for this freeze

- General intelligence, biological brain, consciousness, predictive world model.
- Direct shell/code/network side effects, live providers, unrestricted agent loops.
- Learning model weights or autonomous generation of Python functions.
- A claim of integration with the current GitHub BAGO/ADL runtime.
- Certifying hostile multi-user database tampering, Windows filesystem race freedom, cryptographically signed attestation.

## First candidate behavior

`evidence_integrity_audit`: `manifest_request` → `manifest_entries` → `hashed_entries` → `comparison` → `audit_report`.

This is a controlled illustration of acquiring a previously unregistered *composed behavior*, NOT discovery of a fundamentally new machine primitive. It deliberately uses four known primitives. Its reuse is proven by the second process which **does not call the composer**.
