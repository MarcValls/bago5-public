"""Auditable built-in functions: no process execution, network, or writes to workspace."""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
from typing import Any
from .core import BPBRError, FunctionRegistry

MAX_BYTES = 2 * 1024 * 1024
MAX_ENTRIES = 64
SHA = re.compile(r"^[0-9a-f]{64}$")


def safe_file(root: Path, relative: str) -> Path:
    if not isinstance(relative, str) or not relative or "\\" in relative or "\x00" in relative:
        raise BPBRError("PATH_DENIED", "Invalid relative path")
    p = Path(relative)
    if p.is_absolute() or any(part in ("..", ".") for part in p.parts) or relative.startswith("/"):
        raise BPBRError("PATH_DENIED", "Path traversal or absolute path")
    real_root = root.resolve(strict=True)
    path = real_root / p
    current = real_root
    for part in p.parts:
        current = current / part
        if current.is_symlink():
            raise BPBRError("SYMLINK_DENIED", "Symlinks cannot be followed")
    if not path.resolve(strict=False).is_relative_to(real_root):
        raise BPBRError("PATH_DENIED", "Escapes workspace")
    return path


def parse_manifest(request: Any, workspace: Path) -> dict[str, Any]:
    if not isinstance(request, dict) or set(request) != {"manifest"}:
        raise BPBRError("INPUT_INVALID", "Require {manifest: relative_path}")
    path = safe_file(workspace, request["manifest"])
    if not path.is_file() or path.stat().st_size > MAX_BYTES:
        raise BPBRError("MANIFEST_INVALID", "Manifest missing or too large")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, UnicodeError) as exc:
        raise BPBRError("MANIFEST_INVALID", "Cannot parse manifest") from exc
    if not isinstance(data, dict) or set(data) != {"entries"} or not isinstance(data["entries"], list):
        raise BPBRError("MANIFEST_INVALID", "Expected entries list")
    if not 1 <= len(data["entries"]) <= MAX_ENTRIES:
        raise BPBRError("MANIFEST_INVALID", "Entry count out of bounds")
    seen = set()
    entries = []
    for entry in data["entries"]:
        if not isinstance(entry, dict) or set(entry) != {"path", "sha256"}:
            raise BPBRError("MANIFEST_INVALID", "Entry structure invalid")
        name, expected = entry["path"], entry["sha256"]
        safe_file(workspace, name)
        if not isinstance(expected, str) or not SHA.fullmatch(expected):
            raise BPBRError("MANIFEST_INVALID", "Expected SHA256 must be lowercase hex")
        if name in seen:
            raise BPBRError("MANIFEST_INVALID", "Duplicate entry")
        seen.add(name)
        entries.append({"path": name, "expected": expected})
    return {"entries": entries}


def hash_files(payload: dict[str, Any], workspace: Path) -> dict[str, Any]:
    hashed = []
    for entry in payload["entries"]:
        path = safe_file(workspace, entry["path"])
        if not path.exists():
            hashed.append({**entry, "observed": None})
            continue
        if not path.is_file() or path.stat().st_size > MAX_BYTES:
            raise BPBRError("FILE_INVALID", "Non-regular or oversized file")
        # Use a no-follow file descriptor to limit replacement with symlink on Linux.
        # On Windows the reference is a sandbox-only demonstrator; TOCTOU hardening is not certified.
        hashed.append({**entry, "observed": hashlib.sha256(path.read_bytes()).hexdigest()})
    return {"entries": hashed}


def compare_hashes(payload: dict[str, Any], workspace: Path) -> dict[str, Any]:
    outcomes = []
    for entry in payload["entries"]:
        observed = entry["observed"]
        status = "MISSING" if observed is None else "MATCH" if observed == entry["expected"] else "STALE"
        outcomes.append({"path": entry["path"], "expected": entry["expected"],
                         "observed": observed, "status": status})
    return {"entries": outcomes}


def render_report(payload: dict[str, Any], workspace: Path) -> dict[str, Any]:
    entries = payload["entries"]
    return {"entries": entries, "counts": {status: sum(1 for e in entries if e["status"] == status)
                                           for status in ("MATCH", "STALE", "MISSING")},
            "overall": "PASS" if all(e["status"] == "MATCH" for e in entries) else "REVIEW"}


def standard_registry() -> FunctionRegistry:
    r = FunctionRegistry()
    r.register("parse_manifest", "manifest_request", "manifest_entries", "READ_LOCAL", parse_manifest)
    r.register("hash_files", "manifest_entries", "hashed_entries", "READ_LOCAL", hash_files)
    r.register("compare_hashes", "hashed_entries", "comparison", "PURE", compare_hashes)
    r.register("render_report", "comparison", "audit_report", "PURE", render_report)
    return r
