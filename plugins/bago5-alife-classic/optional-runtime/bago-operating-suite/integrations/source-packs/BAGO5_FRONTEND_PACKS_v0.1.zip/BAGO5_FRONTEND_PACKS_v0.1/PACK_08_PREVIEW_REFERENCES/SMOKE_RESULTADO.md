# Smoke visual de la maqueta — evidencia acotada

**Estado: PASS de MAQUETA**, **NO** constituye verificación de frontend React/BAGO5 ni integración backend.

Ejecución en contenedor de preparación con Chromium headless, Playwright Python, contenido HTML inyectado con `page.set_content` (restricción administrativa de acceso directo a `file://` en este entorno), 18/10/2026.

| Comprobación | Resultado |
|---|---|
| JavaScript: `node --check` sobre script extraído | PASS |
| Monta Proveedores y Modelos sin error JS | PASS |
| Modal Añadir proveedor se abre y se cierra | PASS |
| Alta de proveedor DEMO en memoria | PASS |
| Alta de modelo DEMO en memoria | PASS |
| Modal de rutas se abre, guarda mock y cierra | PASS |
| Navega CFG-03 y CFG-01 | PASS |
| Escape cierra modal | PASS |
| No errores `pageerror` observados | PASS |
| 1600px sin overflow global | PASS |
| 1024px sin overflow global | PASS |
| 390px sin overflow global | PASS |
| Capturas de 1600, 1024 y 390 disponibles en este pack | PASS |
| Backend real, proveedores reales, pagos, credenciales | NOT_RUN |
| App React/Vite integrada, permisos, migración, Windows E2E | NOT_RUN |

**Límites:** Smoke de interacción y visual únicamente. No certifica accesibilidad completa, persistencia, integración ni guardas de ejecución. Las cantidades y proveedores del HTML son de ejemplo y se etiquetan explícitamente como DEMO.
