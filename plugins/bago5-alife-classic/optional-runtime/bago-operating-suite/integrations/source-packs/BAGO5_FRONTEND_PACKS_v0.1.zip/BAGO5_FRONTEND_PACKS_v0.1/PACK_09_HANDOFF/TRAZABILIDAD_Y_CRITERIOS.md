# Trazabilidad: necesidad → pantalla → contrato → verificación

| Necesidad | Dominio/vista | Regla contractual | Prueba objetivo |
|---|---|---|---|
| Registrar proveedor | CFG-02 modal ProviderEditor | 001 owner único / secreto opaco | UI-006 / CFG-T18 |
| Habilitar modelos | CFG-02 listado | enabled ≠ availability ≠ authority | UI-004 / UI-020 |
| Enrutar por función | CFG-02 ModelRoutingDialog | 002 resolución tipada allowlist | UI-008 / CFG-T19 |
| Inspeccionar dependencias | CFG-02 DependencyInspector | 001 ChangeImpact | UI-009 / CFG-T09 |
| Gobernar permisos | CFG-03 y autorización externa | security policy ≠ grant | UI-017 / CFG-T08 |
| Limitar ejecución | CFG-04 | máx. efectivos y sandbox disponible | CFG-T10 / CFG-T20 |
| Contexto por proyecto | CFG-05 y Proyectos | ruta registrada ≠ acceso concedido | UI-018 / CFG-T05 |
| Aislar conversaciones | CFG-05 / Conversación | contexto proyecto ≠ memoria específica | CFG-T13 |
| Copia/restauración | CFG-06 | preflight y compatibilidad | UI-016 / CFG-T22 |
| Instalar dependencias | CFG-07 | integración ≠ herramienta autorizada | CFG-T11 |
| Overrides de agente | Agentes | agente preferencia, no policy owner | UI-012 / CFG-T02 |
| Accesibilidad | Todas | teclado, labels, foco | UI-014 |
| Conservación de UI | Todas | comparar antes/después (elementos y funcionalidad) | UI-021 / UI-022 |

Los IDs `CFG-Txx` son del contrato original; si difieren de versiones posteriores se conserva la referencia al documento FROZEN, y se documenta formalmente la divergencia antes de implementar.

**Definición de DONE:** No basta con render. Exigir un recorrido demostrable con datos, pruebas, capturas y fuente de verdad. Si el backend no existe, la UI se declara `IMPLEMENTADO (MOCK)` y `INTEGRACIÓN NOT_RUN`.
