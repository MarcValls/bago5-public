# PACK 03 — Las 7 pantallas de configuración global

Las siete vistas comparten `SettingsPageLayout`, `ScopeBadge`, `FieldOrigin`, `SaveBar`, `ImpactReview`, `EmptyState`, `ErrorState` y `PendingCapabilityNotice`. No crear stores independientes con copias de lo mismo.

| Pantalla | Paneles y campos | Acciones UI | Owner | Fuera de alcance |
|---|---|---|---|---|
| CFG-01 General | Apariencia (tema, idioma, densidad); inicio (vista inicial/restaurar); notificaciones | guardar/restablecer preferencias | ApplicationPreferences | modelos, permisos |
| CFG-02 Proveedores y Modelos | catálogo, habilitación, disponibilidad, rutas y pruebas | véase PACK_02 | ProviderModelRegistry | herramientas MCP/agentes |
| CFG-03 Seguridad y Permisos | política default deny, restricciones, aprobación humana, grants sólo lectura con revocación delegada | ver políticas, solicitar revisión, revocar vía servicio de autoridad | SecurityPolicyManager; AuthorizationService propietario del grant | ejecutar herramientas, conceder desde UI sin autorización |
| CFG-04 Ejecución y Recursos | límites concurrencia, timeout, retry, perfil sandbox, aislamiento requerido vs disponible | preflight de límites, editar restricciones | ExecutionPolicyManager | trabajos, traces, conceder permisos |
| CFG-05 Contexto y Memoria | políticas retención, aislamiento, memoria conversación, indexado automático gobernado | actualizar política/ver alcance | ContextMemoryPolicy | registrar fuentes, leer memorias ajenas |
| CFG-06 Almacenamiento y Copias | paths locales, salud, backup/restore, integridad, exportación | preflight migración, backup, restore con confirmación | StorageManager | alterar memoria semántica, secrets |
| CFG-07 Integraciones y Sistema | herramientas instaladas, versiones, adaptadores externos no LLM, estado, diagnósticos | detectar/verificar/configurar dependencia | SystemIntegrationRegistry | MCP Tool Registry, modelos |

## Wireframe replicable para seis pantallas no CFG-02

```text
┌──────────────────────────────────────────────────────────────────┐
│ CONFIGURACIÓN / SEGURIDAD Y PERMISOS              Estado: sin leer │
├──────────────────────────────────────────────────────────────────┤
│ [Grupo A: Política]          [Origen global / revisión 4]         │
│ campo | valor | validación | procedencia                         │
│                                                                  │
│ [Grupo B: Diagnóstico]                                          │
│ revisión, límites, dependencias, links a la sección propietaria   │
│                                                                  │
│ [Restablecer cambios]                       [Guardar]            │
└──────────────────────────────────────────────────────────────────┘
```

## Operaciones que NO SON un mero save
- CFG-03: revocar grants exige autoridad y receipt; no mutar `grant` desde un form de política.
- CFG-04: actualizar límites no reescribe ejecuciones activas; al siguiente efecto se comprueba autorización válida.
- CFG-05: retención y borrado efectivo son operaciones distintas, con alcance declarado.
- CFG-06: restaurar backup exige verificación, plan de migración y autorización; nunca sobreescribir por pulsar Guardar.
- CFG-07: verificar binarios requiere un adaptador backend explícito; la mera detección de ruta no concede capacidad ejecutable.

## Vistas con estados operativos
Todos los paneles deben implementar: LOADING, EMPTY, READY, DIRTY, VALIDATING, SAVING, SAVED, STALE_REVISION, POLICY_BLOCKED, NOT_IMPLEMENTED, ERROR. Cuando sólo existe mock, encabezado de entorno `DEMO · ESTADO SIMULADO`.

## Criterios de cierre por pantalla
- Owner identificado y campos documentados, sin elementos que pertenecen a otro owner.
- Puede consultarse el origen/alcance de cada valor editable.
- Acciones no ejecutan efectos colaterales sin consentimiento explícito.
- Teclado, validaciones, errores y responsive comprobados.
- Pruebas negativas y visuales con evidencia/commit; nunca declarar PASS sin ejecutarlas.
