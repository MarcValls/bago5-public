# BAGO5 — Configuration Domain Contract

| Campo | Valor |
|---|---|
| Identificador | `BAGO5-CONFIG-001` |
| Versión | `0.1` |
| Fecha | `2026-10-13` |
| Autor del documento | Especificación de arquitectura BAGO5, preparada por OpenAI / ChatGPT |
| Estado | **DESIGN FROZEN** · implementación `NOT_VERIFIED` |
| Alcance | Configuración global, proyectos, agentes, conversaciones y frontera de ejecución |
| Contrato complementario | [`BAGO5-CONFIG-002_EFFECTIVE_RESOLUTION_v0.1.md`](BAGO5-CONFIG-002_EFFECTIVE_RESOLUTION_v0.1.md) |

> **Estado y límites.** Este documento congela responsabilidades y contratos *lógicos*. No certifica que existan endpoints, tablas, pantallas ni pruebas de implementación. BAGO5 es un sistema nuevo; los componentes de sistemas BAGO anteriores son referencias, no dependencias obligatorias.

## 1. Objetivo y decisiones

1. Cada entidad de configuración persistente tiene **un único propietario canónico**. Las demás pantallas consultan referencias o vistas derivadas.
2. Las pantallas son interfaces de configuración; **no son fuentes de verdad**.
3. Configuración global, proyecto, agente y conversación tienen ámbitos separados. No se copian configuraciones completas entre ámbitos.
4. La herencia selecciona preferencias y aplica restricciones; **nunca concede autoridad**.
5. Registro de fuente, integración, herramienta o modelo **no significa acceso o permiso**.
6. El acceso a recursos surge de una intención explícita y una decisión autorizadora verificable. La frontera de ejecución verifica la vigencia del permiso antes de materializar el efecto.
7. Configuración y ejecución están desacopladas. Guardar una preferencia no debe lanzar llamadas a modelos, comandos o movimientos de datos.
8. Cada cambio que pueda afectar a dependencias se previsualiza y se valida antes de aplicarse.

### 1.1 Dominios de Configuración global

| ID | Pantalla | Servicio propietario | Qué administra | Qué **no** administra | Prioridad |
|---|---|---|---|---|---|
| CFG-01 | General | `ApplicationPreferences` | Idioma, tema, densidad, inicio, ventanas, notificaciones | Modelos, agentes, permisos, memoria | P1 |
| CFG-02 | Proveedores y Modelos | `ProviderModelRegistry` | Proveedores, endpoints LLM, referencias a credenciales, modelos y rutas **globales**, conectividad | Permisos de herramientas, agentes, fuentes | P0 |
| CFG-03 | Seguridad y Permisos | `SecurityPolicyManager` | Políticas de acceso, restricciones, duración máxima de grants, revisión de permisos | Ejecución de herramientas, registro de fuentes | P0 |
| CFG-04 | Ejecución y Recursos | `ExecutionPolicyManager` | Concurrencia, timeouts, reintentos, perfiles de sandbox y límites técnicos | Conceder autoridad, gestionar trabajos concretos | P0 |
| CFG-05 | Contexto y Memoria | `ContextMemoryPolicy` | Políticas de retención, indexación, recuperación y aislamiento | Alta de fuentes concretas, mensajes particulares | P0 |
| CFG-06 | Almacenamiento y Copias | `StorageManager` | Persistencia física, integridad, backups, restauración y migración | Significado del contexto, permisos de agentes | P1* |
| CFG-07 | Integraciones y Sistema | `SystemIntegrationRegistry` | Dependencias, CLIs y servicios externos **no LLM**, conectividad | Registro de herramientas MCP utilizables por agentes, modelos | P1 |

\* La pantalla completa de CFG-06 es P1; la persistencia mínima segura y separación de datos son P0.

### 1.2 Propietarios fuera de Configuración global

| Entidad | Propietario | Datos canónicos |
|---|---|---|
| Proyecto | `ProjectManager` | Identidad, preferencias de proyecto, modelos admitidos, límites propios, agentes vinculados |
| Fuentes de proyecto | `ProjectContextManager` | Catálogo de referencias a archivos, directorios, textos, correos y futuras fuentes; estado de indexación |
| Agente | `AgentRegistry` | Identidad, instrucciones, modelo preferido, parámetros y capacidades solicitadas |
| Conversación | `ConversationMemoryManager` | Mensajes, memoria específica, contexto y selecciones temporales |
| Herramientas / capacidades | `ToolRegistry` | Definición, versión, tipo de efecto y capacidades invocables |
| Grants vigentes | `AuthorizationService` | Concesiones, restricciones, vencimiento, revocación, principal, recurso e intención |
| Secretos | `SecretStore` | Material sensible; los demás dominios almacenan **referencias opacas** |
| Trabajos y efectos | `ExecutionRuntime` / `ExecutionGateway` | Plan, ejecución, resultado y referencias de configuración |
| Evidencia y trazas | `EvidenceStore` / `Observability` | Receipts, verificaciones, trazas y resultados de evaluación |

**Distinción:** `SecurityPolicyManager` configura políticas; `AuthorizationService` es el propietario de los grants y de su validación. El proyecto sólo conserva referencias a los grants pertinentes, nunca decide su validez.

## 2. Esquema de navegación y límites de interfaz

```text
BAGO5
├─ Chat
├─ Proyectos
│  └─ Proyecto seleccionado
│     ├─ Fuentes y contexto                 [propietario: ProjectContextManager]
│     ├─ Modelos permitidos                 [selecciones/referencias]
│     ├─ Agentes asociados                  [vínculos/referencias]
│     ├─ Permisos                           [vista de grants + solicitudes]
│     ├─ Contexto compartido / memoria      [contenido del proyecto]
│     └─ Límites de ejecución               [restricciones de proyecto]
├─ Agentes
│  └─ Agente seleccionado
│     ├─ Identidad e instrucciones
│     ├─ Modelo preferido y parámetros      [referencias, nunca altas de proveedor]
│     └─ Capacidades solicitadas            [no son grants]
├─ Herramientas                            [ToolRegistry]
├─ Ejecución                                [ExecutionRuntime]
├─ Evaluación / Observabilidad              [EvidenceStore]
└─ Configuración global
   ├─ 01 General
   ├─ 02 Proveedores y Modelos
   ├─ 03 Seguridad y Permisos
   ├─ 04 Ejecución y Recursos
   ├─ 05 Contexto y Memoria
   ├─ 06 Almacenamiento y Copias
   └─ 07 Integraciones y Sistema
```

**No crear** una pantalla global «Fuentes del proyecto», ni registrar modelos desde la ficha de agente, ni gestionar secretos en ventanas de consulta de evidencia.

## 3. Contratos lógicos por dominio

Los siguientes son esquemas lógicos, no definiciones obligatorias de API ni tablas.

### CFG-01 — `GeneralPreferences`

```yaml
user_id: string
language: string
theme: system|light|dark
ui_density: compact|comfortable
ui_scale: number
startup_view: string
restore_windows: boolean
close_behavior: ask|close|keep_running
notification_preferences: object
revision: integer
```

**Acciones:** `getPreferences`, `updatePreferences`, `resetPreferences`.

### CFG-02 — `ProviderRegistration`, `ModelRegistration`, `ModelRoute`

```yaml
ProviderRegistration:
  provider_id: string
  provider_type: string
  display_name: string
  endpoint: string|null
  authentication_method: string
  credential_reference: string|null # Nunca secreto en claro
  connection_status: unverified|healthy|degraded|unreachable
  enabled: boolean
  revision: integer
ModelRegistration:
  model_id: string
  provider_id: string
  external_model_id: string
  display_name: string
  capabilities: [string]
  supported_parameters: [string]
  limits: object
  enabled: boolean
  availability_status: unverified|available|unavailable|degraded
  last_verified_at: datetime|null
  revision: integer
ModelRoute:
  route_id: string
  owner_scope: global|project
  owner_id: string
  purpose: chat|reasoning|code|rag|embedding|vision|other
  primary_model_id: string|null
  fallback_model_ids: [string]
  parameter_overrides: object
  budget_policy_ref: string|null
  revision: integer
```

**Acciones:** `registerProvider`, `updateProvider`, `testConnection`, `discoverModels`, `registerModel`, `setModelEnabled`, `setDefaultRoute`, `testModel`, `inspectModelDependencies`.

**Estados ortogonales:** registrado, habilitado, disponible y asignado. Un modelo registrado/habilitado no se considera probado ni autorizado a ejecutar herramientas. Las pruebas de conectividad o inferencia son acciones separadas, explícitas y potencialmente facturables.

### CFG-03 — `SecurityPolicy` y `AuthorizationGrant`

```yaml
SecurityPolicy:
  policy_id: string
  scope: global|project
  default_decision: deny
  restricted_operations: [string]
  maximum_grant_duration_seconds: integer
  resource_constraints: object
  data_transfer_constraints: object
  human_approval_rules: object
  revision: integer
AuthorizationGrant:              # Propietario real: AuthorizationService
  grant_id: string
  principal_id: string
  resource_id: string
  operations: [read|write|create|delete|execute|network|other]
  scope: session|project|operation
  issued_from_intent: string
  issued_by: string
  issued_at: datetime
  expires_at: datetime
  constraints: object
  revocation_status: active|revoked|expired
```

**Acciones de política:** `getSecurityPolicy`, `updateSecurityPolicy`, `inspectEffectivePermissions`.

**Acciones del servicio de autorización:** `requestAuthorization`, `issueGrant`, `validateGrant`, `revokeGrant`.

Detectar un path en un mensaje no lo registra ni concede permiso. Si el usuario pide auditar `C:\PROYECTO`, la solicitud explícita puede ofrecer **Sólo lectura / Lectura y escritura / Cancelar**. El grant emitido especifica principal, recursos, operaciones, expiración y límites. Autorizar un proyecto no autoriza automáticamente a todos los agentes.

### CFG-04 — `ExecutionPolicy`

```yaml
policy_id: string
scope: global|project
max_concurrency: integer
max_duration_seconds: integer
max_memory_bytes: integer|null
max_retries: integer
allowed_executor_profiles: [string]
sandbox_requirements: object
failure_policy: object
receipt_requirements: object
revision: integer
```

**Acciones:** `getExecutionPolicy`, `updateExecutionPolicy`, `resolveExecutionLimits`, `validateExecutionRequest`, `inspectResourceAvailability`.

Los límites efectivos se obtienen combinando restricciones globales, del proyecto, del agente y del permiso. Si no puede imponerse un aislamiento requerido, `DENY`. No confundir política lógica de red con aislamiento de red a nivel del sistema operativo.

### CFG-05 — `ContextMemoryPolicy`, `ProjectContextCatalog`, `ConversationMemory`

```yaml
ContextMemoryPolicy:
  policy_id: string
  retention_policy: object
  conversation_persistence: boolean
  retrieval_policy: object
  indexing_policy: object
  context_size_limits: object
  project_isolation_policy: object
  temporary_context_policy: object
  deletion_policy: object
  revision: integer
ProjectContextCatalog:           # Propietario: ProjectContextManager
  project_id: string
  source_references: [string]
  shared_context_entries: [string]
  index_references: [string]
  retrieval_preferences: object
  revision: integer
ContextSource:
  source_id: string
  source_type: file|directory|text|email|other
  display_name: string
  resource_reference: string
  registration_origin: string
  access_grant_reference: string|null
  index_status: not_indexed|indexed|stale|error
  last_validation: datetime|null
ConversationMemory:             # Propietario: ConversationMemoryManager
  conversation_id: string
  project_id: string|null
  message_references: [string]
  session_context: object
  memory_entries: [string]
  temporary_source_references: [string]
  retention_status: string
  revision: integer
```

**Regla:** `PROJECT_CONTEXT != CONVERSATION_MEMORY`. Registrar una fuente no concede permiso de lectura ni hace que se comparta entre proyectos. La indexación tampoco puede atravesar permisos de acceso o límites de transferencia de datos.

### CFG-06 — `StorageConfiguration`

```yaml
storage_id: string
application_data_path: string
database_backend: string
evidence_path: string
cache_path: string
backup_policy: object
backup_destination: string|null
integrity_policy: object
revision: integer
```

**Acciones:** `getStorageConfiguration`, `updateStorageConfiguration`, `inspectStorageHealth`, `createBackup`, `validateBackup`, `restoreBackup`, `exportConfiguration`.

Los cambios de directorio/base de datos requieren plan explícito de migración, copia comprobable, verificación y recuperación si fallan. Los backups no deben filtrar secretos en claro.

### CFG-07 — `SystemIntegration`

```yaml
integration_id: string
integration_type: cli|local_service|remote_service|other
  # Excluye conexiones a proveedores LLM
display_name: string
endpoint_or_executable: string
version: string|null
authentication_reference: string|null
configuration: object
availability_status: unverified|available|unavailable|degraded
last_verified_at: datetime|null
revision: integer
```

**Acciones:** `registerIntegration`, `updateIntegration`, `detectDependency`, `testIntegration`, `disableIntegration`, `inspectIntegrationDependencies`.

Una integración GitHub, Codex CLI o Playwright registrada sólo se convierte en herramienta para un agente mediante un alta explícita en `ToolRegistry`, un binding válido y autorización separada.

## 4. Contrato transversal

```yaml
ConfigurationEntry:
  configuration_id: string
  domain: CFG-01|CFG-02|CFG-03|CFG-04|CFG-05|CFG-06|CFG-07
  scope: user|global|project|agent|conversation
  owner_id: string
  schema_version: string
  revision: integer
  values: object  # sin secretos
  created_at: datetime
  updated_at: datetime
  updated_by: string
```

Operaciones del subsistema de configuración:

- `readConfiguration(scope, domain)`
- `proposeConfigurationChange(change)`
- `validateConfigurationChange(change)`
- `commitConfigurationChange(change, expected_revision)`
- `resolveEffectiveConfiguration(context)` → definido por `BAGO5-CONFIG-002`
- `getConfigurationHistory(scope, domain)`

**Control de escritura:** atomicidad + control de versión (`expected_revision`). Una validación previa es necesaria pero no evita carreras; el commit debe revalidar la versión y las condiciones críticas.

**Control de cambios con dependencias:** deshabilitar/eliminar proveedor, modelo, integración, fuente o grant y modificar almacenamiento o políticas críticas exige `ChangeImpact`:

```yaml
change_id: string
target_entity: string
requested_operation: string
affected_projects: [string]
affected_agents: [string]
affected_conversations: [string]
affected_routes: [string]
affected_integrations: [string]
active_executions: [string]
required_migrations: [string]
blocking_constraints: [string]
```

Una ejecución conserva el identificador de revisión de configuración usada, pero un snapshot previo **no conserva autoridad revocada**: antes de un efecto material se valida el grant vigente.

## 5. Matriz anti-duplicidades

| Dato / decisión | Fuente canónica | Referencias permitidas |
|---|---|---|
| Conexión con proveedor LLM | CFG-02 | Proyectos y agentes seleccionan modelos registrados |
| Modelo global habilitado | CFG-02 | Proyecto restringe y agente prefiere |
| Modelo seleccionado en conversación | Conversación | Sólo entre modelos efectivos elegibles |
| Política de acceso | CFG-03 | Proyecto añade restricciones; agente solicita capacidades |
| Grant de autorización | `AuthorizationService` | Proyecto/conversación referencian, ejecución valida |
| Secreto | `SecretStore` | Sólo referencia opaca |
| Fuente de conocimiento | Proyecto | Conversaciones del proyecto referencian si procede |
| Memoria de conversación | Conversación | No se replica como memoria global |
| Política de retención/indexación | CFG-05 | Proyecto puede restringir |
| Identidad e instrucciones del agente | Agente | Proyecto mantiene el vínculo |
| Definición de herramienta | `ToolRegistry` | Agente declara capacidades solicitadas |
| Servicio externo / CLI instalado | CFG-07 | `ToolRegistry` usa su integración |
| Límite técnico global | CFG-04 | Proyecto/agente pueden restringir o solicitar menor límite |
| Ubicación física del almacenamiento | CFG-06 | Proyectos reciben espacio lógico |
| Trabajo, receipt y trace | Ejecución / Evidencia | Configuración sólo enlaza y consulta |

## 6. Invariantes vinculantes

| ID | Invariante |
|---|---|
| INV-CONFIG-01 | Propietario canónico único de cada registro persistente. |
| INV-CONFIG-02 | No duplicación de registros globales entre Configuración, Proyecto y Agente. |
| INV-CONFIG-03 | Los overrides no amplían autoridad. |
| INV-CONFIG-04 | Registro no implica permiso. |
| INV-CONFIG-05 | Aislamiento de fuentes entre proyectos. |
| INV-CONFIG-06 | Memoria específica de conversación separada de contexto del proyecto. |
| INV-CONFIG-07 | Secretos sólo en almacén seguro; referencias opacas en configuración y evidence. |
| INV-CONFIG-08 | `AVAILABLE` requiere prueba reciente válida, no mera configuración. |
| INV-CONFIG-09 | Historial de cambios con actor, revisión y resultado. |
| INV-CONFIG-10 | La UI no muestra capacidades no implementadas como operativas. |
| INV-CONFIG-11 | Revocación efectiva en frontera de ejecución. |
| INV-CONFIG-12 | Leer/resolver configuración no provoca efectos materiales. |
| INV-CONFIG-13 | Cambios con dependencias: análisis de impacto, validación y confirmación. |
| INV-CONFIG-14 | Mutaciones atómicas o estado recuperable; no parcialidad silenciosa. |

## 7. Plan de conformidad mínimo

| ID | Prueba | Esperado |
|---|---|---|
| CFG-T01 | Proyecto cambia modelo predeterminado | Global no cambia |
| CFG-T02 | Agente pide modelo deshabilitado | `DENY` |
| CFG-T03 | Conversación cambia a modelo permitido | `ALLOW` si supera otras políticas |
| CFG-T04 | Proyecto intenta ampliar política global | `DENY` |
| CFG-T05 | Texto contiene una ruta | Sin acceso ni alta automática |
| CFG-T06 | Autorización de lectura solicitada por intención | Grant acotado |
| CFG-T07 | Escritura con grant de lectura | `DENY` |
| CFG-T08 | Revocación entre planificación y efecto | `DENY` antes del efecto |
| CFG-T09 | Eliminar modelo en uso | Bloqueo o migración explícita |
| CFG-T10 | Timeout de proyecto supera máximo global | `DENY` |
| CFG-T11 | Integración registrada sin ToolRegistry | No invocable por agentes |
| CFG-T12 | Prueba de conexión fallida | No reportar disponible |
| CFG-T13 | Cambio de proyecto | No fuga de fuentes privadas |
| CFG-T14 | Reinicio | Persistencia consistente |
| CFG-T15 | Conflicto de revisión concurrente | `REVISION_CONFLICT` |
| CFG-T16 | Cambio con job activo | Sin reconfiguración silenciosa |
| CFG-T17 | Error durante guardado | Sin estado parcial |
| CFG-T18 | Lectura de configuración con secreto | No revela material sensible |
| CFG-T19 | Fallback local → cloud sin permiso de transferencia | `DENY` |
| CFG-T20 | Aislamiento técnico exigido no disponible | `DENY` |
| CFG-T21 | Resolución de configuración | Sin efectos materiales |
| CFG-T22 | Backup incompatible | Restauración bloqueada |

**Criterio futuro:** `P0=0`, `P1=0`, pruebas positivas y negativas verificadas. Hasta ejecutar la implementación: `NOT_RUN`.

## 8. Freeze y siguiente fase

**Incluido en el freeze:** dominios, propietarios, fronteras global/proyecto/agente/conversación, esquemas lógicos, invariantes y conformidad mínima.

**No incluido:** componentes React, endpoints definitivos, tablas físicas, proveedor de secretos, migraciones, aislamiento de SO, ni certificación de comportamiento en runtime.

**Siguiente secuencia:**

`FREEZE DOMAIN OWNERS → SPECIFY EFFECTIVE CONFIG RESOLVER → DESIGN PERSISTENCE → IMPLEMENT CONFIG API → POSITIVE/NEGATIVE TESTS → CRIT-BAGO5-CONFIG-001`
