# PACK 02 — CFG-02 Proveedores y Modelos

**Owner:** `ProviderModelRegistry`. UI de gestión, nunca autoridad de ejecución. Reglas contractuales en 001/002.

## Zonas de la pantalla
1. Encabezado con título/ayuda y acción `Añadir proveedor`. Debajo KPI calculados desde API/snapshot **con etiqueta de procedencia**: proveedores registrados, modelos, habilitados y rutas.
2. **Proveedores** (izquierda): búsqueda, estado de conexión comprobado (con timestamp) + estado habilitado independiente; seleccionar proveedor. Menú `Editar / Ver diagnóstico / Deshabilitar / Eliminar` con comprobación de impacto.
3. **Modelos** (centro): buscar, filtrar por tipo/capacidad y estado, activar/desactivar modelos, mostrar ID real, capacidades, vigencia de disponibilidad y ruta por defecto. Acciones `Descubrir`, `Registrar manual`, seleccionar.
4. **Detalles** (derecha): tabs `General / Parámetros / Asignaciones / Pruebas`; editor coherente con campos admitidos para el modelo; no mostrar temperatura a embeddings.
5. Banda inferior: `Enrutamiento / Fallback` (abre un diálogo ampliado) y `Prueba rápida` con confirmación/aviso de coste si procede. Resultados con evidencia y fuente.

## Wireframe de escritorio

```text
┌──────────────────────────────────────────────────────────────────────────────────────────────┐
│ Proveedores y Modelos                                [+ Añadir proveedor]                    │
│ Proveedores: 6          Modelos: 18             Habilitados: 9         Rutas: 4              │
├────────────────────┬────────────────────────────────┬────────────────────────────────────────┤
│ PROVEEDORES        │ MODELOS                        │ DETALLE DEL MODELO                     │
│ Buscar...          │ Buscar... [Capacidad ▼]         │ General | Parámetros | Uso | Pruebas  │
│ [AWS Bedrock]      │ [ ] Modelo A   Chat    No verif │ ID externo, capacidad, config         │
│ [OpenAI]           │ [ ] Modelo B   Emb.    ...      │ Habilitado ≠ disponible               │
│ [Ollama local]     │ ...                            │ [Guardar cambios]                     │
│ [+ Registrar]      │ [Actualizar catálogo]          │ [Probar modelo]                       │
├────────────────────┴────────────────────────────────┴────────────────────────────────────────┤
│ Rutas por función [Configurar]       Prueba explícita [Abrir pruebas]                        │
└──────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 6 DIÁLOGOS — cada uno un objetivo

| Modal | Disparador | Campos/acciones | Condición crítica |
|---|---|---|---|
| `ProviderEditorDialog` | Añadir/Editar proveedor | providerType, alias, authMethod, credentialRef, endpoint, región, timeout | Nunca ver o persistir secretos en frontend; registro ≠ conectado |
| `ModelRegisterDialog` | Registrar modelo | proveedor, external ID, alias, capacidades declaradas | capacidades `unverified` hasta prueba; IDs validados |
| `ModelDiagnosticDialog` | Probar proveedor/modelo | elección de prueba, parámetros, confirmación de posible coste, receipt | operación explícita; sin API real, `NOT_IMPLEMENTED`, nunca `PASS` simulado como real |
| `ModelRoutingDialog` | Gestionar rutas | purpose, primario, lista ordenada fallback, scope | cross-provider data egress requiere política/consentimiento; no fallback silencioso |
| `DependencyInspectorDialog` | Dep./desactivar | proyectos/agentes/rutas/ejecuciones afectados, links | consulta backend; las cifras demo se etiquetan mock |
| `DestructiveChangeDialog` | desactivar con impacto/eliminar | resumen, confirmación y propuesta de reasignación | bloquear hasta preflight/impacto y revisión de configuración |

## Estados independientes
`registered`, `configured`, `enabled`, `availability(unverified/available/degraded/unavailable; checkedAt; TTL)`, `defaultFor[]`, `integrationEvidence`. La UI jamás mezcla habilitado y disponible en un solo badge.

## Contratos de interacción
- **Guardar:** validar esquema, mostrar diff, confirmar alcance, `expectedRevision`, presentar conflictos `409` (o equivalente del servicio real) sin sobrescribir.
- **Descubrir modelos:** no alterar activación, rutas ni permisos. Si una API no puede descubrir, registrar manualmente sin inventar capabilities.
- **Probar conexión:** una operación (potencialmente externa) separada, con identidad, aviso de posible cargo y resultado verificable.
- **Habilitar/deshabilitar:** acción de configuración, no permiso de ejecución; antes de deshabilitar inspeccionar dependencias.
- **Seleccionar modelo:** mantener pestaña detalle e identificar qué valores son heredados o personalizados.
- **Eliminar proveedor:** preflight de rutas, agentes, proyectos, activaciones y pruebas pendientes; DENY sin tratamiento de dependencias.
- **Rutas:** `chat, reasoning, code, rag, embedding, vision` como purposes iniciales; elegir sólo modelos elegibles por capacidades y política; fallbacks sólo explícitos.
- **Credenciales:** sólo referencias opacas, no mostrar clave previa ni recuperar secreto en pantalla.

## Pruebas negativas indispensables
Deshabilitado pero seleccionado como default; sin credencial; disponibilidad expirada; descubrir no soportado; parámetro no soportado; permiso de egress cloud ausente; fallback local→cloud sin autorización; cambiar modelo con agentes activos; conflicto de revision; error de proveedor; fallo de prueba facturable; eliminación con dependencias; modelo eliminado mientras se edita; descarga de catálogo parcial.

**Aceptación:** Un usuario puede gestionar un catálogo simulado y comprender exactamente qué está probado; al conectar backend, API real es única fuente de estado. No se afirma ni simula autorización material desde UI.
