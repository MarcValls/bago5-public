# PACK 00 — Contexto, contratos y freeze

**Fuentes obligatorias:** `BAGO5-CONFIG-001_DOMAIN_CONTRACT_v0.1.md` (propietarios) y `BAGO5-CONFIG-002_EFFECTIVE_RESOLUTION_v0.1.md` (resolución tipada). Estas copias conservan el diseño previo; **no se modifican** en la implantación UI.

## Intención estable
- Construir una interfaz gráfica que **materialice y permita observar** configuración y funcionamiento comprobable; ninguna cifra de mock equivale a evidencia.
- La UI refleja el backend; no se erige en autoridad de autorización, permisos, disponibilidad o credenciales.
- Cada entidad canónica tiene **un único owner**: global registra, proyecto selecciona/restringe, agente expresa preferencias/capacidades solicitadas, conversación permite overrides temporales; ejecución autoriza por su frontera.
- La prioridad P0 corresponde a CFG-02, CFG-03, CFG-04 y CFG-05; CFG-01/06/07 son P1 de pantalla completa, pero persistencia segura y separación de datos son P0.
- BAGO5 es un sistema nuevo, no una obligación de usar código del BAGO histórico; reutilizar componentes existentes del repo receptor tras inspección y verificación de compatibilidad.
- UX: topbar de una sola línea, Windows/minimalista, esquinas casi rectas, baja carga cognitiva, paneles consistentes, diálogos para acciones compuestas/críticas, nunca modales anidados.

## Inventario a realizar ANTES de Codex escribir
1. `git status`, rama, SHA; stack real y comandos de build/test; rutas y pantallas ya presentes.
2. Componentes y estilos reutilizables; inventariar formularios, navegación, modales y catálogos, detectar duplicados.
3. Endpoints, servicios/owners, esquemas reales, autorización, integración de credenciales, evidencia y mocks existentes.
4. Marcar `REUSE / ADAPT / BUILD / HOLD` por pieza. Proteger funcionalidades, pruebas y rutas ya existentes.
5. Determinar alcance permitido: primero frontend visual con mocks marcados; después conectar sólo endpoints reales o implementar contrato backend en una tarea separada autorizada.

## Estado contractual
`BAGO5-CONFIG-001`: DESIGN FROZEN; implementación NO_VERIFICADA. `BAGO5-CONFIG-002`: SPECIFIED; implementación NOT_RUN. Este pack NO promueve esos estados.
