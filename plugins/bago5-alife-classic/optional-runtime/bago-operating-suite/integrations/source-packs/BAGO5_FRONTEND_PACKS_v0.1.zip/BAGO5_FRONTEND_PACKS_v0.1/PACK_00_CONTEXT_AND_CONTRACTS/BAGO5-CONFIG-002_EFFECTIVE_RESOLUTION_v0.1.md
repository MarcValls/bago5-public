# BAGO5 — Effective Configuration Resolution Contract

| Campo | Valor |
|---|---|
| Identificador | `BAGO5-CONFIG-002` |
| Versión | `0.1` |
| Fecha | `2026-10-13` |
| Autor del documento | Especificación de arquitectura BAGO5, preparada por OpenAI / ChatGPT |
| Estado | **SPECIFIED / IMPLEMENTATION NOT_RUN** |
| Depende de | [`BAGO5-CONFIG-001_DOMAIN_CONTRACT_v0.1.md`](BAGO5-CONFIG-001_DOMAIN_CONTRACT_v0.1.md) |
| Motor | `EffectiveConfigurationResolver` |

> El resolver **no es un sistema de autorización**, ni un router que llama a proveedores, ni un ejecutor. Produce un resultado determinista y explicable a partir de un snapshot validado de configuración y restricciones. La autorización del efecto material se valida después, mediante `AuthorizationService` y `ExecutionGateway`.

## 1. Responsabilidad, límites y garantías

El resolver determina para una operación concreta: preferencias efectivas, opciones elegibles, límites técnicos, fuentes referenciables, obligaciones de autorización y **procedencia de cada decisión**.

**Sí hace:**

- Resolver por ámbito y por campo, con reglas de combinación explícitas.
- Aplicar políticas restrictivas y devolver `BLOCKED` si no hay opción válida.
- Calcular el modelo candidato y fallbacks permitidos (sin invocarlos).
- Explicar valor, origen, revisiones, restricciones y rechazos.
- Producir una huella estable de la resolución, apta para correlacionar receipts.

**No hace:**

- Leer ficheros externos, indexar documentos o incorporar rutas automáticamente.
- Invocar LLM, testear conexión, gastar tokens o probar credenciales.
- Emitir grants o aprobar accesos y transferencias de datos.
- Ejecutar herramientas o reservar recursos materiales.
- Persistir cambios o duplicar configuración entre ámbitos.

**Propiedades obligatorias:** *pureza respecto al snapshot*, determinismo, fail-closed ante ausencia de restricciones críticas, no exposición de secretos, resultados auditables, comparación de revisiones y ausencia de efectos por lectura.

## 2. Arquitectura y flujo

```text
            CONFIGURATION STORE (canonical records, revisions)
                              │
            snapshot consistente + esquema validado
                              ▼
                EffectiveConfigurationResolver
                  ├─ campo → regla tipada
                  ├─ límites globales / proyecto
                  ├─ preferencias agente / conversación
                  ├─ candidatos + dependencias
                  └─ explicación + fingerprint
                              │
            ┌─────────────────┴──────────────────┐
            ▼                                    ▼
      RESOLVED / BLOCKED                EVIDENCE (sin secretos)
            │
            ▼
   AuthorizationService.validateGrant (vigencia en el instante del efecto)
            │
            ▼
  ExecutionGateway / Sandbox / Provider Adapter
            │
            ▼
       Receipt + Trace + Eval
```

La UI utiliza las mismas reglas para la **previsualización**, pero la ejecución nunca confía exclusivamente en una previsualización previa. Debe revalidar contexto, revisiones, permisos y obligaciones críticas.

## 3. Interfaces lógicas

### 3.1 `ResolutionRequest`

```yaml
request_id: string
principal_id: string
purpose: chat|reasoning|code|rag|embedding|vision|tool_execution|other
project_id: string|null
agent_id: string|null
conversation_id: string|null
operation: string               # p. ej. model.invoke, filesystem.read
resource_references: [string]    # identificadores canónicos, no acceso implícito
data_classification: public|internal|restricted|secret|unknown
requested_model_id: string|null
requested_parameters: object
requested_capabilities: [string]
requested_resource_limits: object
expected_config_revision_vector: object|null
```

El servicio que construye la petición ya ha autenticado al principal y validado las relaciones de pertenencia `conversation → project`, `agent binding → project` y `principal → scope`. Si no puede verificarse una de estas relaciones, la resolución resulta `BLOCKED`.

### 3.2 `ConfigurationSnapshot`

```yaml
snapshot_id: string
read_at: datetime
revision_vector: object          # entidad canónica → revisión
schemas: object                  # dominio → versión
entries:
  user_preferences: object|null
  global: object
  project: object|null
  agent: object|null
  conversation: object|null
references:
  model_registry: object
  integration_registry: object
  tool_registry: object
  context_catalog: object|null
restrictions:
  global_security: object
  project_security: object|null
  global_execution: object
  project_execution: object|null
availability_snapshot: object|null
```

`AvailabilitySnapshot` es información **ya observada** con hora y caducidad. El resolver no realiza sondeos de red. La verificación de conectividad en vivo se hace por una acción independiente autorizada.

### 3.3 `EffectiveConfigurationResult`

```yaml
resolution_id: string
request_id: string
status: resolved|blocked
selected_model_id: string|null
eligible_fallback_model_ids: [string]
effective_values: object
applied_restrictions: [object]
blocked_overrides: [object]
required_authorizations: [object]  # obligaciones; nunca aprobaciones
provenance:
  fields: object                  # campo → fuentes ordenadas + regla
  revision_vector: object
snapshot_id: string
resolved_at: datetime
fingerprint: string               # SHA-256 de proyección canónica sin secretos
reason_codes: [string]
```

`resolved` significa que la **configuración** es coherente. **No significa que esté autorizada la operación material.** `required_authorizations` describe permisos que deberán comprobarse en la frontera de ejecución; nunca es un grant.

## 4. Reglas tipadas por clase de campo

No se permite un merge ciego de diccionarios. Cada clave posee una **regla declarada en esquema**.

| Clase | Regla | Ejemplo |
|---|---|---|
| `OWNER_ONLY` | Sólo propietario canónico escribe; otros ámbitos referencian | Credenciales, altas de proveedores, fuentes |
| `PREFERENCE` | Prioridad permitida: global → proyecto → agente → conversación | Modelo preferido, temperatura, pantalla inicial cuando aplique |
| `ALLOWLIST` | Intersección de conjuntos admitidos (no unión) | Modelos elegibles, ejecutores permitidos |
| `MAX_BOUND` | Máximo efectivo = mínimo de techos aplicables | Timeout, memoria, reintentos |
| `MIN_BOUND` | Mínimo efectivo = máximo de suelos aplicables | Nivel de registro requerido (si se define orden válido) |
| `REQUIRE_ALL` | Todas las obligaciones aplicables deben satisfacerse | Sandbox obligatorio, trazabilidad obligatoria |
| `PROHIBIT_ANY` | Cualquier prohibición aplicable bloquea | Transferencia a cloud prohibida |
| `REFERENCE` | Resolver identificador contra registro canónico; verificar pertenencia | Modelo, fuente, herramienta, integración |
| `EXPLICIT_GRANT` | Sólo `AuthorizationService` puede conceder autoridad; el resolver informa obligación | Lectura/escritura/ejecución |
| `VOLATILE_STATUS` | Resultado informativo de verificación, con TTL | Salud del proveedor, disponibilidad |

Las reglas se definen por **dominio y campo**, no de manera global para todas las claves. Un campo sin regla reconocida produce `CONFIG_SCHEMA_UNKNOWN` o se ignora exclusivamente si el esquema declara que es opcional y no crítico.

### 4.1 Ausencia, `null` y colección vacía

- Campo **ausente**: no existe override; puede heredarse si su esquema lo permite.
- Campo `null`: sólo válido si el esquema declara `nullable`; nunca significa automáticamente «sin restricciones».
- `[]` en una allowlist explícita: **ningún elemento permitido**, no «todos».
- Política global obligatoria ausente o caducada: `BLOCKED / REQUIRED_POLICY_MISSING`.
- Preferencia ausente: usar valor heredable declarado o `NO_ELIGIBLE_DEFAULT` si no hay opción.

### 4.2 Orden de preferencias

```text
  GLOBAL DEFAULT
       ↓ (si el campo permite override)
  PROJECT PREFERENCE
       ↓ (si el campo permite override)
  AGENT PREFERENCE
       ↓ (si el campo permite override)
  CONVERSATION OVERRIDE
       ↓
  VALIDACIÓN DE RESTRICCIONES Y REFERENCIAS
       ↓
  VALOR EFECTIVO O BLOCKED
```

Una preferencia de un nivel inferior no anula una prohibición superior. Los errores de rango o capacidad **no se corrigen silenciosamente**: se rechaza el override inválido con `OVERRIDE_EXCEEDS_BOUND` o el error tipado correspondiente. Sólo se permite un fallback si está expresamente configurado y también supera las restricciones.

## 5. Resolución de modelos y rutas

La selección de modelo es una preferencia sometida a filtros, no un permiso.

**Orden:**

1. Cargar ruta/purpose global y la variante de proyecto si existe.
2. Construir candidatos explícitos: override válido de conversación → preferencia de agente → principal de proyecto → principal global → fallback(s) expresamente configurado(s), eliminando duplicados y conservando orden.
3. Exigir `provider.enabled && model.enabled`, IDs existentes y binding del proyecto.
4. Exigir capacidades necesarias (`tool_use`, `vision`, `embedding`, etc.) y parámetros admitidos.
5. Exigir que el modelo figure en las allowlists efectivas.
6. Validar destino del proveedor frente a clasificación de datos y restricciones de transferencia. Si requiere autorización adicional, devolver obligación y **no seleccionar como ejecutable** hasta que la autorización exista.
7. Usar estado/TTL para determinar elegibilidad operacional. Salud no verificada no se convierte en «funciona»: requiere prueba o decisión explícita de invocación con permiso; para llamadas con comprobación previa obligatoria, bloquear si el TTL no es válido.
8. Devolver primario y fallbacks elegibles más explicación; no llamar al modelo.

El fallback sólo ocurre durante una invocación posterior mediante política explícita. La transición `local → cloud` o `proveedor A → B` se vuelve a evaluar contra la política de datos y autorización; nunca se deduce que es válida porque el segundo modelo está registrado.

### Ejemplo 1 — selección heredada

```yaml
input:
  global_route: {purpose: chat, primary: model-A}
  project_route: {purpose: chat, primary: model-B}
  agent_preference: model-C
  conversation_override: null
  global_allowed: [model-A, model-B, model-C]
  project_allowed: [model-B, model-C]
  model_C: {enabled: true, capabilities: [chat], health: available}
output:
  status: resolved
  selected_model_id: model-C
  provenance: {selected_model_id: agent_preference}
```

### Ejemplo 2 — agente pide modelo prohibido

```yaml
input:
  project_allowed: [model-B]
  agent_preference: model-C
  declared_fallbacks: []
output:
  status: blocked
  reason_codes: [MODEL_NOT_ALLOWED]
```

No se sustituye silenciosamente por `model-B` si el usuario/agente exigió específicamente `model-C` y no hay fallback explícito.

### Ejemplo 3 — fallback local a cloud

```yaml
input:
  primary: ollama-local
  fallback: bedrock-cloud
  data_classification: restricted
  cloud_transfer_policy: prohibited
output:
  status: resolved                # solo puede seleccionarse local si disponible
  selected_model_id: ollama-local
  eligible_fallback_model_ids: []
  blocked_overrides: [{candidate: bedrock-cloud, reason: DATA_EGRESS_DENIED}]
```

Si falla el local, la ejecución da fallo controlado; no sale información restringida a Bedrock.

## 6. Resolución de permisos, contexto y recursos

### 6.1 Fuente de proyecto

`source.registered` y `source.indexed` no son permisos. Para usarla se necesita vinculación al proyecto, acceso del principal, autorización sobre el recurso y política de transferencia compatible con la operación.

```text
Fuente registrada + ámbito correcto + restricción de proyecto
    ≠ permiso
Operación concreta + intención + grant vigente del principal
    → AuthorizationService.validateGrant
    → ExecutionGateway / adapter
```

La fuente `C:\repo` mencionada en un mensaje no se añade a `ProjectContextCatalog` por detección textual. Una petición expresa «audita esta carpeta» activa el **flujo de solicitud de permiso**, no el acceso automático.

### 6.2 Autorización y TOCTOU

El resultado del resolver incorpora obligaciones, pero **no** emite tokens ni toma decisiones definitivas. `ExecutionGateway` debe validar el grant vigente, el principal, la operación, el recurso y las restricciones **en el momento del efecto**, incluso si una resolución anterior era válida. Ante revocación o expiración entre resolución y ejecución: `DENY` + receipt de denegación.

### 6.3 Límites técnicos

```text
max_duration_effective = min(global, project?, agent_requested?, grant_limit?)
max_retries_effective  = min(global, project?, agent_requested?)
allowed_executor_profiles = intersection(global, project?, grant_restrictions?)
required_sandbox_features = union(global_required, project_required, grant_required)
```

Las configuraciones de proyecto y las peticiones del agente que superen el techo global son **inválidas**, no se ajustan silenciosamente: `OVERRIDE_EXCEEDS_BOUND`. El cálculo `min(...)` sólo se realiza con entradas previamente validadas. `agent_requested` se interpreta como petición de límite más estricto cuando lo hay; no puede elevar máximos. Si el backend no puede imponer una característica requerida (`network=deny` a nivel OS, memoria, filesystem), el resultado debe ser `BLOCKED / EXECUTOR_CAPABILITY_MISSING` para la operación que la exija, no ejecución degradada silenciosamente.

## 7. Pseudocódigo de referencia

```python

def resolve(request: ResolutionRequest, snapshot: ConfigurationSnapshot) -> EffectiveConfigurationResult:
    # Función pura: sin red, filesystem, modelos, secret store ni escrituras.
    assert_snapshot_consistent(snapshot)
    assert_known_schema_versions(snapshot)
    assert_principal_scope_bindings(request, snapshot)  # bindings proporcionados y verificados
    assert_required_global_policies_present(snapshot)

    results = {}
    trace = {}
    blockers = []
    obligations = []

    for field in schema.fields_for(request.operation, request.purpose):
        candidates = field.read_scoped_values(snapshot, request)
        value, sources, violations = field.apply_typed_rule(candidates)
        trace[field.name] = {"rule": field.rule, "sources": sources}
        if violations:
            blockers.extend(violations)
        else:
            results[field.name] = value

    model_result = choose_eligible_models(request, snapshot, results)
    blockers.extend(model_result.blockers)
    obligations.extend(model_result.authorization_requirements)

    obligations.extend(derive_material_effect_requirements(request, snapshot, results))
    # Los grants NO se validan ni emiten aquí.

    status = "blocked" if blockers else "resolved"
    return redact_and_fingerprint(status, results, model_result, trace, blockers, obligations, snapshot)
```

El pseudocódigo define orden y límites; no es código de producción ni promete disponibilidad de librerías/servicios.

## 8. Consistencia, invalidación y evidencia

### Snapshots y revisiones

- Una resolución se realiza sobre un **snapshot consistente** de registros canónicos. Si hay lectura fragmentada/inconsistente, `REVISION_CONFLICT`.
- Se incluye `revision_vector` por entidad referenciada; un cambio relevante obliga a resolver de nuevo antes de ejecutar.
- La selección de modelo y las preferencias pueden usar snapshot de sesión si no cambian; autorizaciones, revocaciones y restricciones críticas siempre se validan en la frontera del efecto.
- Caché de resultados permitida sólo con clave que incorpore propósito, scopes, identificadores, clasificación de datos, versiones y política; no almacena secretos ni sustituye checks de grants.

### Observabilidad de la resolución

Cada resolución produce una proyección estructurada redactada:

```yaml
resolution_id: res-0001
status: resolved
selected_model_id: model-local-01
sources:
  selected_model_id: [global:rev12, project:rev7, agent:rev3]
applied_restrictions: [project_model_allowlist, global_data_egress]
blocked_overrides: []
required_authorizations: [filesystem.read] # obligaciones pendientes
fingerprint: sha256:<hash>
```

Prohibido guardar tokens, API keys, prompts secretos, datos de documentos, credenciales, rutas sensibles innecesarias o información personal íntegra en el trace. Usar identificadores opacos cuando sea suficiente. El `fingerprint` se calcula sobre una **proyección canónica estable**, que excluye `resolved_at`, `resolution_id`, credenciales y cualquier dato volátil irrelevante; incluye el vector de revisiones y la política aplicada. El hash sólo acredita identidad de esa proyección, no prueba por sí mismo que la ejecución ocurrió.

## 9. API lógica (sin transporte fijado)

| Operación | Entrada | Salida | Efectos |
|---|---|---|---|
| `resolveEffectiveConfiguration` | Request + snapshot | Result | Ninguno |
| `explainEffectiveValue` | Resolution ID + key | Procedencia + regla | Ninguno |
| `previewConfigChange` | Change proposal | Impact + diff | Ninguno |
| `validateConfigChange` | Change proposal + expected revision | Validaciones | Ninguno |
| `commitConfigChange` | Propuesta validada + revisión | Nueva revisión | Escritura persistente, autorizada |
| `checkGrantAtEffectBoundary` | Principal + grant + recurso + operación | ALLOW / DENY / HUMAN | Consulta de autoridad vigente (fuera del resolver) |
| `executeAuthorizedOperation` | Request + permit + resolved config | Receipt | Efecto material (fuera del resolver) |

Para impedir carreras, `commitConfigChange` debe validar atómicamente su revisión, aunque ya se haya utilizado `validateConfigChange`.

## 10. Código de errores y comportamiento

| Código | Ejemplo | Resultado |
|---|---|---|
| `REQUIRED_POLICY_MISSING` | Falta política global de seguridad | `BLOCKED` |
| `CONFIG_SCHEMA_UNKNOWN` | Campo o versión crítica desconocida | `BLOCKED` |
| `REVISION_CONFLICT` | Snapshot o commit con revisión obsoleta | Reintentar lectura/validación, nunca sobreescribir |
| `SCOPE_BINDING_INVALID` | Agente no vinculado al proyecto | `BLOCKED` |
| `MODEL_NOT_REGISTERED` | Modelo preferido sin catálogo | `BLOCKED` salvo fallback explícito |
| `MODEL_DISABLED` | Modelo deshabilitado | `BLOCKED` salvo fallback elegible |
| `MODEL_NOT_ALLOWED` | No está en allowlist de proyecto | `BLOCKED` salvo fallback elegible |
| `MODEL_CAPABILITY_MISMATCH` | Uso de visión con modelo solo texto | `BLOCKED` salvo fallback elegible |
| `MODEL_PARAMETER_UNSUPPORTED` | Parámetro inválido para el modelo | `BLOCKED`, no silenciosamente corregido |
| `MODEL_HEALTH_UNVERIFIED` | Política requiere check fresco | `BLOCKED` hasta comprobación explícita |
| `DATA_EGRESS_DENIED` | Fuente restringida → cloud prohibido | Rechazar el destino |
| `NO_ELIGIBLE_MODEL` | Ningún candidato cumple políticas | `BLOCKED` |
| `OVERRIDE_EXCEEDS_BOUND` | Configuración inferior intenta ampliar límite global | `BLOCKED` (sin clamp silencioso) |
| `EXECUTOR_CAPABILITY_MISSING` | Aislamiento requerido no implementado | `BLOCKED` |
| `GRANT_REQUIRED` | Se necesita autorización por intención | Obligación pendiente, no `ALLOW` |
| `GRANT_REVOKED` | Revocación antes del efecto | Denegación en ExecutionGateway |

## 11. Pruebas de conformidad del resolver

| ID | Tipo | Escenario | Resultado esperado |
|---|---|---|---|
| RES-T01 | Positiva | Herencia global→proyecto→agente válida | Origen exacto y modelo correcto |
| RES-T02 | Positiva | Override de conversación permitido | Sólo afecta a esa conversación |
| RES-T03 | Negativa | Modelo global deshabilitado | `MODEL_DISABLED` |
| RES-T04 | Negativa | Modelo fuera de allowlist de proyecto | `MODEL_NOT_ALLOWED` |
| RES-T05 | Negativa | Modelo sin capacidad requerida | `MODEL_CAPABILITY_MISMATCH` |
| RES-T06 | Negativa | Parámetro no soportado | `MODEL_PARAMETER_UNSUPPORTED` |
| RES-T07 | Negativa | Local falla, cloud prohibido para dato restringido | Sin fallback cloud |
| RES-T08 | Negativa | Fuente mencionada pero no registrada | No acceso ni registro implícito |
| RES-T09 | Negativa | Fuente registrada pero sin grant | Sólo `GRANT_REQUIRED`, no lectura |
| RES-T10 | Negativa | Principal fuera de proyecto | `SCOPE_BINDING_INVALID` |
| RES-T11 | Negativa | Política global obligatoria ausente | `REQUIRED_POLICY_MISSING` |
| RES-T12 | Negativa | Config crítica con esquema desconocido | `CONFIG_SCHEMA_UNKNOWN` |
| RES-T13 | Negativa | Límite proyecto > global | `OVERRIDE_EXCEEDS_BOUND`, no clamp silencioso |
| RES-T14 | Negativa | Sandbox requerido no implementado | `EXECUTOR_CAPABILITY_MISSING` |
| RES-T15 | Negativa | Estado proveedor caducado con check fresco requerido | `MODEL_HEALTH_UNVERIFIED` |
| RES-T16 | Negativa | Se revoca grant entre resolver y efecto | Efecto denegado por gateway |
| RES-T17 | Negativa | Modificar configuración mientras se resuelve | `REVISION_CONFLICT` o snapshot íntegro |
| RES-T18 | Negativa | Se intenta resolver campo sin regla | `CONFIG_SCHEMA_UNKNOWN` |
| RES-T19 | Negativa | Allowlist explícita `[]` | Ningún modelo permitido |
| RES-T20 | Negativa | Fallback no declarado | No reemplazar candidato solicitado |
| RES-T21 | Positiva | Dos resoluciones con mismo snapshot/request | Misma proyección canónica/fingerprint |
| RES-T22 | Negativa | Inspección de resultado/trace | Sin secretos |
| RES-T23 | Negativa | Solicitud de resolver provoca llamadas a modelo | Cero invocaciones/red/efectos |
| RES-T24 | Negativa | Snapshot de grant antiguo tras revocación | No habilita efecto |
| RES-T25 | Positiva | Explain de un override rechazado | Motivo, ámbito y regla visibles |
| RES-T26 | Negativa | Proyecto habilita modelo globalmente prohibido | `BLOCKED` |
| RES-T27 | Positiva | Reintentos y timeout restrictivos | Límites efectivos correctos |
| RES-T28 | Negativa | Conversation ID no pertenece al project ID | `SCOPE_BINDING_INVALID` |

**Criterio GO (futuro):** todos los tests positivos/negativos PASS, `P0=0`, `P1=0`, receipt de conformidad con commit, entorno, comando, resultados y evidencia. Hasta ejecutarse: **NO_GO para declarar implementación VERIFIED**.

## 12. Dependencias y secuencia de construcción

```text
BAGO5-CONFIG-001 congelado
    ↓
Tipar schema/field rules + scopes
    ↓
Implementar ConfigurationSnapshot consistente
    ↓
Implementar EffectiveConfigurationResolver como función pura
    ↓
Resolver modelos, límites, contexto y obligaciones de autorización
    ↓
Implementar explicaciones/procedencia y revisión
    ↓
Pruebas RES-T01...RES-T28 (positivas y negativas)
    ↓
Acoplar vista previa de UI y validación en ExecutionGateway
    ↓
CRIT-BAGO5-CONFIG-002
```

**Fuera de alcance inmediato:** almacenar secretos, invocar modelos, registrar fuentes, emitir grants, elegir librería React, migrar BAGO antiguo o desplegar nube. Cada responsabilidad conserva su propietario del contrato `BAGO5-CONFIG-001`.

## 13. Dictamen

`SPEC COMPLETE → IMPLEMENTATION NOT_RUN → CONFORMANCE NOT_RUN`

El resolver es el mecanismo común que permite que Configuración Global, Proyecto, Agente y Conversación compartan reglas y fuentes de verdad sin duplicarse. **La configuración resuelta describe qué se podría usar; la autorización vigente determina qué se puede hacer realmente.**
