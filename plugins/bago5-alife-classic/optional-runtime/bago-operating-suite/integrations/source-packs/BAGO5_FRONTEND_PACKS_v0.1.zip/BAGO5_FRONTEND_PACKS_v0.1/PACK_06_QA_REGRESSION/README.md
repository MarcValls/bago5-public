# PACK 06 — Preservación funcional, accesibilidad y pruebas Playwright

## Baseline obligatorio antes de cambiar
- Rama y SHA; capturas desktop 1440x900, tablet 1024x768 y móvil 390x844; inventario de controles existentes.
- Pruebas que YA pasan y flujos existentes. Prohibido asumir que añadir control mantiene elementos anteriores.
- Capturar árbol accesible (roles/names) además de screenshots. Diferenciar cambios intencionados y regresiones.

## Matriz de pruebas — objetivo (NOT_RUN)
| ID | Caso | Esperado |
|---|---|---|
| UI-001 | App sin proveedores | empty-state y Añadir, sin contadores inventados |
| UI-002 | Seleccionar proveedor | sólo cambia la lista central |
| UI-003 | Seleccionar modelo | ficha adecuada, atributos correctos |
| UI-004 | Activar/desactivar | independencia habilitado/disponible; backend recibe cambio al guardar |
| UI-005 | Guardar con revisión obsoleta | aviso de conflicto y diff, sin sobrescribir |
| UI-006 | Registrar proveedor sin credenciales | sin secretos en DOM persistente, estados no verificados |
| UI-007 | Prueba facturable sin confirmación | no se inicia; ofrece aviso de coste |
| UI-008 | Fallback local→cloud con datos restringidos | DENY y razón legible |
| UI-009 | Eliminar con dependencias | bloquear y mostrar inspector |
| UI-010 | Modelo embeddings seleccionado | no mostrar parámetros incompatibles |
| UI-011 | Proyecto configura ruta | no cambia global/otro proyecto |
| UI-012 | Agente override bloqueado | muestra procedencia y política |
| UI-013 | Sin backend / API error | estado claro, sin falsa conexión saludable |
| UI-014 | Reabrir modal teclado | foco inicial, Escape, retorno foco, no modales anidados |
| UI-015 | 390px de ancho | cero desbordamiento horizontal; navegación completa |
| UI-016 | Restaurar copia | confirmación y preflight; nunca sólo un save |
| UI-017 | Revoke grant | UI delega; no revocación simulada declarada real |
| UI-018 | Ver fuente de proyecto | registro ≠ permiso; sin acceso automático |
| UI-019 | Intercambiar rutas | no cambia proveedor ni credenciales |
| UI-020 | Habilitar modelo nuevo | no implica tool authorization |
| UI-021 | Smoke todas las 7 screens | título, paneles, estado, navegación conservados |
| UI-022 | Comparar con baseline | no desaparecen controles, elementos ni acciones preexistentes |

## Configuración de pruebas propuesta
- Usar Playwright si ya existe; instalarlo si el repositorio lo autoriza y si no duplica herramientas.
- `screenshot` y `accessibility snapshot` (o rol/nombre vía locators) en pasos críticos.
- No aprobar sólo por `pixel diff`: comparar DOM, roles, nombres, rutas, respuesta de interacciones y contratos.
- Registrar evidencia `evidence/frontend/<commit>/<testid>/{before,after,trace,report}` (formato final según repo).
- Tests positivos + negativos + regresión diferencial. `PASS/FAIL/NOT_RUN` nunca inferidos.

## Gate de aprobación
`P0=0`, `P1=0`, invariantes 001/002 comprobados, 7 pantallas navegables, 6 modales de CFG-02 funcionales, no hay llamadas facturables implícitas, secretos seguros, responsive y accesibilidad revisados, rutas y comportamientos previos conservados.

Si no se ha ejecutado el navegador real: **NO GO para VERIFIED visual**. Un mock puede ser DEMOSTRABLE como maqueta únicamente.
