# PACK 07 — Prompts secuenciales para Codex / VS Code

Copia **uno cada vez** al chat de Codex con el proyecto real abierto. Adjunta / indica la ruta local del pack extraído. No pegar todas las fases de golpe.

## PROMPT 00 — INSPECCIÓN Y FREEZE
```text
Trabaja sobre el repositorio BAGO5 actualmente abierto. Lee primero README_INICIO.md del pack BAGO5_FRONTEND_PACKS_v0.1, PACK_00 y los contratos originales BAGO5-CONFIG-001/002. No escribas código todavía. Haz inventario del stack real, pantallas presentes, rutas, stores, APIs, schemas, diseño actual, tests, capturas y SHA de referencia. Clasifica cada pieza REUSE/ADAPT/BUILD/HOLD. Informa incompatibilidades de contrato, duplicados, riesgos y define una vertical mínima observable sin romper nada. Entrega un plan de ficheros y criterios PASS/FAIL. Estado: INSPECTED, NOT IMPLEMENTED.
```

## PROMPT 01 — SHELL Y SISTEMA VISUAL
```text
Implementa únicamente la shell de configuración según PACK_01, reutilizando el stack y los componentes existentes. Topbar una línea, sidebar, siete rutas, design tokens, tres estados loading/empty/error, responsive y accesibilidad. No tocar backend ni introducir stores duplicados. Ejecuta build y tests existentes; genera screenshots desktop/móvil si Playwright está disponible. Reporta cambios y regresiones; no declares verificado lo no ejecutado.
```

## PROMPT 02 — PROVEEDORES Y MODELOS EN MOCK
```text
Implementa CFG-02 según PACK_02 con tres columnas, búsqueda/filtros, ficha de modelo, enrutamiento, 6 diálogos y estado ortogonal registered/enabled/available/default. Usa sólo fixtures explícitamente etiquetados DEMO/MOCK, sin claves ni peticiones externas. No permitas que el mock devuelva PASS de conectividad ni que guarde permisos de ejecución. Incluye pruebas de interacciones, teclado, responsive y capturas. Preserva pantalla/shell ya implementadas.
```

## PROMPT 03 — CONECTAR CFG-02 A SERVICIO REAL
```text
Inspecciona contratos backend y owners del repositorio antes de tocar API. Aplica PACK_05, reutiliza servicios reales si existen y crea adaptador de frontend sin inventar rutas REST. Si falta contrato backend, prepara un gap report y deja la vista MOCK rotulada; NO construyas endpoints sin autorización. Implementa save con optimistic concurrency, preflight de impacto y errores tipados. Las pruebas de conexión/modelo requieren acción explícita con aviso de posible coste y receipt. Nunca colocar credenciales en frontend.
```

## PROMPT 04 — RESTO DE CONFIGURACIÓN GLOBAL
```text
Implementa CFG-01, CFG-03, CFG-04, CFG-05, CFG-06 y CFG-07 desde PACK_03 con componentes comunes y owner único por dominio. Los controles sin soporte real quedan read-only/NOT_IMPLEMENTED; sin simulación de operaciones de autoridad. Mantén distinciones SecurityPolicy vs AuthorizationService, ExecutionPolicy vs jobs, Storage vs Context. Añade pruebas por pantalla y verifica que CFG-02 conserva todas sus capacidades y controles.
```

## PROMPT 05 — PROYECTO, AGENTE Y CONFIGURACIÓN EFECTIVA
```text
Aplicar PACK_04 y contratos 001/002: proyecto guarda referencias y límites restrictivos, agente preferencias, conversación overrides temporales. Mostrar valor efectivo, origen y bloqueos; no usar merge genérico ni copiar provider records por ámbito. Si EffectiveConfigurationResolver backend todavía no existe, preparar contrato/adaptador read-only y render de ejemplo MOCK sin atribuir autorización a resolución. Tests negativos sobre overrides y aislamiento entre proyectos.
```

## PROMPT 06 — AUDITORÍA DIFERENCIAL Y VERTICAL DEMOSTRABLE
```text
Ejecuta PACK_06 al estado actual: inventario de capacidades antes/después, pruebas de regresión de componentes preexistentes, pruebas negativas, capturas visuales desktop/tablet/móvil, checks accesibles, prueba de instalación Windows (si disponible), evidencia de cambios y dictamen GO/NO GO. Construye una demo mínima que permita seleccionar proveedor y modelo, editar y guardar una ruta con evidencia de persistencia real si hay backend, o declararlo MOCK inequívocamente si no lo hay. No alteres los contratos FROZEN.
```

## PROMPT 07 — ENTREGAR CONTINUIDAD
```text
Actualiza PACK_09 con SHA, rama, componentes realmente IMPLEMENTADOS, tests PASS/FAIL/NOT_RUN, ruta de arranque exacta, screenshots, pendientes, P0/P1, siguientes acciones. Empaqueta sólo archivos necesarios y un README de instalación paso a paso. No reclames GO si hay regresiones o ausencia de pruebas críticas. Diferencia frontend mock DEMOSTRABLE de backend integrado VERIFIED.
```

## Condición global de cada fase
Siempre devuelve: `ARCHIVOS MODIFICADOS → REUTILIZACIÓN/ADAPTACIÓN → BUILD/TESTS con comando → CAPTURAS/EVIDENCIAS → REGRESIONES → ESTADO (PROPUESTO/IMPLEMENTADO/VERIFICADO/DEMOSTRABLE) → 1 SIGUIENTE PASO`.
