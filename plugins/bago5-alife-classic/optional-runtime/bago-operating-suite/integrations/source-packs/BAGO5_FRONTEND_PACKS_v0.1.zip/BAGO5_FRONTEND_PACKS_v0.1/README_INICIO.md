# BAGO5 — FRONTEND · PACK DE PACKS v0.1

**Destino:** implementación del frontend de configuración de **BAGO5**, un sistema nuevo. ADL puede comprobar el resultado de forma independiente, pero no es dependencia de runtime.

**Contenido:** diez subpacks autónomos, contratos canónicos BAGO5-CONFIG-001/002, maqueta HTML offline, fixtures de ejemplo, tipos propuestos, manual de arranque y prompts listos para Codex / VS Code.

**Semáforo de estado**
- `ESPECIFICADO`: arquitectura de UI, responsabilidades, transiciones, criterios de aceptación y prompts.
- `IMPLEMENTADO (MAQUETA)`: `PACK_08_PREVIEW_REFERENCES/preview.html` abre en navegador, con datos **simulados**, sin conexión a proveedores, secretos, servicios o sistemas de ejecución.
- `PASS (MOCK PREVIEW)`: smoke Playwright/Chromium de la maqueta (navegación, modales, altas ficticias y sin overflow a 1600/1024/390). Evidencia en `PACK_08_PREVIEW_REFERENCES/SMOKE_RESULTADO.md`.
- `NOT_RUN`: tests E2E del frontend futuro, conexión a backend real, rutas del proyecto de destino, build React/Vite y pruebas en Windows del repositorio receptor.
- `CONTRATOS FROZEN INTACTOS`: el trabajo de UI no modifica ni promueve los contratos congelados `BAGO5-CONFIG-001` y `BAGO5-CONFIG-002`. Verificar consistencia contra las copias adjuntas.

## Cómo usarlo — orden estricto

1. **Copia/descomprime** el ZIP en una carpeta de trabajo junto al repo BAGO5, no encima de `src/` ni del repositorio sin inspeccionarlo. Recomendado `C:\BAGO5\_handoffs\BAGO5_FRONTEND_PACKS_v0.1` (ajustar a ruta real).
2. Abre `PACK_08_PREVIEW_REFERENCES/preview.html` en el navegador. Es una referencia interactiva, **no un sistema productivo**. Comprueba estilo y navegación; el catálogo y los contadores son ficticios.
3. Abre `PACK_00_CONTEXT_AND_CONTRACTS/README.md` y los contratos 001/002. **No crear un segundo modelo de permisos ni un segundo registry.**
4. Lee los packs 01 → 06 como especificación y criterios de aceptación.
5. Copia **sólo un prompt cada vez** desde `PACK_07_CODEX_EXECUTION/PROMPTS_SECUENCIALES.md` a Codex con el repositorio de destino abierto. Codex debe inspeccionar el repo antes de escribir código.
6. Después de cada fase exige: lista de archivos, qué cambió, checks ejecutados/NO EJECUTADOS, evidencias, riesgos y GO/NO GO. No avances sobre regresiones P0/P1.
7. Usa `PACK_09_HANDOFF/ESTADO_Y_CONTINUIDAD.md` para registrar commit, decisiones y pruebas reales. Copia ese documento con el proyecto al cambiar de entorno.

## Orden de entrega (verticales verificables)

`BASELINE REAL → APP SHELL → CFG-02 PROVEEDORES/MODELOS (MOCK) → CFG-02 API REAL → CFG-01/03/04/05/06/07 → PROYECTO/AGENTE → IMPACTO/RESOLUCIÓN → QA VISUAL Y NEGATIVA → DEMO`.

No terminar toda la plataforma para hacer demostrable una pantalla. Cada vertical debe poder observarse, probarse y enseñarse con evidencias.

## Índice de subpacks

| Subpack | Para qué sirve | Estado |
|---|---|---|
| `PACK_00_CONTEXT_AND_CONTRACTS` | Baseline, decisiones, 001/002 originales y alcance | Especificado |
| `PACK_01_UX_SYSTEM_AND_SHELL` | Diseño Windows/minimalista, shell, responsive, accesibilidad | Especificado |
| `PACK_02_PROVIDERS_AND_MODELS` | Pantalla 3 columnas, rutas, modal, estados, acciones | Especificado |
| `PACK_03_SEVEN_GLOBAL_SETTINGS` | Fichas implementables CFG-01..07, ownership | Especificado |
| `PACK_04_PROJECT_AGENT_SCOPES` | Reglas de configuración Global/Proyecto/Agente/Chat | Especificado |
| `PACK_05_FRONTEND_API_AND_MOCKS` | Tipos TS y fixtures, contratos frontera, no inventar endpoints | Propuesto |
| `PACK_06_QA_REGRESSION` | Pruebas negativas, UX, Playwright y conservación | Especificado |
| `PACK_07_CODEX_EXECUTION` | Prompts numerados, gates, fases y comandos | Especificado |
| `PACK_08_PREVIEW_REFERENCES` | Preview HTML y referencia de estilo ilustrativa | Implementado (maqueta) |
| `PACK_09_HANDOFF` | Matriz de estados, trazabilidad, continuidad y aceptación | Especificado |

## Criterios globales de NO GO

- Acceso a recursos simplemente por registrarlos; activar proveedor/modelo implica permiso de herramienta.
- Proyectos o agentes duplican registros globales en lugar de guardar referencias/overrides tipados.
- Controles que afirman VERIFICADO/LIVE sin consulta real y evidencia.
- Acciones facturables al cargar vistas o pulsar guardar; se exige prueba explícita con confirmación cuando hay costes posibles.
- UI con controles de aislamiento, red o recursos que afirman imponer límites no soportados.
- Secretos en estado frontend persistente, logs o fixtures, incluso si aparecen ocultos visualmente.
- Pérdida de capacidades existentes por añadir un campo nuevo, un modal o una ruta.

**Recordatorio:** el sistema independiente de auditoría (ADL) puede verificar BAGO5; no debe ser integrado o exigido como dependencia funcional de este frontend.
