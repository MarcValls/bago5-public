# Ejecución práctica en Windows 10 / Codex / VS Code

1. Descomprime `BAGO5_FRONTEND_PACKS_v0.1.zip` en un directorio separado del repo de BAGO5.
2. Ejecuta `git status` y `git rev-parse HEAD` dentro del repo; copia resultados en `PACK_09_HANDOFF/ESTADO_Y_CONTINUIDAD.md`.
3. Abre `PACK_08_PREVIEW_REFERENCES/preview.html` con doble clic: no requiere servidor, npm ni servicios de pago.
4. Abre el repo BAGO5 en VS Code/Codex, da acceso al **pack extraído** como documentación de solo lectura.
5. Envía PROMPT 00 y espera el inventario antes de permitir cambios.
6. Envía PROMPT 01; espera build/tests/capturas. Continúa fase por fase.
7. Si se identifica React+Vite: ejecutar **los comandos que el repositorio indique**, habitualmente `npm ci`, `npm run dev`, `npm run build`, `npx playwright test`; NO asumir que existen scripts hasta inspeccionar `package.json`.
8. Ante bloqueo por permisos, stack distinto o falta de backend, detenerse y pedir decisión sin improvisar integraciones.

Evita pegar el pack directamente en `src/`: contiene contratos, especificaciones, una maqueta HTML independiente y prompts, **no un patch del repositorio**.
