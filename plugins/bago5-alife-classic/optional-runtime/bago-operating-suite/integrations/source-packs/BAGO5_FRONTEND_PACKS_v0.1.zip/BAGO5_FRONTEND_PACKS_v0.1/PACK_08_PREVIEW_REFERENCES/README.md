# PACK 08 — Mock observable y referencia visual

- `preview.html`: **maqueta HTML independiente**, abre offline con doble clic; muestra las 7 pantallas, catálogo ficticio y algunas operaciones UI. No accede a archivos, credenciales, modelos ni backend.
- `REFERENCIA_CONCEPTUAL_NO_CANONICA.png`: imagen exploratoria de la conversación anterior. Contiene nombres/contadores posiblemente inventados y no es contrato ni evidencia.

**Función:** enseñar visualmente el layout, solicitar cambios de UX y proporcionar referencia a Codex. Ningún indicador de conexión o prueba del mock es un resultado real.

**Criterios de observación:** topbar única, izquierda navegación, subsección settings, CFG-02 con tres columnas, modales explícitos, campos no implementados identificables, cambios de pantalla claros, diseño parecido a Windows.
