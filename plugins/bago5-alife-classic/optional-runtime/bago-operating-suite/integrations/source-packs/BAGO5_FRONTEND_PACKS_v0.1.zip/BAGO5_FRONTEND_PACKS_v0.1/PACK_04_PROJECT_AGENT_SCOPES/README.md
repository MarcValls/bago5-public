# PACK 04 — Global, Proyecto, Agente y Conversación

## Dos espacios de edición, una fuente canónica
- **Global**: `/settings/*`: catálogos, infraestructura, políticas.
- **Proyecto**: `/projects/:projectId/settings`: referencias a modelos globales permitidos, contexto/fuentes propios, agentes vinculados, límites restrictivos, grants por referencia.
- **Agente**: `/agents/:agentId/config`: identidad, instrucciones, modelo preferido de los admitidos, parámetros permitidos, herramientas solicitadas (sin auto-grant).
- **Conversación**: preferencia temporal/sesión; no modificar persistencia global o de proyecto sin otra intención explícita.

## UI: cada control muestra su origen
`Valor efectivo: model-a [PERSONALIZADO: agente-1] [Restricciones: proyecto-A, global]`, con botón `Ver procedencia` y `Restaurar heredado` cuando aplique. Un valor bloqueado conserva razón legible y acceso al propietario correcto.

```text
Global: modelo-A [ACTIVO]
  └─ Proyecto P: allowlist [A, B]
       └─ Agente G: preferido B
            └─ Chat C: intenta D
                 └─ Resolver: BLOCKED (D no admitido)
```

## No duplicar datos
- En proyecto, referencia `modelId`, no copies del proveedor/modelo.
- En agente, preferencia `preferredModelId`, no alta de modelo.
- En fuentes de proyecto, `resourceReference` y `grantRef`, nunca deducir permisos de path.
- En Chat, override temporal no altera agente.
- Políticas globales de seguridad/execution son techos obligatorios.

## Interacción crítica
`Ver configuración efectiva` debe explicar: candidatos, reglas, restricciones, procedencia, bloqueos, autorizaciones **pendientes**; una resolución satisfactoria **no aprueba ejecución**.

## Acceptance samples
1. Proyecto cambia modelo: vista global y otro proyecto no cambian.
2. Agente intenta modelo deshabilitado: bloqueo visible, sin petición de red.
3. Conversación cambia a modelo permitido: selección temporal, sin mutar agente.
4. Proyecto intenta aumentar concurrencia: bloqueado; no guardar sobre techo.
5. Agente solicita acceso a archivo: la UI sólo construye request; grant real requiere AuthorizationService.
6. Revocación entre resolución y efecto: ExecutionGateway revalida; UI muestra receipt de denegación.
7. Fuente de un proyecto no aparece en otro sin autorización/vinculación explícita.
