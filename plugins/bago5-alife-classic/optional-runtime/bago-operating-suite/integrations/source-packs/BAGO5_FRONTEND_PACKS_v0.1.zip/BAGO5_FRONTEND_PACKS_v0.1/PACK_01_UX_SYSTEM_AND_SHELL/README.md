# PACK 01 — Design system, shell y navegación

## Distribución objetivo

```text
┌────────────────────────────────────────────────────────────────────────────────────────────┐
│ BAGO5 │  Inicio / Configuración / Proveedores y modelos                   buscar  Ayuda Perfil │  TOPBAR: 1 línea
├───────────────┬────────────────────────────────────────────────────────────────────────────┤
│ Chat          │ CONFIGURACIÓN                                                             │
│ Proyectos     │  General | Proveedores y Modelos | Seguridad | Ejecución | Contexto ...    │
│ Agentes       │                                                                            │
│ Herramientas  │ ┌────────────────┬───────────────────────────────────┬────────────────────┐ │
│ Ejecución     │ │ PROVEEDORES    │ MODELOS                           │ FICHA MODELO       │ │
│ Evaluación    │ │                │                                   │                    │ │
│ Observabilidad│ │                │                                   │                    │ │
│ Configuración │ └────────────────┴───────────────────────────────────┴────────────────────┘ │
│               │ RUTAS POR FUNCIÓN + PRUEBA EXPLÍCITA / RESUMEN ESTADO                      │
└───────────────┴────────────────────────────────────────────────────────────────────────────┘
```

## Tokens visuales sugeridos (NO FROZEN)
- Tipografía: `Segoe UI, system-ui, sans-serif`, base 14 px, títulos 21/16.
- Fondo `#f5f7fb`, tarjetas `#ffffff`, texto `#182338`, secundarios `#607086`, borde `#d9e1ea`.
- Acento azul `#2361cc`; OK `#118568`; alerta `#a96205`; error `#c32d3e`.
- Radio 4 px, sombra tenue; separación 8/12/16/24; altura campos 34–38 px.
- Sidebar ~205 px, central min 720 px, panel modelo ~310–350 px; a partir de 1440 px usar tres columnas: proveedores 250–270, modelos flexible, detalle 335.
- Topbar: una sola línea, sin duplicar encabezados. Scroll interno sólo en listas; botón Guardar visible sin tapar contenido.

## Responsive y accesibilidad
- >= 1280 px: tres columnas; 900–1279 px: proveedores + modelos, detalle como drawer no modal.
- < 900 px: navegación plegada y una columna con selector o tabs Proveedores / Modelos / Detalle. Sin desplazamiento horizontal del contenido.
- Modal `role=dialog`, `aria-modal`, foco inicial y retorno al disparador, Escape si no hay operación irreversible en curso, bloqueo de scroll de fondo.
- Control con label visible y asociación programática; controles inhabilitados explican por qué y marcan IMPLEMENTACIÓN PENDIENTE si no hay backend.
- Keyboard: Tab, Enter, Escape, Space, flechas para listas; `prefers-reduced-motion`.
- Estados universales: sin datos, cargando, guardando, error, conflicto de revisión, permiso denegado, offline, stale, éxito con evidencia y estado de mock claramente indicado.

## Navegación izquierda (no duplicar)
Chat · Proyectos · Agentes · Herramientas (MCP) · Ejecución · Evaluación · Observabilidad · Configuración. Dentro de Configuración: CFG-01..CFG-07 como navegación secundaria.

## Prohibiciones visuales
- No dashboards ficticios con datos de producción inventados; mostrar `DEMO / DATOS SIMULADOS` cuando proceda.
- No toggles que aparenten cambiar permisos o activar modelos reales sin persistencia real.
- No dos menús de configuración superpuestos ni seis subpáginas para seis ventanas; reutilizar componente modal/drawer.

## Cierre del pack
Shell navegable + 7 entradas + layout responsive + vistas vacías/errores + captura desktop y móvil + accesibilidad básica demostrada.
