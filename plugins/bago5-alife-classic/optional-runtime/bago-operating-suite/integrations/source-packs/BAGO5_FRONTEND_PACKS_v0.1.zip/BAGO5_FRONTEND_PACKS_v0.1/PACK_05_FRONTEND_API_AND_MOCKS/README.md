# PACK 05 — Frontera frontend/backend y fixtures

**No hay endpoints REST certificados aquí.** Todos los nombres de métodos son **puertos de interfaz propuestos**; Codex debe inspeccionar el backend receptor y adaptar (no inventar URL pública ni escribir backend automáticamente).

`types/configContracts.ts` modela `Provider`, `Model`, `ModelRoute`, `ConfigurationEntry`, `EffectiveConfiguration`, `ChangeImpact`, `DiagnosticReceipt` y el ciclo de estados UI.

`fixtures/mock-settings.json` son **datos completamente inventados** para prototipar; nunca mostrarlos como estados reales. No incluyen credenciales ni usuarios reales.

## Puerto sugerido de datos
```ts
interface ConfigGateway {
  listProviders(): Promise<Provider[]>;
  listModels(providerId: string): Promise<Model[]>;
  inspectDependencies(targetId: string): Promise<ChangeImpact>;
  dryRunChange(change: ConfigChange): Promise<ChangeImpact>;
  saveChange(change: ConfigChange, expectedRevision: number): Promise<ConfigurationEntry>;
  resolveEffectiveConfig(request: ResolveRequest): Promise<EffectiveConfiguration>;
  runExplicitDiagnostic(request: DiagnosticRequest): Promise<DiagnosticReceipt>;
}
```

En modo MOCK, `runExplicitDiagnostic` devuelve `NOT_IMPLEMENTED` y no emite tráfico. Una implementación real necesita autorización para llamadas externas facturables, identidad del solicitante, tiempo de prueba, trazas/evidencia y errores tipados.

## Prohibiciones de seguridad
1. Ni API Key ni secretos en `localStorage`, fixtures, logs, Redux/state de navegador o exportación.
2. Los resultados del resolver no son grants. No se invoca una herramienta por mostrar modelo activo.
3. Cada `saveChange` admite control de revisión y prevención de sobrescritura.
4. No asumir que un proveedor ofrece listado de modelos, capacidades o costes actualizados.
5. `connectionStatus` y `availabilityStatus` requieren `lastVerifiedAt` y fuente real para informar de LIVE.
6. La vista debe declararse `MOCK` hasta consumir servicios reales validados.
