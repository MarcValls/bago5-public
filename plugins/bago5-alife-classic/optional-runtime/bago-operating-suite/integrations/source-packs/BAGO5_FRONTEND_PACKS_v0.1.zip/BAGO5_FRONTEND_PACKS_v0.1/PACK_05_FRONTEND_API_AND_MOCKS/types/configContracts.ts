// Contratos de vista PROPUESTOS. No constituyen una API backend real ni conceden permisos.
export type Status = 'unverified' | 'healthy' | 'degraded' | 'unreachable';
export type Availability = 'unverified' | 'available' | 'degraded' | 'unavailable';
export type Scope = 'user' | 'global' | 'project' | 'agent' | 'conversation';
export type Capability = 'chat' | 'reasoning' | 'code' | 'rag' | 'embedding' | 'vision' | 'tool_use' | string;
export interface Provider {
  providerId: string; providerType: string; displayName: string;
  endpoint?: string; authenticationMethod: string; credentialReference?: string;
  enabled: boolean; connectionStatus: Status; lastVerifiedAt?: string;
  revision: number;
}
export interface Model {
  modelId: string; providerId: string; externalModelId: string;
  displayName: string; capabilities: Capability[]; supportedParameters: string[];
  enabled: boolean; availabilityStatus: Availability; lastVerifiedAt?: string;
  revision: number;
}
export interface ModelRoute {
  routeId: string; ownerScope: 'global' | 'project'; ownerId: string;
  purpose: Capability; primaryModelId: string | null; fallbackModelIds: string[];
  parameterOverrides: Record<string, unknown>; revision: number;
}
export interface ConfigurationEntry {
  configurationId: string; domain: string; scope: Scope; ownerId: string;
  schemaVersion: string; revision: number; values: Record<string, unknown>;
}
export interface ChangeImpact {
  targetId: string; operation: string; affectedProjects: string[];
  affectedAgents: string[]; affectedRoutes: string[]; activeExecutions: string[];
  blockingConstraints: string[];
}
export interface EffectiveConfiguration {
  status: 'resolved' | 'blocked'; selectedModelId: string | null;
  eligibleFallbackModelIds: string[]; appliedRestrictions: string[];
  blockedOverrides: string[]; requiredAuthorizations: string[];
  fieldProvenance: Record<string, string[]>; revisionVector: Record<string, number>;
  reasonCodes: string[];
}
export interface ConfigChange { targetId: string; values: Record<string, unknown>; }
export interface ResolveRequest { projectId?: string; agentId?: string; conversationId?: string; purpose: Capability; }
export interface DiagnosticRequest { targetId: string; diagnosticType: 'connection' | 'inference'; consentToPotentialCost: boolean; }
export interface DiagnosticReceipt { status: 'pass' | 'fail' | 'not_run' | 'not_implemented'; targetId: string; checkedAt?: string; evidenceId?: string; message: string; }
export interface ConfigGateway {
  listProviders(): Promise<Provider[]>;
  listModels(providerId: string): Promise<Model[]>;
  inspectDependencies(targetId: string): Promise<ChangeImpact>;
  dryRunChange(change: ConfigChange): Promise<ChangeImpact>;
  saveChange(change: ConfigChange, expectedRevision: number): Promise<ConfigurationEntry>;
  resolveEffectiveConfig(request: ResolveRequest): Promise<EffectiveConfiguration>;
  runExplicitDiagnostic(request: DiagnosticRequest): Promise<DiagnosticReceipt>;
}
