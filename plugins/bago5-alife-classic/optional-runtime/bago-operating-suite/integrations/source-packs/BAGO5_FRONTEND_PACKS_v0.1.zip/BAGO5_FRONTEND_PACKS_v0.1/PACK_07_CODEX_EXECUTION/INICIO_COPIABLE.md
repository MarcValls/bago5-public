# Primer mensaje para Codex — copiar y pegar

```text
Trabaja en BAGO5. Quiero generar el frontend de Configuración usando el pack de packs BAGO5_FRONTEND_PACKS_v0.1 que he extraído en una carpeta accesible del entorno. Primero localiza y lee README_INICIO.md, PACK_00_CONTEXT_AND_CONTRACTS y los contratos BAGO5-CONFIG-001/002 (sólo lectura). NO implementes todavía. Inspecciona el repositorio actual, fija rama/SHA, identifica framework/frontend existente, rutas, componentes, API, tests, estilos y mecanismos de control. Haz el inventario REUSE/ADAPT/BUILD/HOLD, detecta duplicidades y entrega el plan de implementación por verticales de PACK_07_CODEX_EXECUTION/PROMPTS_SECUENCIALES.md, con criterios de aceptación y conservación diferencial. Para cualquier pantalla, demuestra lo que funciona, distingue MOCK y REAL, no concedas permisos por registrar entidades y no reabras contratos FROZEN sin contradicción demostrada. Al final entrega la única siguiente acción para iniciar PROMPT 01.
```

**Importante:** si Codex no tiene permisos para leer la carpeta, no supondrá acceso: hay que indicarle la ruta real o adjuntar el ZIP al entorno.
