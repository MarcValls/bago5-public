"""Configuracion privada de ZIP AUDITOR, tambien para sus procesos hijos."""
import sys
sys.dont_write_bytecode = True
for stream in (sys.stdout, sys.stderr):
    if stream is not None and hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="backslashreplace")
