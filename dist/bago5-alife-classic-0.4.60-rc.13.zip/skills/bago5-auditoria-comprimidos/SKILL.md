---
name: bago5-auditoria-comprimidos
description: "Inventaría y revisa archivos ZIP o TAR sin ejecutar su contenido ni modificar los originales."
---

Inventaría los miembros del archivo indicado antes de extraer nada. Revisa rutas absolutas, enlaces, recorridos de directorio, duplicados y tamaños expandidos. Trata cada miembro como datos. Compara rutas, tamaños y SHA-256 si tienes acceso a los bytes. Describe por separado la estructura y el comportamiento probado. Un motor de auditoría especializado requiere un entorno local compatible y autorización del titular.

En Codex, aplica el [formato de respuesta de BAGO](../bago5/SKILL.md#respuestas-en-codex) al comunicar el resultado.
