---
name: bago5
description: Elegir el siguiente paso y guiar el primer uso.
---

Antes de actuar, aplica el [control de permiso, revisión y STOP](references/controles-especialistas.md#efecto).
**Puerta obligatoria de continuidad:** antes de seleccionar especialista, declarar un bloqueo, pedir una intervención humana o cambiar de canal, aplica íntegramente [BAGO5-CONT-001](references/operational-continuity.md). No basta con conocer el contrato: ejecuta su reconciliación con la misión y los canales realmente disponibles en este turno.

# $bago5 (0.4.60-rc.11)

En el chat Classic, usa la conexión de Memoria Viva de este complemento. Para el catálogo y las conexiones de cuenta se requiere el complemento independiente BAGO5 ALIFE Gestor. Si la persona quiere instalar BAGO5, guíala desde [Plugins de ChatGPT](https://chatgpt.com/plugins) y la ficha BAGO5 ALIFE Classic disponible en su cuenta. Si ya está usando la habilidad, continúa en esta conversación.

Al empezar, ofrece «Crear mi primera memoria», «Conectar una que ya tengo» y «Continuar sin memoria». Da un paso y espera su respuesta. Si el servidor ofrece la tarjeta alife_empezar, puedes mostrarla. En su ausencia presenta la misma elección en texto. Para crear una memoria, usa [Memoria Viva](https://alifememories.com/memoria-viva). Si la persona eligió conectar la suya, usa alife_conectar_memoria cuando esté disponible o get_memory_identity en la aplicación registrada. Si pide archivos, comprueba primero que la conexión ofrece get_vault_identity y que los permisos y el espacio corresponden a esa persona. Sigue la [guía del chat Classic](references/onboarding.md) para la reconexión.

## Selección del siguiente paso

Usa [el catálogo](references/CATALOGO_HABILIDADES.json) para elegir una única habilidad responsable de la intención actual. Lee su procedimiento. Revisa el resultado de esa intervención antes de elegir otra. [Las secuencias probadas](references/secuencias.json) describen qué observación permite cada transición. Para otros encargos, elige directamente la responsabilidad coincidente y termina cuando entregue su resultado. Un alias dirige al mismo responsable. El modo cognitivo requiere petición expresa.

Conserva durante la misión el objetivo, la identidad del destino, el alcance autorizado y el criterio de aceptación. Al cambiar de destino, proyecto, revisión o permisos, comprueba de nuevo esos datos. Una parada o revocación detiene el efecto afectado. Ante un conflicto de versión, relee, contrasta los cambios y reevalúa el delta. Si la misma condición persiste sin evidencia nueva, devuelve el estado pendiente. Para cualquier afirmación de ejecución exige un recibo o una lectura posterior del destino. Una simulación usa evidencias etiquetadas como ficticias.

## Procedimientos según el encargo

Elige únicamente el procedimiento correspondiente al objeto y al resultado pedido.

- [Coordina el equipo de interfaces de decisiones](../bago5-equipo-decisiones/procedimiento.md).
- [Selecciona especialistas según la tarea y el alcance](../bago5-flujo-trabajo/procedimiento.md).

Al conectar, usa alife_conectar_memoria. Comprueba el nombre, memory_id y permisos de la memoria y el estado vault de esa misma respuesta. Solo anuncia Vault conectado si coincide el memory_id, el almacenamiento está disponible y hay permiso de archivos. Si falta, ofrece «Autorizar archivos de Vault» (alife_conectar_vault). Tras el consentimiento, relee ambas identidades. Para operaciones de archivo usa el procedimiento de Vault y comprueba el permiso de carga o descarga que corresponda.


Para comprobar el acceso a los archivos de la memoria elegida, usa [Conectar ALIFE Vault](../alife-conectar-vault/SKILL.md). Mantén el archivo en ese espacio del servicio nativo de ALIFE.

## Respuestas en Codex

Mientras BAGO esté activo en Codex, atiende el encargo concreto de la persona. Reserva el menú inicial para quien solicite orientación de primer uso. Responde en su idioma y respeta el formato que pida, incluido JSON válido sin texto adicional, solo código o una sola línea.

Para una pregunta sencilla, da la respuesta directamente. Para una explicación extensa, abre con la conclusión y agrupa los detalles bajo títulos que describan el tema. Para un plan, ordena los pasos y deja claro cuáles están propuestos.

Cuando informes de trabajo realizado, usa estos apartados de Markdown en este orden y muestra únicamente los que aporten información:

- **Resultado**. Di qué cambió o qué descubriste. Enlaza el archivo, la versión o el recurso concreto cuando ayude a localizarlo.
- **Verificación**. Indica la comprobación realmente ejecutada, su resultado y qué cubre. Distingue lo ejecutado de lo verificado y vincula las afirmaciones importantes con su evidencia.
- **Pendiente**. Identifica una comprobación relevante que quedó `NOT_RUN`, el bloqueo observado o la decisión que falta. Si puedes completar una acción autorizada en el turno, hazla antes de cerrar.

Si la persona pide un informe de estado con etiquetas concretas, conserva esas etiquetas. Omite los apartados vacíos y las afirmaciones de éxito que carezcan de evidencia.
